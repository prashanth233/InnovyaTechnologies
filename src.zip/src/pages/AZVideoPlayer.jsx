import React, { useEffect } from 'react'
// import calImg from '../Assets/Calendar.png'

import '../styles/App.css'
import PropTypes from 'prop-types'
import { isMobile } from 'react-device-detect'
let myAZPlayer
const currentRole = JSON.parse(localStorage.getItem('UserType'))
let status = ''
let videoEnded = false
export const AZVideoPlayer = ({ videoUrlData, handleModalPopUp, handleAzurePlayerClick, rtm, sameSession, isVREnabled }) => {
  const handleAzurePlayer = (e) => {
    // console.log('Azure media player click::', e.target.innerText, e.target)
    if (currentRole === 'Practitioner') {
      handleAzurePlayerClick(e.target.innerText, myAZPlayer.currentTime())
    }
  }
  const handleAzurePlayerEvents = () => {
    if (currentRole === 'Practitioner') {
      handleAzurePlayerClick('Seeking', myAZPlayer.currentTime())
    }
  }
  const handleAzurePlayerPausedEvents = () => {
    if (currentRole === 'Practitioner') {
      handleAzurePlayerClick('Pause', myAZPlayer.currentTime())
    }
  }
  const handleAzurePlayerPlayEvents = () => {
    if (currentRole === 'Practitioner') {
      handleAzurePlayerClick('Play', myAZPlayer.currentTime())
    }
  }
  const handleAzurePlayerVideoEndEvents = () => {
    if (currentRole === 'Practitioner') {
      // console.log('Video complete', myAZPlayer.currentAbsoluteTime(), myAZPlayer.duration() - 1)
      handleAzurePlayerClick('Ended', myAZPlayer.currentTime())
    }
  }

  useEffect(() => {
    status = ''
    const isVrMode = currentRole === 'Client' && isVREnabled

    if (!isVrMode) {
      myAZPlayer = window.amp('practitionerVideoPlayer', {
        autoplay: false,
        controls: true,
        techOrder: ['azureHtml5JS', 'html5']
      }, function () {
        if (currentRole === 'Practitioner') {
          this.addEventListener('seeked', handleAzurePlayerEvents)
          this.addEventListener('pause', handleAzurePlayerPausedEvents)
          this.addEventListener('play', handleAzurePlayerPlayEvents)
          this.addEventListener('ended', handleAzurePlayerVideoEndEvents)
        }
      })
    } else {
      myAZPlayer = window.amp('clientVideoPlayer', {
        // nativeControlsForTouch: false,
        autoplay: false,
        controls: true,
        poster: '',
        techOrder: ['azureHtml5JS', 'html5']
      }, function () {
        console.log('Good to go Client!')
      })
    }
    myAZPlayer.src([{
      src: videoUrlData,
      // type: 'application/vnd.apple.mpegurl'
      type: 'application/vnd.ms-sstr+xml'
    }])
    document.getElementById('practitionerMediaPlayer').style.display = 'block'
    // window.dispatchEvent(new Event('resize'))

    if (sameSession) {
      rtm && rtm.on('MemberJoined', ({ channelName, args }) => {
        const memberId = args[0]
        console.log('MemberJoinedAZ :: channel ', channelName, ' member: ', memberId, 'Role:', currentRole)
      })

      rtm && rtm.on('MemberLeft', ({ channelName, args }) => {
        const memberId = args[0]
        console.log('MemberLeftAZ:: channel ', channelName, ' member: ', memberId, 'Role:', currentRole)
      })
      rtm && rtm.on('ChannelMessage', async ({ channelName, args }) => {
        const [message, memberId] = args
        console.log('azvideoplayer ChannelMessage:: channel ', channelName, ', messsage: ', message.text, ', memberId: ', memberId, 'Role:', currentRole)
        // console.log('JSON.parse(message)::', JSON.parse(message.text).action)
        const messageData = JSON.parse(message.text)
        if (messageData === 'Close') {
          handleModalPopUp(myAZPlayer.currentTime(), myAZPlayer.duration(), status, videoEnded)

          // setIsVideoStarted(false)
        }
        if (messageData === 'Play') {
          // console.log('Session acti comp ChannelMessage:: channel ', channelName, ', messsage: ', message.text, ', memberId: ', memberId)
          // document.getElementById('clientMediaPlayer').style.display = 'block'
          status = 'play'
          videoEnded = false
          myAZPlayer.currentTime()
          myAZPlayer.play()
          // azureMediaPlayerRef.current.play()
          // mediaPlayer.play()
        }
        if (messageData === 'Pause') {
          // console.log('Session acti comp ChannelMessage:: channel ', channelName, ', messsage: ', message.text, ', memberId: ', memberId)
          myAZPlayer.pause()
        }
        if (messageData === 'Ended') {
          // console.log('Session acti comp ChannelMessage:: channel ', channelName, ', messsage: ', message.text, ', memberId: ', memberId)
          videoEnded = true
          myAZPlayer.pause()
        }
        if (messageData === 'Mute') {
          // console.log('Session acti comp ChannelMessage:: channel ', channelName, ', messsage: ', message.text, ', memberId: ', memberId)
          myAZPlayer.muted(true)
        }
        if (messageData && messageData.action === 'Seeking') {
          // console.log('Session acti comp ChannelMessage:: channel ', channelName, ', messsage: ', message.text, ', memberId: ', memberId)
          myAZPlayer.currentTime(messageData.playerDuration)
        }
        if (messageData === 'Unmute') {
          // console.log('Session acti comp ChannelMessage:: channel ', channelName, ', messsage: ', message.text, ', memberId: ', memberId)
          myAZPlayer.muted(false)
        }
        // console.log('End of channel message ::', messageData, message.text)
      })
    }

    return () => {
      if (currentRole === 'Practitioner') {
        myAZPlayer.removeEventListener('seeking', handleAzurePlayerEvents)
        myAZPlayer.removeEventListener('ended', handleAzurePlayerVideoEndEvents)
        myAZPlayer.removeEventListener('pause', handleAzurePlayerPausedEvents)
        myAZPlayer.removeEventListener('play', handleAzurePlayerPlayEvents)
      }
      myAZPlayer && myAZPlayer.dispose()
    }
  }, [])
  // azureModaliOS
  const deviceTypeiOS = isMobile
  const isVrMode = currentRole === 'Client' && isVREnabled
  // console.log('VR enabled data::', isVrMode, isVREnabled)
  return (
    <>
      <div id='practitionerMediaPlayer' className={deviceTypeiOS ? 'azureModaliOS' : 'azureModal'} onClick={handleAzurePlayer}>
        {
          !isVrMode
            ? (
              <video id="practitionerVideoPlayer" crossOrigin
                className="azuremediaplayer amp-default-skin amp-big-play-centered" playsinline tabIndex="0" autoPlay controls width="100%" height="100%" data-setup='{ "nativeControlsForTouch": false, "techOrder": ["azureHtml5JS", "html5"] }' >
                <p className="amp-no-js">
                  To view this video please enable JavaScript, and consider upgrading to a web browser that
                  supports HTML5
                  video
                </p>
              </video>
              )
            : (
              <video id="clientVideoPlayer" crossOrigin
                className="azuremediaplayer amp-default-skin amp-big-play-centered" playsinline autoPlay controls disableFullscreenButton width="100%" height="100%" data-setup='{ "nativeControlsForTouch": false, "techOrder": ["azureHtml5JS", "html5"], "plugins": { "threeSixty": { "hardwareScalingLevel": 1 } } }' >
                <p className="amp-no-js">
                  To view this video please enable JavaScript, and consider upgrading to a web browser that
                  supports HTML5
                  video
                </p>
              </video>
              )
        }

      </div>
    </>
  )
}

AZVideoPlayer.propTypes = {
  name: PropTypes.string,
  isVREnabled: PropTypes.bool,
  videoUrlData: PropTypes.string,
  sameSession: PropTypes.bool,
  handleAzurePlayerClick: PropTypes.func,
  handleModalPopUp: PropTypes.func,
  rtm: PropTypes.object
}
