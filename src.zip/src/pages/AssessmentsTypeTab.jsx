import React, { useState } from 'react'
import { Tabs, Tab } from 'react-bootstrap'
import '../styles/App.css'
import PropTypes from 'prop-types'
import { ClientAssessmentListing } from './ClientAssessmentListing'

export const AssessmentsTypeTab = ({ selectedTab, cardData }) => {
  const [key, setKey] = useState(selectedTab)
  const baselineData = cardData.filter(data => data.assessmentType === 'baseline')
  const interimData = cardData.filter(data => data.assessmentType === 'interim')

  return (
      <div style={{ paddingLeft: 20 }}>
        <Tabs
        id="controlled-tab-example"
        activeKey={key}
        onSelect={(k) => setKey(k)}
        className="tabTitleAssessment"
        // style={{color:'red'}}
      >
        <Tab eventKey="baseline" title="Baseline">
          <ClientAssessmentListing assessmentsData={baselineData}></ClientAssessmentListing>
        </Tab>
        <Tab eventKey="interim" title="Interim">
        <ClientAssessmentListing assessmentsData={interimData}></ClientAssessmentListing>
        </Tab>
      </Tabs>
      </div>
  )
}

AssessmentsTypeTab.propTypes = {
  selectedTab: PropTypes.string,
  cardData: PropTypes.array
}
