/* eslint-disable array-callback-return */
import React, { useState, useEffect } from 'react'
import { useMsal, useAccount } from '@azure/msal-react'
import { Button, ListGroup } from 'react-bootstrap'
import { TableComponent } from '../components/TableComponent'
import { patientProfileColumns } from '../CommonData/Data'
import { callApiForListing } from '../fetch'
import { ClientAppointments } from '../CommonData/APIListing'
import { LoaderModalPopUp } from '../CommonData/ModalPopUp'
import { NoAppointmentFound } from '../CommonData/WorkInProgress'
import '../styles/App.css'
import { getTodaysDate, getTodaysFromDate } from '../CommonData/CommonFunction'
import PropTypes from 'prop-types'

const currentRole = JSON.parse(localStorage.getItem('UserType'))

const AppointmentListGroup = ({ appointmentFilter, selectd }) => {
  return (
    <>
      <div style={{ float: currentRole === 'Practitioner' ? 'right' : 'left' }} >
        <ListGroup horizontal active="#link2" style={{ height: 45, fontFamily: 'Roboto', fontSize: 14, color: '#139ED7', border: '1px solid #139ED7', borderRadius: 5 }}>
          <ListGroup.Item active={selectd === 'upcoming'} id="upcoming" onClick={appointmentFilter} >Upcoming</ListGroup.Item>
          <ListGroup.Item active={selectd === 'past'} id="past" onClick={appointmentFilter} >Past</ListGroup.Item>
          <ListGroup.Item active={selectd === 'all'} id="all" onClick={appointmentFilter} >All</ListGroup.Item>
        </ListGroup>
      </div>

    </>)
}

AppointmentListGroup.propTypes = {
  selectd: PropTypes.string,
  appointmentFilter: PropTypes.func.isRequired
}

export const ClientAppointmentsListing = ({ userId, viewAppointmentClicked, scheduleAppointmentClicked }) => {
  const columns = patientProfileColumns
  const [isAPICalling, setisAPICalling] = useState(false)

  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})

  const [cardData, setCardData] = useState([])

  // For Today, This Month , This week, All related
  const [selectd, setSelectd] = useState('upcoming')

  const appointmentFilter = (e) => {
    // console.log("Clicked", e.target.id);
    setSelectd(e.target.id)
  }

  const getAppointmentUrl = (type) => {
    const tenantId = account.idTokenClaims.extension_Organization
    const userData = JSON.parse(localStorage.getItem('UserData'))
    const currentRole = JSON.parse(localStorage.getItem('UserType'))

    const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName

    const commonData = `${tenantId}/${practiceName}/appointments/patient/`
    const currentDate = getTodaysDate()
    const currentFromDate = getTodaysFromDate()

    let url = ''
    switch (type) {
      case 'upcoming':
        url = `${commonData}${userId}?fromdate=${currentFromDate}`
        break
      case 'past':
        url = `${commonData}${userId}?todate=${currentDate}`

        break
      case 'all':
        url = `${commonData}${userId}`
        break
      default:
        url = `${commonData}${userId}?fromdate=${currentFromDate}`
        break
    }

    return url
  }

  const getAllAppointmentsListing = () => {
    const appointmentUrl = `${ClientAppointments}${getAppointmentUrl(selectd)}`
    // console.log("Client appt URL::", appointmentUrl, selectd);
    setisAPICalling(true)
    callApiForListing(appointmentUrl)
      .then((response) => {
        // console.log('Client Appointment Listing API Resp:-', response)
        setisAPICalling(false)
        // setcardDataDefault(response)
        const finalResp = response && response.length ? response : []

        const sortedRespData = selectd === 'upcoming' ? [...finalResp].sort((a, b) => Date.parse(new Date(a.meetingStartDateTime)) - Date.parse(new Date(b.meetingStartDateTime))) : [...finalResp].sort((a, b) => Date.parse(new Date(a.meetingStartDateTime)) - Date.parse(new Date(b.meetingStartDateTime))).reverse()
        // console.log('Client Sorted API Resp:-', sortedRespData)

        if (finalResp.length) {
          finalResp.map(obj => {
            obj.meetingStatus = obj.status
            obj.meetingDateTime = `${obj.meetingStartDateTime};${obj.meetingEndDateTime}`
            obj.meetingAssessmentStatus = `${obj.assessmentStatus};${obj.assessmentPendingCount}`
          })
        }
        setCardData([...sortedRespData])
      })
  }

  // Table Column Button View Details Click handler
  const onRowClicked = (row, e) => {
    // console.log("table event Data::", e.target.innerText);
    if (e.target.nodeName === 'BUTTON' && (e.target.innerText === 'Activities' || e.target.innerText === 'Assessments')) {
      const tabData = e.target.innerText.toLowerCase()
      viewAppointmentClicked(row.original, tabData)
    }
  }
  /// //////

  useEffect(() => {
    getAllAppointmentsListing()
  }, [selectd])
  return (
    <div style={{ border: '1px solid #EEEEEE' }}>
      <LoaderModalPopUp show={isAPICalling} message='Fetching Appointments...' />
      <div style={{
        margin: '20px'
      }}>

        <AppointmentListGroup selectd={selectd} appointmentFilter={appointmentFilter} ></AppointmentListGroup>
        {
          currentRole === 'Coordinator' && (
            <Button variant="danger" style={{ float: 'right', backgroundColor: '#F24B5D', color: 'white', border: 'none', height: 35 }} onClick={scheduleAppointmentClicked} >SCHEDULE</Button>
          )
        }
      </div>
      <div style={{ padding: '40px 10px 20px 10px', color: '#2D2D34' }} >
        {
          cardData && cardData.length
            ? (<TableComponent columns={columns} data={cardData} onRowClicked={onRowClicked} showHeader={true} tableWidth="70vw" />)
            : (<NoAppointmentFound></NoAppointmentFound>)
        }
      </div>

    </div>
  )
}

ClientAppointmentsListing.propTypes = {
  userId: PropTypes.string,
  viewAppointmentClicked: PropTypes.func,
  scheduleAppointmentClicked: PropTypes.func.isRequired

}
