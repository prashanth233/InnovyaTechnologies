/* eslint-disable no-unreachable */
/* eslint-disable array-callback-return */
import React, { useState, useRef, useEffect } from 'react'
import '../styles/App.css'
import { Form, Col, Row, Button } from 'react-bootstrap'
import { useMsal, useAccount } from '@azure/msal-react'
import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import ProfileEdit from '../Assets/ProfileEdit.png'
import { Avatar, Badge, Divider } from '@mui/material'
import { styled } from '@mui/material/styles'
import { languagePref } from '../CommonData/Data'
import { LabelComponent, LabelComponentRequired } from './LabelComponent'
import Loader from './Loader'
import PropTypes from 'prop-types'
import { CoordinatorBaseURL, userDataAPI } from '../CommonData/APIListing'
import { callApiForProfile, callApiForRegistration } from '../fetch'
import { LoaderModalPopUp, ModalPopUp } from '../CommonData/ModalPopUp'
import { ClientRegistrationUrl, createProfileBaseUrl } from '../CommonData/CreateAPIUrl'

export function EditProfile ({ userData, handleEditProfile }) {
  const [photoChanged, setPhotoChanged] = useState(false)
  const profileFile = useRef(null)
  const [isAPICalling, setIsAPICalling] = useState(false)
  const [isLoading, setLoading] = useState(false)
  const [imgFile, setImgFile] = useState(userData.photo === '' ? ProfilePlaceholder : userData.photo)
  const [errors, setErrors] = useState([])
  const [registrationData, setRegistrationData] = useState(userData)
  let userLangPref = ''
  languagePref.forEach(element => {
    if (element.code === registrationData.languagePreferences) {
      userLangPref = element.language
    }
  })
  const [userLang, setUserLang] = useState(userLangPref)
  const [showModal, setShowModal] = useState(false)
  const [showErrorModal, setShowErrorModal] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')
  const [headerMessage, setHeaderMessage] = useState('')
  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})

  const handleSubmit = (event) => {
    const requiredDataCheck = Object.assign({}, registrationData)

    const deleteKeysData = ['age', 'middleName', 'dob', 'babyDOB', 'gender', 'id', 'insurenceId', 'insurenceName', 'insurencePlan', 'mrnNo', 'referralName', 'country', 'photo', 'referralPracticeName']
    deleteKeysData.forEach(element => {
      delete requiredDataCheck[element]
    })

    const errorsData = []
    // console.log('requiredDataCheck Data:', requiredDataCheck)
    Object.entries(requiredDataCheck).map(([key, value]) => {
      value !== null && value.length === 0 && errorsData.push(key)
      if (['mobileNo', 'zipCode'].indexOf(key) !== -1 && !Number(value)) {
        errorsData.push(key)
      }
      setErrors(errorsData)
    })

    // console.log('Errors Data:', errorsData.length, errorsData)
    if (errorsData.length === 0) {
    //   event.stopPropagation()
    //   //   setIsAPICalling(true)
      saveFormData()
    }
  }
  const handleReset = (event) => {
    setRegistrationData({})
    setRegistrationData(userData)
    setPhotoChanged(false)
    // event.preventDefault();
    event.stopPropagation()
  }
  const SmallAvatar = styled(Avatar)(({ theme }) => ({
    left: -10,
    top: -5,
    width: 30,
    height: 30,
    border: '1px solid #F24B5D' // ${theme.palette.background.paper}
  }))

  const hasError = (key) => {
    return errors.indexOf(key) !== -1
  }

  const handleDataChange = (e) => {
    const { name, value } = e.target
    // console.log('Name value::', name, value)
    const errors = []
    if (!Number(value) && ['mobileNo', 'zipCode'].indexOf(name) !== -1) {
      errors.push(name)
    }
    if (value === '' && ['address', 'city', 'state'].indexOf(name) !== -1) {
      errors.push(name)
    }
    if (name === 'languagePreferences') {
      setUserLang(value)
    }

    // email
    // '/\S+@\S+\.\S+/'
    // const expression = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/ /// \S+@\S+/;
    const expression = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/ /// \S+@\S+/;

    const validEmail = expression.test(String(value).toLowerCase())

    if (!validEmail && name === 'email') {
      errors.push(name)
    }
    setErrors(errors)
    setRegistrationData(oldState => ({ ...oldState, [name]: value }))
  }

  const handleFileChange = (event) => {
    setLoading(true)
    const file = event.target.files[0]
    const reader = new FileReader()

    reader.onload = () => {
      // console.log('Img data::', reader.result)
      setImgFile(reader.result)
      setLoading(false)
      setPhotoChanged(true)
    }
    reader.readAsDataURL(file)
  }
  // console.log('registrationData::', registrationData, userLang)

  const saveFormData = () => {
    let langPrefCode // = registrationData.languagePreferences === '' ? 'en-US' : registrationData.languagePreferences
    languagePref.forEach(element => {
      // console.log('languagePref.forEach(element =>::', element, registrationData.languagePreferences)

      if (element.language === userLang) {
        langPrefCode = element.code
      }
    })
    // console.log('registrationData::', registrationData, langPrefCode)
    const saveData = {
      id: registrationData.id,
      firstName: registrationData.firstName,
      middleName: registrationData.middleName,
      lastName: registrationData.lastName,
      email: registrationData.email,
      mobileNo: registrationData.mobileNo,
      address: registrationData.address,
      city: registrationData.city,
      state: registrationData.state,
      zip: registrationData.zipCode,
      photoId: photoChanged ? imgFile : '',
      userName: registrationData.userName,
      languagePreference: langPrefCode,
      referralPracticeName: registrationData.referralPracticeName
    }

    // console.log('saveData Resp:-', saveData)
    // return
    const reqUrl = `${ClientRegistrationUrl(account, CoordinatorBaseURL)}/${saveData.id}`

    // const reqUrl = `${ClientRegistration}/${saveData.id}`
    setIsAPICalling(true)
    setHeaderMessage('Client Profile Update')
    callApiForRegistration(reqUrl, saveData)
      .then((response) => {
        // console.log('Edit profile API Resp:-', response)
        setIsAPICalling(false)
        if (response && response === 'Client Updated Successfully') {
          setShowModal(true)
        } else {
          setShowErrorModal(true)
        }
        setErrorMessage(response)
      })
      .catch(error => console.log('API Catch eror main class', error))
  }

  // Get client details
  const getClientDetails = () => {
    setIsAPICalling(true)
    setHeaderMessage('Fetching client details...')
    const profileUrl = createProfileBaseUrl(account, userDataAPI)
    callApiForProfile(profileUrl, userData.id, 'client')
      .then((response) => {
        // console.log('Get user profile API Resp:-', response)
        const finalResp = response || {}
        setImgFile(finalResp.photo === '' ? ProfilePlaceholder : finalResp.photo)
        setIsAPICalling(false)
        setRegistrationData(finalResp)
      })
  }

  const handleModalPopUp = () => {
    setShowModal(!showModal)
    handleEditProfile()
  }
  const handleErrorModalPopUp = () => {
    setShowErrorModal(false)
  }

  useEffect(() => {
    getClientDetails()
  }, [])

  // console.log('userLang::', userLang)
  return (
      <>
    <ModalPopUp handleModalPopUp={handleModalPopUp} show={showModal} header={headerMessage} messageBody={errorMessage} />
    <ModalPopUp handleModalPopUp={handleErrorModalPopUp} show={showErrorModal} header="Error!" messageBody={errorMessage} />
    <LoaderModalPopUp show={isAPICalling} message='Client Updation is in progress...' />
        <Form noValidate onReset={handleReset}>
            <div style={{ display: 'flex', justifyContent: 'start' }}>
                <div>
                    <div style={{ marginRight: '35px', width: '148px', height: '148px' }}>
                        {
                            isLoading
                              ? (
                                <Loader />
                                )
                              : (
                                    <>
                                        <Badge
                                            overlap="circular"
                                            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                                            badgeContent={
                                                <SmallAvatar onClick={() => profileFile.current.click()} src={ProfileEdit} />
                                            }
                                        >
                                            <Avatar
                                                src={imgFile}
                                                // src={registrationData["photo"] === "" ? ProfilePlaceholder : registrationData["photo"]}
                                                rounded
                                                sx={{ width: 148, height: 148 }}
                                            />
                                        </Badge>
                                        <input
                                            id="profile"
                                            ref={profileFile}
                                            type="file"
                                            style={{ display: 'none' }}
                                            accept="image/*"
                                            onChange={handleFileChange}
                                        />
                                    </>
                                )
                        }

                    </div>
                    <Divider variant="middle" style={{ padding: '15px', marginLeft: '-5px', width: '130px' }} />
                    {/* <p style={{ padding: '20px', marginLeft: '-15px', color: '#F24B5D', fontFamily: 'Roboto', fontSize: '14px' }}>CHANGE PASSWORD</p> */}
                </div>
                <div >
                    <Row style={{ width: '70vw' }}>
                        <Form.Group as={Col} controlId="validationCustom01">
                            <LabelComponentRequired name="First Name " />
                            <Form.Control
                                disabled
                                type="text"
                                placeholder="First Name"
                                name='firstName'
                                value={registrationData.firstName}
                                onChange={handleDataChange}
                            />
                        </Form.Group>
                        <Form.Group as={Col} controlId="validationCustom02">
                            <LabelComponent name="Middle Name " />
                            <Form.Control
                                type="text"
                                placeholder="Middle Name"
                                name='middleName'
                                value={registrationData.middleName}
                                onChange={handleDataChange}
                            />
                            {/* <Form.Control.Feedback>Looks good!</Form.Control.Feedback> */}
                        </Form.Group>
                        <Form.Group as={Col} controlId="validationCustom02">
                            <LabelComponentRequired name="Last Name " />
                            <Form.Control
                                disabled
                                type="text"
                                placeholder="Last Name"
                                name='latstName'
                                value={registrationData.lastName}
                                onChange={handleDataChange}
                            />
                        </Form.Group>
                    </Row>
                    <Row >
                        <Form.Group as={Col} md="4" controlId="validationCustom03">
                            <LabelComponentRequired name="Email " />
                            <Form.Control type="text" name="email" value={registrationData.email} onChange={handleDataChange} placeholder="Email" required />
                            <div
                                className={hasError('email') ? 'inline-errormsg' : 'hidden'}
                            >
                                Email is invalid or missing
                            </div>
                        </Form.Group>
                        <Form.Group as={Col} md="4" controlId="validationCustom03">
                            <LabelComponentRequired name="Mobile Number " />
                            <Form.Control type="text" name="mobileNo" value={registrationData.mobileNo} onChange={handleDataChange} placeholder="Mobile Number" required style={{ borderColor: hasError('mobileNo') ? '#F24B5D' : '', boxShadow: 'none' }} />
                            <div
                                className={hasError('mobileNo') ? 'inline-errormsg' : 'hidden'}
                            >
                                Please enter valid mobile number
                            </div>
                        </Form.Group>
                        <Form.Group as={Col} md="4" controlId="validationCustom03">
                            <LabelComponent name="Username " />
                            <Form.Control disabled type="text" name="userName" value={registrationData.userName} onChange={handleDataChange} placeholder="User Name" />
                        </Form.Group>
                    </Row>
                    <Row >
                        <Form.Group as={Col} controlId="validationCustom04">
                            <LabelComponentRequired name="Address " />
                            <Form.Control type="text" placeholder="Address" name="address" onChange={handleDataChange} value={registrationData.address} required />
                            <div
                                className={hasError('address') ? 'inline-errormsg' : 'hidden'}
                            >
                                Please enter valid address
                            </div>
                        </Form.Group>
                        <Form.Group as={Col} controlId="validationCustom03">
                            <LabelComponentRequired name="City " />
                            <Form.Control type="text" placeholder="City" name="city" onChange={handleDataChange} value={registrationData.city} required />
                            <div
                                className={hasError('city') ? 'inline-errormsg' : 'hidden'}
                            >
                                Please provide valid City
                            </div>
                        </Form.Group>
                    </Row>
                    <Row >
                    <Form.Group as={Col} controlId="validationCustom05">
                            <LabelComponentRequired name="Zip Code " />
                            <Form.Control type="text" placeholder="Zip Code" name="zipCode" onChange={handleDataChange} value={registrationData.zipCode} required />
                            <div
                                className={hasError('zipCode') ? 'inline-errormsg' : 'hidden'}
                            >
                                Please enter only numeric values
                            </div>
                        </Form.Group>
                        <Form.Group as={Col} controlId="validationCustom04">
                            <LabelComponentRequired name="State " />
                            <Form.Control type="text" placeholder="State" name="state" onChange={handleDataChange} value={registrationData.state} required />
                            <div
                                className={hasError('state') ? 'inline-errormsg' : 'hidden'}
                            >
                                Please provide valid State
                            </div>
                        </Form.Group>
                    </Row>
                    <Row>
                        <Form.Group as={Col} md="4" controlId="validationCustom03">
                            <LabelComponent name="Referring Practice Name " />
                            <Form.Control type="text" value={registrationData.referralPracticeName} name="referralPracticeName" disabled />
                        </Form.Group>
                        <Form.Group as={Col} md="4" >
                            <LabelComponent name="Language Preference " />
                            <Form.Control as="select" value={userLang} name="languagePreferences" onChange={handleDataChange}>
                                {
                                    languagePref.map((x, y) =>
                                        <option key={y}>{x.language}</option>)
                                }
                            </Form.Control>
                        </Form.Group>
                    </Row>
                </div>
            </div>
            <Divider variant="middle" style={{ padding: '10px' }} />
            <Form.Group style={{ padding: '30px' }}>
                <Row style={{ float: 'right' }}>
                    <Form.Group md="auto" controlId="validationCustom03">
                        <Button style={{ backgroundColor: '#F24B5D', borderRadius: '5px', border: 'none', color: 'white' }} onClick={handleSubmit} >Save</Button>
                    </Form.Group>
                    <Form.Group md="auto" controlId="validationCustom03">
                        <button type="reset" style={{ backgroundColor: 'white', border: '1px red solid', color: '#F24B5D', borderRadius: '5px', height: '35px', marginLeft: '20px' }} onClick={handleEditProfile} >Cancel</button>
                    </Form.Group>
                </Row>
            </Form.Group>
            <br />
        </Form>
        </>
  )
}

EditProfile.propTypes = {
  userData: PropTypes.object,
  handleEditProfile: PropTypes.func.isRequired
}
