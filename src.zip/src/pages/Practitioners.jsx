import React, { useEffect, useState } from 'react'
import { MsalAuthenticationTemplate, useMsal, useAccount } from '@azure/msal-react'
import { InteractionType } from '@azure/msal-browser'
import { Button } from 'react-bootstrap'
import { Divider } from '@mui/material'
import { loginRequest } from '../authConfig'
import { callApiForListing } from '../fetch'
import PractitionerDetails from '../Cards/PractitionerDetails'
import { RegistrationPractitioner } from './RegistrationPractitioner'
import SearchComponent from '../components/SearchComponent'
import { LoaderModalPopUp, ModalPopUp } from '../CommonData/ModalPopUp'
import { PractitionerListing } from '../CommonData/APIListing'
import { coordinatorPractitionerSearch } from '../CommonData/Data'

const PractitionerContent = () => {
  /**
     * useMsal is hook that returns the PublicClientApplication instance,
     * an array of all accounts currently signed in and an inProgress value
     * that tells you what msal is currently doing. For more, visit:
     * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-react/docs/hooks.md
     */
  const { instance, accounts, inProgress } = useMsal()
  const account = useAccount(accounts[0] || {})
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const [showLogOutErrorModal, setShowLogOutErrorModal] = useState(false)
  // const [helloData, setHelloData] = useState(null)
  const currentRole = JSON.parse(localStorage.getItem('UserType'))

  const [isAPICalling, setisAPICalling] = useState(false)

  const [cardData, setCardData] = useState([])
  const [cardDataDefault, setcardDataDefault] = useState([])

  const [pageNo, setPageNo] = useState(1)
  const [pageCount, setPageCount] = useState(1)
  const [show, setShow] = useState(false)

  const [allPractitioner, setAllPractitioner] = useState(true)
  const [searchData, setSearchData] = useState('')
  const [searchKey, setSearchKey] = useState('userName')
  const [filterName, setFilterName] = useState('Filter')

  const handleSearch = (event) => {
    const searchValue = event.target.id === 'clear' ? '' : event.target.value
    // console.log("Handle search name1:-", event.target.id, searchValue);
    const searchedCards = cardDataDefault.filter((item) => {
      // console.log('Handle search item prac:-', item, searchKey)
      return item[searchKey] && Object.values(item[searchKey]).join('').toLowerCase().includes(searchValue && searchValue.toLowerCase())
    })
    // console.log("Searched Result=:", searchedCards);
    setPageNo(1)
    handlePagination(searchValue === '' ? cardDataDefault : searchedCards)
    setSearchData(searchValue)
  }
  const handlePagination = (data) => {
    const pageCount = data.length % 10 ? ~~(data.length / 10) + 1 : ~~(data.length / 10)

    // setPageNo()
    setPageCount(pageCount)
    const showData = data.slice((pageNo - 1) * 10, pageNo * 10)
    // console.log("showData Result=:", showData);

    setCardData(showData)
  }
  const handlePageChange = (event, value) => {
    setPageNo(value)
    // console.log("DEfault Carddata Result=:", cardDataDefault);

    const showData = cardDataDefault.slice((value - 1) * 10, value * 10)
    // console.log("showData Result=:", showData);

    setCardData(showData)
    // console.log("Selectd page:-", value);
  }

  const handleFilterChange = (event, value) => {
    // console.log('Event target::--', event.target.id);
    if (event.target.id !== 'filter') {
      // console.log('inside if handleFilterChange::')

      const filterNameValue = event.target.name === '' ? filterName : event.target.name
      setFilterName(filterNameValue)
      setSearchKey(event.target.id)
    }

    setShow(!show)
  }
  const handleAllPractitionerChange = () => {
    setAllPractitioner(!allPractitioner)
    getAllPractitionerListing()
  }
  const getAllPractitionerListing = () => {
    callApiForListing(PractitionerListing)
      .then((response) => {
        const finalResp = response && typeof (response) === 'object' ? response : []
        handlePagination(finalResp)

        setisAPICalling(false)
        setcardDataDefault(finalResp)
      })
  }

  useEffect(() => {
    setisAPICalling(true)
    getAllPractitionerListing()
  }, [])

  useEffect(() => {
    if (account && inProgress === 'none') {
      // instance.acquireTokenSilent({
      //     scopes: protectedResources.apiHello.scopes,
      //     account: account
      // }).then((response) => {
      //     // callApiWithToken(response.accessToken, protectedResources.apiHello.endpoint)
      //     //     .then(response => setHelloData(response));
      // }).catch((error) => {
      //     // in case if silent token acquisition fails, fallback to an interactive method
      //     // if (error instanceof InteractionRequiredAuthError) {
      //     //     if (account && inProgress === "none") {
      //     //         instance.acquireTokenPopup({
      //     //             scopes: protectedResources.apiHello.scopes,
      //     //         }).then((response) => {
      //     //             callApiWithToken(response.accessToken, protectedResources.apiHello.endpoint)
      //     //                 .then(response => setHelloData(response));
      //     //         }).catch(error => // console.log(error));
      //     //     }
      //     // }
      // });
    }
  }, [account, inProgress, instance])

  // This useeffect is used to check if any other user is logged in in other tab or not
  useEffect(() => {
    if (account.idTokenClaims.sub !== userData.id) {
      setShowLogOutErrorModal(true)
    }
  })
  const logOutUser = () => {
    // localStorage.clear()
    instance.logoutRedirect({ postLogoutRedirectUri: '/' })
  }

  return (
        <>
        <LoaderModalPopUp show={isAPICalling} message='Fetching Practitioner listing...' />
        <ModalPopUp handleModalPopUp={logOutUser} show={showLogOutErrorModal} header="Error!" messageBody='Another user is logged in. You will be logout' />

        <div style={{ backgroundColor: '#FFF5F6', padding: '20px' }}>
            <div style={{ backgroundColor: 'white', borderRadius: '20px', border: '2px' }}>
                    <div style={{ padding: '10px 20px 5px 20px', color: '#139ED7', fontFamily: 'Roboto, light', fontSize: '20px', display: 'flex', justifyContent: 'space-between', marginTop: '10px' }}>
                    <p > {allPractitioner ? 'All Practitioners' : 'Register New Practitioner'}</p>

                    {currentRole === 'Coordinator' ? <Button variant="danger" style={{ backgroundColor: allPractitioner ? '#F24B5D' : 'white', color: allPractitioner ? 'white' : '#F24B5D', border: 'none' }} onClick={handleAllPractitionerChange}>{allPractitioner ? 'REGISTER PRACTITIONER' : 'ALL PRACTITIONERS'}</Button> : null}

                </div>
                <Divider variant="middle" />
                <div style={{
                  position: 'relative',
                  float: 'right',
                  marginRight: '30px',
                  marginTop: '10px'
                }}>
                    {(allPractitioner)
                      ? <SearchComponent filterArr={coordinatorPractitionerSearch} onSearchClick={handleSearch} searchValue={searchData} handleFilterChange={handleFilterChange} filterName={filterName} />
                      : null }
                </div>
                <div style={{ marginLeft: '30px', marginTop: '10px' }}>
                    {/* {!allPractitioner ? <Registration /> : <PractitionerDetails cardData={cardData} pageNo={pageNo} pageCount={pageCount} handlePageChange={handlePageChange} />} */}

                    {!allPractitioner ? <RegistrationPractitioner handleAllPractitionerChange={handleAllPractitionerChange} /> : <PractitionerDetails cardData={cardData} pageNo={pageNo} pageCount={pageCount} handlePageChange={handlePageChange} />}
                </div>
            </div>
        </div>
        </>
  )
}

/**
 * The `MsalAuthenticationTemplate` component will render its children if a user is authenticated
 * or attempt to sign a user in. Just provide it with the interaction type you would like to use
 * (redirect or popup) and optionally a [request object](https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/request-response-object.md)
 * to be passed to the login API, a component to display while authentication is in progress or a component to display if an error occurs. For more, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-react/docs/getting-started.md
 */
export const Practitioners = () => {
  const authRequest = {
    ...loginRequest
  }

  return (
        <MsalAuthenticationTemplate
            interactionType={InteractionType.Redirect}
            authenticationRequest={authRequest}
        >
            <PractitionerContent />
        </MsalAuthenticationTemplate>
  )
}
