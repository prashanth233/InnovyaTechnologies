/* eslint-disable array-callback-return */
import React, { useState, useEffect } from 'react'
// import axios from "axios";
import moment from 'moment'
import { useMsal, useAccount } from '@azure/msal-react'
import '../styles/App.css'

import { TableComponent } from '../components/TableComponent'
import { practitionerColumns, coordinatorColumns, patientsColumns, coordinatorAppointmentFilter, practitionerAppointmentFilter } from '../CommonData/Data'
import SearchComponent from '../components/SearchComponent'
import { ListGroup } from 'react-bootstrap'
import { callApiForListing, callApiForUpdate } from '../fetch'
import { ClientAppointments, AppointmentsCommonUrl } from '../CommonData/APIListing'
import { AskModalPopUp, JoinModalPopUp, LoaderModalPopUp } from '../CommonData/ModalPopUp'
import { NoAppointmentFound } from '../CommonData/WorkInProgress'
import { getNextMonthsDate, getNextWeeksDate, getTodaysDate, getCustomSelectedDate, showJoinOption, getTodaysFromDate, getNextWeeksFromDate, getNextMonthsFromDate, getCustomSelectedFromDate } from '../CommonData/CommonFunction'
import { useHistory } from 'react-router-dom'
import PropTypes from 'prop-types'
import { Stack } from '@mui/material'
import { createCoordinatorAppointmentsUrl } from '../CommonData/CreateAPIUrl'

const AppointmentListGroup = ({ appointmentFilter, selectd, isPastAppointment, handleCalendarChange, errorDate }) => {
  const value1 = document.getElementById('byDate') && document.getElementById('byDate').value
  const curreDate = moment(new Date()).format('MM/DD/YYYY')
  const inputDate = moment(new Date(value1)).format('MM/DD/YYYY')
  const isPastDate = new Date(curreDate).getTime() <= new Date(inputDate).getTime()
  // console.log('byDate::', value1, isPastDate)

  return (
    <>
      <div className="ml-auto">
        {
          errorDate && (
            <div style={{ color: 'red', marginTop: '-1vw', fontFamily: 'Roboto, Regular', fontSize: '12px' }} >
              { !isPastDate ? 'Please select future date' : 'Please select proper date'}
            </div>
          )
        }
        <div style={{ marginTop: '1vh', fontFamily: 'Roboto, Regular', fontSize: '14px' }} >
          <label style={{ marginTop: '2.5vh', marginRight: '1vw', color: '#6A6A6A' }}>By Date: </label>
          <input type="date" id="byDate" name="byDate" onChange={handleCalendarChange}
          ></input>
        </div>
      </div>

      <div>
        <ListGroup horizontal active="#link2" style={{ marginTop: 7, fontFamily: 'Roboto', fontSize: '0.875em', color: '#139ED7', border: '1px solid #139ED7', borderRadius: 5 }}>
          <ListGroup.Item active={selectd === 'today'} id="today" onClick={appointmentFilter} >Today</ListGroup.Item>
          <ListGroup.Item active={selectd === 'week'} id="week" onClick={appointmentFilter} >{isPastAppointment ? 'Last Week' : 'This Week'}</ListGroup.Item>
          <ListGroup.Item active={selectd === 'month'} id="month" onClick={appointmentFilter} >{isPastAppointment ? 'Last Month' : 'This Month'}</ListGroup.Item>
          <ListGroup.Item active={selectd === 'all'} id="all" onClick={appointmentFilter} >All</ListGroup.Item>
        </ListGroup>
      </div>

    </>)
}
AppointmentListGroup.propTypes = {
  selectd: PropTypes.string,
  isPastAppointment: PropTypes.bool,
  errorDate: PropTypes.bool,
  appointmentFilter: PropTypes.func.isRequired,
  handleCalendarChange: PropTypes.func.isRequired

}

export const AppointmentsListing = ({ isPastAppointment, viewAppointmentClicked, handleEditAppointment, handleFirstAppointmentData, appointmentFilterData }) => {
  const currentRole = JSON.parse(localStorage.getItem('UserType'))
  // const [isVideoStarted, setIsVideoStarted] = useState(false)
  const history = useHistory()

  let columns = []
  let filterArrData = []
  switch (currentRole) {
    case 'Coordinator':
      columns = coordinatorColumns
      filterArrData = coordinatorAppointmentFilter
      break
    case 'Practitioner':
      columns = practitionerColumns
      filterArrData = practitionerAppointmentFilter
      break
    case 'Client':
      columns = patientsColumns
      break

    default:
      columns = patientsColumns
      break
  }

  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})

  const [isAPICalling, setisAPICalling] = useState(false)

  // const [cardData, setCardData] = useState(data);
  // const [cardDataDefault, setcardDataDefault] = useState(data);

  const [cardData, setCardData] = useState([])
  const [cardDataDefault, setcardDataDefault] = useState([])

  const [show, setShow] = useState(false)
  const [showModalPopUp, setShowModalPopUp] = useState(false)
  const [showAskModalPopUp, setShowAskModalPopUp] = useState(false)
  const [headerMessage, setHeaderMessage] = useState('')
  const [cancelApptId, setCancelApptId] = useState('')

  const [messageData, setMessageData] = useState('')

  // For Today, This Month , This week, All related
  const [selectd, setSelectd] = useState(appointmentFilterData)

  // For By Date filter
  const [byDate, setByDate] = useState('')
  const [errorDate, setErrorDate] = useState(false)

  const appointmentFilter = (e) => {
    // console.log("Clicked", e.target.id);
    setSelectd(e.target.id)
    setByDate('')
    setSearchData('')
  }

  // Calendar Change
  const handleCalendarChange = (e) => {
    const curreYaer = new Date().getFullYear()
    const inputYaer = new Date(e.target.value).getFullYear()

    const curreDate = moment(new Date()).format('MM/DD/YYYY')
    const inputDate = moment(new Date(e.target.value)).format('MM/DD/YYYY')
    // console.log('Calendar date input::', curreDate, inputDate, inputYaer, curreYaer, curreYaer <= inputYaer, new Date(curreDate).getTime() <= new Date(inputDate).getTime())

    if ((e.target.value === '') || (curreYaer <= inputYaer && new Date(curreDate).getTime() <= new Date(inputDate).getTime() && inputYaer < 9999)) {
      setByDate(e.target.value)

      const type = e.target.value === '' ? 'all' : e.target.id
      setSelectd(type)
      setErrorDate(false)
    } else {
      setErrorDate(true)
    }
  }

  /// /////

  // Search and Filter related
  const [searchData, setSearchData] = useState('')
  const [searchKey, setSearchKey] = useState('clientName')
  const [filterName, setFilterName] = useState('Filter')

  const handleSearch = (event) => {
    // console.log('Handle search key:-', searchKey, event.target.id)
    const searchValue = event.target.id === 'clear' ? '' : event.target.value
    // console.log('Handle search value:-', searchValue)
    const searchedCards = cardDataDefault.filter((item) => {
      // console.log('item.searchkey::', item, item[searchKey])
      return Object.values(item[searchKey]).join('').toLowerCase().includes(searchValue && searchValue.toLowerCase())
    })
    // console.log("Searched Result=:", searchedCards);
    // setPageNo(1)
    // handlePagination(searchedCards)
    setCardData(searchValue === '' ? cardDataDefault : searchedCards)
    setSearchData(searchValue)
  }

  const handleFilterChange = (event) => {
    if (event.target.id !== 'filter') {
      // console.log('inside if handleFilterChange::')

      const filterNameValue = event.target.name === '' ? filterName : event.target.name
      setFilterName(filterNameValue)
      setSearchKey(event.target.id)
    }
    setShow(!show)
  }
  /// //////
  /// Client Appointments
  const getClientAppointmentUrl = () => {
    const currentDate = getTodaysDate()
    const currentFromDate = getTodaysFromDate()

    const userId = account && account.idTokenClaims.sub
    const tenantId = account.idTokenClaims.extension_Organization
    const userData = JSON.parse(localStorage.getItem('UserData'))
    const currentRole = JSON.parse(localStorage.getItem('UserType'))

    const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName

    const url = isPastAppointment ? `${tenantId}/${practiceName}/appointments/patient/${userId}?todate=${currentDate}` : `${tenantId}/${practiceName}/appointments/patient/${userId}?fromdate=${currentFromDate}`

    return url
  }
  /// //

  const getAppointmentUrl = (type) => {
    // pratitionerAppointmentType = "past"
    // console.log('getAppointmentUrl account::', account)
    const tenantId = account.idTokenClaims.extension_Organization
    const userData = JSON.parse(localStorage.getItem('UserData'))
    const currentRole = JSON.parse(localStorage.getItem('UserType'))

    const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName
    const practId = account && account.idTokenClaims.sub
    const practType = isPastAppointment ? `&todate=${getTodaysDate()}Z` : `&fromdate=${getTodaysFromDate()}Z`

    let url = `${tenantId}/${practiceName}/appointments`

    const forWeek = isPastAppointment ? `${url}?todate=${getTodaysDate()}Z&fromdate=${getNextWeeksFromDate(isPastAppointment)}Z` : `${url}?fromdate=${getTodaysFromDate()}Z&todate=${getNextWeeksDate(isPastAppointment)}Z`

    const forMonth = isPastAppointment ? `${url}?todate=${getTodaysDate()}Z&fromdate=${getNextMonthsFromDate(isPastAppointment)}Z` : `${url}?fromdate=${getTodaysFromDate()}Z&todate=${getNextMonthsDate(isPastAppointment)}Z`

    switch (type) {
      case 'today':
        url = currentRole === 'Coordinator' ? `${url}?fromdate=${getTodaysFromDate()}Z&todate=${getTodaysDate()}Z` : `${url}?fromdate=${getTodaysFromDate()}Z&todate=${getTodaysDate()}Z&practitionerId=${practId}`

        break
      case 'week':
        url = currentRole === 'Coordinator' ? `${url}?fromdate=${getTodaysFromDate()}Z&todate=${getNextWeeksDate(isPastAppointment)}Z` : `${forWeek}&practitionerId=${practId}`

        break
      case 'month':
        url = currentRole === 'Coordinator' ? `${url}?fromdate=${getTodaysFromDate()}Z&todate=${getNextMonthsDate(isPastAppointment)}Z` : `${forMonth}&practitionerId=${practId}`

        break
      case 'all':
        url = currentRole === 'Coordinator' ? url : `${url}?practitionerId=${practId}${practType}`

        break
      case 'byDate':
        url = currentRole === 'Coordinator' ? `${url}?fromdate=${getCustomSelectedFromDate(byDate)}Z&todate=${getCustomSelectedDate(byDate)}Z` : `${url}?fromdate=${getCustomSelectedFromDate(byDate)}Z&todate=${getCustomSelectedDate(byDate)}Z&practitionerId=${practId}`

        break

      default:
        url = currentRole === 'Coordinator' ? '' : `?practitionerId=${practId}${practType}`

        break
    }

    return url
  }

  const getAllAppointmentsListing = () => {
    // getClientAppointmentUrl

    const appointmentUrl = currentRole === 'Client' ? `${ClientAppointments}${getClientAppointmentUrl()}` : `${ClientAppointments}${getAppointmentUrl(selectd)}`

    setisAPICalling(true)
    setHeaderMessage('Fetching Appointments...')
    setCancelApptId('')

    callApiForListing(appointmentUrl)
      .then((response) => {
        setisAPICalling(false)

        try {
          const finalResp = response && typeof (response) === 'object' ? response : []
          const sortedRespData = isPastAppointment ? [...finalResp].sort((a, b) => Date.parse(new Date(a.meetingStartDateTime)) - Date.parse(new Date(b.meetingStartDateTime))).reverse() : [...finalResp].sort((a, b) => Date.parse(new Date(a.meetingStartDateTime)) - Date.parse(new Date(b.meetingStartDateTime)))
          // console.log('SortedResp::', sortedRespData)

          if (finalResp.length) {
            finalResp.map(obj => {
              obj.meetingStatus = obj.status
              obj.meetingDateTime = `${obj.meetingStartDateTime};${obj.meetingEndDateTime}`
              obj.meetingAssessmentStatus = `${obj.assessmentStatus};${obj.assessmentPendingCount}`
              obj.meetingDateTimeStatus = `${obj.meetingDateTime};${obj.meetingStatus}`
            })
            handleFirstAppointmentData(finalResp[0])
          } else {
            handleFirstAppointmentData({})
          }
          if (currentRole === 'Client') {
            const apptData = finalResp.length > 0 ? finalResp[0] : {}
            finalResp.length > 0 && localStorage.setItem('AppointmentDetails', JSON.stringify(apptData))
          }
          setcardDataDefault(selectd === 'all' && currentRole !== 'Client' ? finalResp : sortedRespData)
          setCardData(selectd === 'all' && currentRole !== 'Client' ? finalResp : sortedRespData)
        } catch (e) {
          console.warn(`Fetch 2 error: ${e.message}`)
        }
      })
  }

  // Table Column Button View Details Click handler
  const onRowClicked = (row, e) => {
    // console.log('table row event Data::', row.original, e.target.id, e.target.innerText)
    // if(e.target.nodeName === "BUTTON"){
    if (e.target.id === 'details' || e.target.id === 'activities' || e.target.id === 'assessments') {
      const tabSelect = e.target.id === 'details' ? 'activities' : e.target.id
      // console.log("table row Data::", row, row.index);
      viewAppointmentClicked(row.original, tabSelect)
    } else if (e.target.id === 'join') {
      const show = showJoinOption(row.original.meetingStartDateTime, row.original.meetingEndDateTime)

      if (show && row.original.status === 'Scheduled') {
        history.push('/sessionactivities', { apptDet: row.original, comingForView: false })
        window.location.reload(false)
        // getAgoraTokenCall(row.original)
      } else {
        const message = isPastAppointment ? "This meeting is already completed or cancelled. You can't join this." : 'This meeting is not started yet or cancelled. Please join accordingly.'
        setShowModalPopUp(true)
        setMessageData(message)
      }
    } else if (e.target.id === 'view') {
      history.push('/sessionactivities', { apptDet: row.original, comingForView: true })
      window.location.reload(false)
    } else if (e.target.id === 'cancel') {
      setShowAskModalPopUp(true)
      setCancelApptId(row.original.appointmentId)
      // cancelAppointmentCall(row.original.appointmentId)
    } else if (e.target.id === 'edit') {
      handleEditAppointment(row.original)
    }
    // }handleEditAppointment
  }
  /// //////

  /// Join Modal Popup code
  const handleModalPopUp = () => {
    setShowModalPopUp(false)
  }
  /// //

  // Cancel Appointment Permission Modal
  const handleAskModalPopUp = (e) => {
    // console.log('handleAskModalPopUp::', e && e.target && e.target.id)
    setShowAskModalPopUp(false)
    if (e && e.target && e.target.id === 'yes') {
      cancelAppointmentCall(cancelApptId)
    }

    // cancelAppointmentCall(row.original.appointmentId)
  }

  // Cancel Appointment API Call

  const cancelAppointmentCall = (apptId) => {
    setisAPICalling(true)
    setHeaderMessage('Cancelling Appointment...')
    const tempUrl = `${createCoordinatorAppointmentsUrl(account, AppointmentsCommonUrl)}/${apptId}?status=Cancelled`

    callApiForUpdate(tempUrl, {})
      .then((response) => {
        setisAPICalling(false)
        // console.log('Cancel Appt response::', response)
        getAllAppointmentsListing()
        setCancelApptId('')
      })
  }

  // Cancel API call ends

  useEffect(() => {
    setSelectd(appointmentFilterData)
  }, [appointmentFilterData])

  useEffect(() => {
    getAllAppointmentsListing()
  }, [selectd, isPastAppointment, byDate])

  return (
    <>
      <AskModalPopUp show={showAskModalPopUp} handleAskModalPopUp={handleAskModalPopUp} />
      <LoaderModalPopUp show={isAPICalling} message={headerMessage} />
      <JoinModalPopUp show={showModalPopUp} handleModalPopUp={handleModalPopUp} message={messageData} />
      <div>
        {
          currentRole !== 'Client' && (
            <Stack direction="horizontal" gap={2} style={{
              marginRight: '30px', marginTop: '47px', marginLeft: '2px'
            }}>
              <SearchComponent filterArr={filterArrData} onSearchClick={handleSearch} searchValue={searchData} handleFilterChange={handleFilterChange} filterName={filterName} />
              <AppointmentListGroup selectd={selectd} appointmentFilter={appointmentFilter} byDate={byDate} isPastAppointment={isPastAppointment} handleCalendarChange={handleCalendarChange} errorDate={errorDate}></AppointmentListGroup>
            </Stack>
          )
        }
        <div style={{ padding: '33px 23px 11px 11px' }} >
          {
            cardData && cardData.length
              ? (<TableComponent columns={columns} data={cardData} onRowClicked={onRowClicked} showHeader={true} tableWidth="95.5vw" />)
              : (<NoAppointmentFound></NoAppointmentFound>)
          }
        </div>
      </div>
    </>
  )
}
AppointmentsListing.propTypes = {
  isPastAppointment: PropTypes.bool,
  viewAppointmentClicked: PropTypes.func,
  handleEditAppointment: PropTypes.func.isRequired,
  handleFirstAppointmentData: PropTypes.func.isRequired,
  appointmentFilterData: PropTypes.string
}
