import { Divider } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { Button, FormControl, InputGroup } from 'react-bootstrap'
import { useMsal, useAccount } from '@azure/msal-react'
import '../styles/App.css'
import { LoaderModalPopUp, ModalPopUp } from '../CommonData/ModalPopUp'
import { callApiForListing, callApiForRegistration } from '../fetch'
import moment from 'moment'
import { GetPractitionerNotes } from '../CommonData/APIListing'
import PropTypes from 'prop-types'
import Loader from './Loader'
import { savePractitionerNotesUrl } from '../CommonData/CreateAPIUrl'

export const NotesSection = ({ userId, comingFrom, appointmentDetail }) => {
  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})

  const [showModal, setShowModal] = useState(false)
  const [showErrorModal, setShowErrorModal] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')
  const [headerMessage, setHeaderMessage] = useState('')

  const [isAPICalling, setIsAPICalling] = useState(false)
  const [notesData, setNotesData] = useState('')
  const [notesListData, setNotesListData] = useState([])

  const handleDataChange = (e) => {
    const { value } = e.target
    // console.log('Data Values:', value)

    setNotesData(value)
  }

  const saveNotesData = () => {
    setIsAPICalling(true)
    setHeaderMessage('Saving notes data...')
    const tenantId = account.idTokenClaims.extension_Organization
    const userData = JSON.parse(localStorage.getItem('UserData'))

    const practiceName = userData && userData.practiceName
    // const practiceName = account.idTokenClaims.extension_PracticeName
    const dateData = `${moment(new Date()).format('yyyy-MM-DDTHH:mm:ss.SSS')}Z`
    const submitNotes = {
      id: '',
      description: notesData,
      notesDateTime: dateData,
      clientId: userId,
      practitionerId: account.idTokenClaims.sub,
      tenantId: tenantId,
      practiceName: practiceName
    }
    // console.log('submitNotes::', submitNotes)

    const saveNotesUrl = savePractitionerNotesUrl(account, GetPractitionerNotes)
    callApiForRegistration(saveNotesUrl, submitNotes)
      .then((response) => {
        setIsAPICalling(false)
        if (response && response === 'Notes added successfully') {
          setShowModal(true)
          setNotesData('')
        } else {
          setShowErrorModal(true)
        }
        setErrorMessage(response)
      })
      .catch(error => console.log('API Catch eror main class', error))
  }

  const handleModalPopUp = () => {
    setShowModal(!showModal)
  }
  const handleErrorModalPopUp = () => {
    setShowErrorModal(false)
  }

  const getNotesListing = () => {
    setIsAPICalling(true)
    // setHeaderMessage('Fetching notes data...')

    const tenantId = account.idTokenClaims.extension_Organization
    const userData = JSON.parse(localStorage.getItem('UserData'))
    const currentRole = JSON.parse(localStorage.getItem('UserType'))

    const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName
    const practitionerId = account.idTokenClaims.sub
    const notesList = `${GetPractitionerNotes}${tenantId}/${practiceName}/notes?clientId=${appointmentDetail && appointmentDetail.clientId}&practitionerId=${practitionerId}`

    callApiForListing(notesList)
      .then((response) => {
        const finalResp = response && typeof (response) === 'object' ? response : []
        setNotesListData(finalResp)
        setIsAPICalling(false)
      })
  }

  useEffect(() => {
    // console.log('Inside separate useEffect');
    if (comingFrom === 'overview') {
      getNotesListing()
    }
  }, [appointmentDetail && appointmentDetail.clientId])

  const headerLabel = <p style={{ fontFamily: 'Roboto', fontSize: '14px', color: '#9E9E9E' }}>Today | <span style={{ fontSize: '14px', color: 'black' }}>{moment(new Date()).format('MMM DD, yyyy')}</span> </p>
  return (
    <div style={{ border: '1px solid #EEEEEE', borderRadius: 5 }}>
      {
        isAPICalling && comingFrom === 'overview'
          ? (
            <Loader />
            )
          : (
            <>
              {
                comingFrom !== 'overview' && (
                  <LoaderModalPopUp show={isAPICalling} message={headerMessage} />

                )
              }
              <ModalPopUp handleModalPopUp={handleModalPopUp} show={showModal} header="Notes" messageBody={errorMessage} />
              <ModalPopUp handleModalPopUp={handleErrorModalPopUp} show={showErrorModal} header="Error!" messageBody={errorMessage} />

              <div style={{ padding: '10px', color: '#2D2D34' }} >
                {
                  comingFrom === 'overview'
                    ? (
                      <div className='notesDiv'>
                        <NotesGenres values={notesListData} ></NotesGenres>
                      </div>
                      )
                    : (
                      <>
                        <div style={{ textAlign: 'right' }} >
                          {headerLabel}
                        </div>
                        <div style={{ padding: '0px 0px 20px 0px' }} >
                          <InputGroup style={{ height: '214px' }}>
                            <FormControl as="textarea" aria-label="With textarea" value={notesData} onChange={handleDataChange} />
                          </InputGroup>
                        </div>
                        <Divider></Divider>
                        <div style={{ textAlign: 'right', paddingTop: '20px' }} >
                          <Button style={{ backgroundColor: '#F24B5D', borderRadius: '5px', border: 'none', color: 'white' }} onClick={saveNotesData} disabled={notesData.length === 0} >SAVE</Button>
                        </div>
                      </>
                      )
                }
              </div>
            </>
            )
      }

    </div>
  )
}
NotesSection.propTypes = {
  userId: PropTypes.string,
  comingFrom: PropTypes.string,
  appointmentDetail: PropTypes.object
}

const NotesGenres = ({ values }) => {
  return (
    <>
      {values.map((notes, idx) => {
        return (
          <div key={idx} style={{ padding: '5px', fontFamily: 'Roboto, Regular' }}>
            <label style={{ fontSize: '14px', color: '#9E9E9E' }}>Appointment on :  <span style={{ fontSize: '14px', color: '#2D2D34', marginLeft: '10px' }}>{moment(notes.notesDateTime).format('MMM DD, yyyy')}</span> </label>
            <p style={{ fontSize: '15px', color: '#2D2D34', fontWeight: '500' }}>Note - <span style={{ fontSize: '15px', color: '#2D2D34', marginLeft: '0px', fontWeight: '400' }}>{notes.description}</span> </p>
          </div>
        )
      })}
    </>
  )
}
NotesGenres.propTypes = {
  values: PropTypes.array
}
