import React from 'react'
import { useMsal } from '@azure/msal-react'
import { loginRequest } from '../authConfig'

function HomePage () {
  const { instance } = useMsal()

  return (
    <div className='App'>
      <div style={{ textAlign: 'center' }}>
      Please Select your role
      </div>
     <button onClick={() => instance.loginRedirect(loginRequest)}>Clicl Me</button>
    </div>
  )
}

export default HomePage
