/* eslint-disable array-callback-return */
import React, { useEffect, useState } from 'react'

import { MsalAuthenticationTemplate, useMsal, useAccount } from '@azure/msal-react'
import { InteractionType } from '@azure/msal-browser'
import calImg from '../Assets/Calendar.png'
import calRemImg from '../Assets/calendarremove.png'
import accCirImg from '../Assets/accountcircle.png'
import fileDocImg from '../Assets/filedocument.png'
import notesImg from '../Assets/notes.png'
import { loginRequest } from '../authConfig'
import PractitionerOverview from '../Cards/PractitionerOverview'
import moment from 'moment'
import { Image, Row } from 'react-bootstrap'
import { TodaysAppointment } from './TodaysAppointment'
import { AppointmentSummary } from './AppointmentSummary'
import { NotesSection } from './NotesSection'
import { useHistory } from 'react-router-dom'
import { LoaderModalPopUp, ModalPopUp } from '../CommonData/ModalPopUp'
import { ClientAppointments, ProviderBaseUrl } from '../CommonData/APIListing'
import { callApiForListing } from '../fetch'
import { getTodaysDate, getTodaysFromDate } from '../CommonData/CommonFunction'

const cardData = [{ img: calImg, title: "TODAY'S APPOINTMENTS", value: '', subTitle: '/10', bgColor: '#FFF8E5' }, { img: calImg, title: 'ALL APPOINTMENTS', value: '', subTitle: 'in the past month', bgColor: '#EAF8FE' }, { img: calRemImg, title: 'CANCELLED APPOINTMENTS', value: '', subTitle: 'in the past month', bgColor: '#F3F3F3' }, { img: accCirImg, title: 'NEW PATIENTS', value: '', subTitle: 'in the past month', bgColor: '#F3F6FF' }]

const OverviewContent = () => {
  const history = useHistory()
  const isMounted = React.useRef(true)

  const { accounts, instance } = useMsal()
  const account = useAccount(accounts[0] || {})
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const [showLogOutErrorModal, setShowLogOutErrorModal] = useState(false)

  const [isAPICalling, setisAPICalling] = useState(false)
  const [todaysAPICalling, setTodaysAPICalling] = useState(false)

  const [selectedId, setSelectedId] = useState(-1)
  const [time, setTime] = useState(moment(new Date()).format('hh:mm A'))

  const [appointmentsData, setAppointmentsData] = useState([])

  const getTodaysAppointmentListing = () => {
    // setIsAPICalling(true)
    // setHeaderMessage('Fetching appointments data...')

    const tenantId = account.idTokenClaims.extension_Organization
    const userData = JSON.parse(localStorage.getItem('UserData'))
    const currentRole = JSON.parse(localStorage.getItem('UserType'))

    const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName
    const practitionerId = account.idTokenClaims.sub
    const url = `${tenantId}/${practiceName}/appointments?fromdate=${getTodaysFromDate()}Z&todate=${getTodaysDate()}Z&practitionerId=${practitionerId}`

    const appointmentUrl = `${ClientAppointments}${url}`

    setTodaysAPICalling(true)

    callApiForListing(appointmentUrl)
      .then((response) => {
        // console.log('getTodaysAppointment Listing API Resp:-', response)
        const finalResp = response && typeof (response) === 'object' ? response : []
        const sortedRespData = [...finalResp].sort((a, b) => Date.parse(new Date(a.meetingStartDateTime)) - Date.parse(new Date(b.meetingStartDateTime)))
        if (isMounted.current) {
          setTodaysAPICalling(false)
          setAppointmentsData(sortedRespData)
        }
      })
  }

  const getAppointmentCardsListing = () => {
    setisAPICalling(true)
    const tenantId = account.idTokenClaims.extension_Organization
    const userData = JSON.parse(localStorage.getItem('UserData'))
    const currentRole = JSON.parse(localStorage.getItem('UserType'))

    const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName
    const practitionerId = account.idTokenClaims.sub
    const appointmentCardsList = `${ProviderBaseUrl}${tenantId}/${practiceName}/providers/${practitionerId}/summary`

    callApiForListing(appointmentCardsList)
      .then((response) => {
        const finalResp = response && typeof (response) === 'object' ? response : {}

        if (finalResp.todaysAppointmentCount >= 0) {
          cardData.map((obj, i) => {
            obj.value = i === 0 ? finalResp.todaysAppointmentCount : i === 1 ? finalResp.allAppointmentCount : i === 2 ? finalResp.cancelledAppointmentCount : finalResp.newPatientCount
          })
        }
        setisAPICalling(false)
      })
  }
  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])
  useEffect(() => {
    // console.log('Inside separate useEffect');
    getTodaysAppointmentListing()
    getAppointmentCardsListing()
  }, [])
  useEffect(() => {
    const interval = setInterval(() => setTime(moment(new Date()).format('hh:mm A')), 1000)
    return () => {
      clearInterval(interval)
    }
  }, [])

  // This useeffect is used to check if any other user is logged in in other tab or not
  useEffect(() => {
    if (account.idTokenClaims.sub !== userData.id) {
      setShowLogOutErrorModal(true)
    }
  })
  const logOutUser = () => {
    // localStorage.clear()
    instance.logoutRedirect({ postLogoutRedirectUri: '/' })
  }

  const viewAllHandler = (e) => {
    const { id } = e.target
    // console.log('id data overview', id, e.target)
    if (id === '3') {
      history.push('/clients')
      window.location.reload('false')
    } else if (id === 'today' || id === '0') {
      history.push('/appointments', { apptFilter: 'today' })
      window.location.reload('false')
    } else { history.push('/appointments') }
    window.location.reload('false')
  }
  const viewAppointmentDetails = () => {
    // console.log("Client profile A/ppt Details::", obj, tabSelected);
    history.push('/appointments', { apptDet: appointmentsData[selectedId], tabSelected: 'activities' })
    window.location.reload('false')
  }

  const generSelected = (e) => {
    // console.log('setSelectedId::', e.target.id)
    setSelectedId(e.target.id)
  }

  const dateData = moment(new Date()).format('dddd, D MMMM YYYY')
  return (
    <>
      <LoaderModalPopUp show={isAPICalling} message='Fetching Appointment Cards Data...' />
      <ModalPopUp handleModalPopUp={logOutUser} show={showLogOutErrorModal} header="Error!" messageBody='Another user is logged in. You will be logout' />

      <div style={{ fontFamily: 'Roboto, Regular', fontSize: '12px', textAlign: 'right', padding: '10px 20px 20px 0px', height: 50 }}>
        {`${dateData} | ${time}`}
      </div>
      <PractitionerOverview cardData={cardData} viewAllHandler={viewAllHandler} />

      <div style={{ backgroundColor: '#FFF5F6' }}>

        <div style={{ marginTop: '-55px', backgroundColor: '#FFF5F6' }}>
          <br />
          <div style={{ margin: '50px 20px', backgroundColor: 'white', borderRadius: 12 }}>
            <Row style={{ padding: '10px 20px 20px 20px' }}>
              <div style={{ width: '35vw', padding: '10px' }} >
                <div style={{ fontFamily: 'Roboto, light', fontSize: '20px', display: 'flex', justifyContent: 'space-between' }}>
                  <div>
                    <Image style={{ marginTop: '-3px', width: '24px', height: '24px' }} src={calImg} />
                    <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto, Light', fontSize: '20px', color: '#139ED7' }}>{"Today's Appointments"}</label>
                  </div>
                  <div>
                    <button id='today' style={{ backgroundColor: 'white', color: '#F24B5D', border: 'none', fontFamily: 'Roboto, Medium', fontSize: '14px', marginLeft: '15px' }} onClick={viewAllHandler}>
                      VIEW ALL
                    </button>
                  </div>
                </div>
                <TodaysAppointment selectedId={selectedId} generSelected={generSelected} isAPICalling={todaysAPICalling} appointmentsData={appointmentsData}></TodaysAppointment>
              </div>
              <div style={{ width: '58vw', padding: '10px' }}>
                <div>
                  <div style={{ fontFamily: 'Roboto, light', fontSize: '20px' }}>
                    <div>
                      <Image style={{ marginTop: '-3px', width: '24px', height: '24px' }} src={fileDocImg} />
                      <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto, Light', fontSize: '20px', color: '#139ED7' }}>Appointment Summary</label>
                    </div>
                  </div>
                  {
                    selectedId !== -1 && (
                      <AppointmentSummary handleViewDetails={viewAppointmentDetails} appointmentDetail={appointmentsData[selectedId]}></AppointmentSummary>
                    )
                  }
                </div>
                <div>
                  <div style={{ fontFamily: 'Roboto, light', fontSize: '20px', paddingTop: '30px' }}>
                    <div>
                      <Image style={{ marginTop: '-3px', width: '24px', height: '24px' }} src={notesImg} />
                      <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto, Light', fontSize: '20px', color: '#139ED7' }}>Notes</label>
                    </div>
                  </div>
                  {
                    selectedId !== -1 && (
                      <NotesSection comingFrom='overview' viewAllHandler={viewAllHandler} appointmentDetail={appointmentsData[selectedId]}></NotesSection>
                    )
                  }
                </div>
              </div>
            </Row>
          </div>
          <br />
        </div>
      </div>
    </>

  )
}

/**
 * The `MsalAuthenticationTemplate` component will render its children if a user is authenticated
 * or attempt to sign a user in. Just provide it with the interaction type you would like to use
 * (redirect or popup) and optionally a [request object](https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/request-response-object.md)
 * to be passed to the login API, a component to display while authentication is in progress or a component to display if an error occurs. For more, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-react/docs/getting-started.md
 */
export const Overview = () => {
  const authRequest = {
    ...loginRequest
  }

  return (
    <MsalAuthenticationTemplate
      interactionType={InteractionType.Redirect}
      authenticationRequest={authRequest}
    >
      <OverviewContent />
    </MsalAuthenticationTemplate>
  )
}
