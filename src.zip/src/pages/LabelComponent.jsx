import { Form } from 'react-bootstrap'
import React from 'react'
import PropTypes from 'prop-types'

export const LabelComponent = ({ name }) => {
  return (
        <Form.Label style={{ fontFamily: 'Roboto', fontSize: '14px' }}>{name}</Form.Label>
  )
}
LabelComponent.propTypes = {
  name: PropTypes.string
}

export const LabelComponentRequired = ({ name }) => {
  return (
        <Form.Label style={{ fontFamily: 'Roboto', fontSize: '14px' }}>{name}<span style={{ color: '#F24B5D' }}>*</span></Form.Label>
  )
}

LabelComponentRequired.propTypes = {
  name: PropTypes.string
}

export const LabelHeaderComponent = ({ name }) => {
  return (
        <Form.Label style={{ marginLeft: '-10px', fontFamily: 'Roboto', fontSize: '18px' }}>{name}</Form.Label>
  )
}

LabelHeaderComponent.propTypes = {
  name: PropTypes.string
}

export const LabelHeaderComponentRequired = ({ name }) => {
  return (
        <Form.Label style={{ marginLeft: '-10px', fontFamily: 'Roboto', fontSize: '18px' }}>{name}<span style={{ color: '#F24B5D' }}>*</span></Form.Label>
  )
}
LabelHeaderComponentRequired.propTypes = {
  name: PropTypes.string
}
