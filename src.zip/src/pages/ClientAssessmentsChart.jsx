import React, { useEffect, useState } from 'react'
import { useMsal, useAccount } from '@azure/msal-react'
import '../styles/App.css'
import { colorCode, viewGraphFrequency } from '../CommonData/Data'
import PropTypes from 'prop-types'
import { getDateWithFormat, getFutureDateWithFormat } from '../CommonData/CommonFunction'
import Loader from './Loader'
import { ClientAssessmentsBaseUrl } from '../CommonData/APIListing'
import { callApiForListing } from '../fetch'
// import { Form } from 'react-bootstrap'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'
import { Line } from 'react-chartjs-2'
import { createClientAssessmentsListingUrl } from '../CommonData/CreateAPIUrl'
import { AssessmentsChartModal } from '../CommonData/ModalPopUp'
// import moment from 'moment'
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
)

export const ClientAssessmentsChart = ({ clientUserId, comingFrom }) => {
  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})
  const [dropDownData, setDropDownData] = useState('Weekly')
  const [data, setData] = useState({})
  const [isAPICalling, setIsAPICalling] = useState(false)
  const [isFullScreen, setIsFullScreen] = useState(false)

  const options = {
    responsive: true,
    scales: { // <-- Note change in options from scale to scales
      yAxis: {
        beginAtZero: true
      }
    },
    maintainAspectRatio: false
  }

  const handleDataChange = (e) => {
    // console.log('handleDataChange', e.target)
    const interval = e.target.value
    setDropDownData(interval)
    getClientLongitudinalData(interval === 'Weekly' ? 7 : interval === 'Monthly' ? 30 : 364)
  }
  const getClientLongitudinalData = (interval) => {
    setIsAPICalling(true)
    // setHeaderMessage('Fetching appointments data...')
    const url = `${createClientAssessmentsListingUrl(account, ClientAssessmentsBaseUrl)}${clientUserId}/wellbeingProfileChart?fromdate=${getFutureDateWithFormat(-interval, 'yyyy-MM-DDTHH:mm:ss.SSS')}Z&todate=${getFutureDateWithFormat(0, 'yyyy-MM-DDTHH:mm:ss.SSS')}Z`
    // Note:: In this chart, when there will be data submission for same date and same assessments then we will take latest data entry and not all the entries data.

    callApiForListing(url)
      .then((response) => {
        const finalResp = response && typeof (response) === 'object' ? response : []

        const sortedRespData = [...finalResp].sort((a, b) => Date.parse(new Date(a.assessmentSubmittedDate)) - Date.parse(new Date(b.assessmentSubmittedDate)))
        setIsAPICalling(false)
        const personGroupedByName = groupByData(sortedRespData, 'assessmentName')
        const labelsData = finalResp.map(obj => getDateWithFormat(obj.assessmentSubmittedDate, 'MM/DD/YY'))

        const finalLabelsData = [...new Set(labelsData.reverse())]
        // console.log('finalLabelsData data', finalLabelsData)

        const finalDataSet = []

        for (const key in personGroupedByName) {
          const index = Object.keys(personGroupedByName).indexOf(key)

          const valueData = personGroupedByName[key].map(obj => obj.score).reverse()
          const datesData = personGroupedByName[key].map(obj => getDateWithFormat(obj.assessmentSubmittedDate, 'MM/DD/YY')).reverse()
          // const copyData = [...valueData].reverse()

          // console.log('values reverse datesData initial data', valueData, datesData)

          // Copying data of Values in another array for calculation
          let valueArrData = [...valueData]
          for (let i = 0; i < valueData.length; i++) {
            // Checking if the value of date is same or what. If same date data then we are taking latest date value and others removing
            if (i > 0 && datesData[i] === datesData[i - 1]) {
              valueArrData.splice(i, 1, NaN)
            }
          }

          // Here we are reversing the data as it should be in incremental date
          valueArrData = valueArrData.filter(value => !Number.isNaN(value)).reverse()

          const missingDates = finalLabelsData.filter(ele => !datesData.find(dateObj => ele === dateObj))
          missingDates.map(missingDateObj => {
            const indexOfMissingObj = finalLabelsData.findIndex(axisDate => axisDate === missingDateObj)

            return valueArrData.splice(indexOfMissingObj, 0, '-')
          })

          // console.log('values final data', valueArrData)

          const dataSetObj = {
            label: key,
            data: valueArrData,
            borderColor: colorCode[index],
            borderWidth: 1,
            backgroundColor: colorCode[index]
          }
          finalDataSet.push(dataSetObj)
        }

        // console.log('finalDataSet data::', finalDataSet)

        const dataSet = {
          labels: finalLabelsData, // getLabelsData(interval),
          datasets: finalDataSet
        }
        setData(dataSet)
      })
  }
  const groupByData = (array, key) => {
    // Return the end result
    return array.reduce((result, currentValue) => {
      // If an array already present for key, push it to the array. Else create an array and push the object
      (result[currentValue[key]] = result[currentValue[key]] || []).push(
        currentValue
      )
      // Return the current iteration `result` value, this will be taken as next iteration `result` value and accumulate
      return result
    }, {}) // empty object is the initial value for result object
  }

  useEffect(() => {
    getClientLongitudinalData(7)
  }, [])

  return (
    <>
      <AssessmentsChartModal clientUserId={clientUserId} show={isFullScreen} handleModalPopUp={() => { setIsFullScreen(false) }}></AssessmentsChartModal>
      <div style={{ border: '1px solid #EEEEEE', height: '27.625rem' }}>
        <>
          {/* <LoaderModalPopUp show={isAPICalling} message='Saving notes data...' /> */}
          {
            isAPICalling
              ? (
                <Loader />
                )
              : (
                <div style={{ padding: '10px', color: '#2D2D34' }} >
                  {
                    comingFrom === '' && (
                      <>
                        <div style={{ fontFamily: 'Roboto,Regular', fontSize: 12, display: 'flex' }} >
                          <label style={{ paddingTop: '5px', color: '#2D2D34' }} >View : </label>
                          <div style={{ paddingLeft: '10px', color: '#2D2D34', paddingRight: '30px' }} >
                            <select name="line" id="line" value={dropDownData} onChange={handleDataChange} style={{ padding: '5px', border: '1px solid grey', borderRadius: '5px' }} >
                              {
                                viewGraphFrequency.map((x, y) =>
                                  <option key={y}>{x}</option>)
                              }
                            </select>
                          </div>
                        </div>
                      </>
                    )
                  }
                  <div>
                    {
                      data && data.labels && (
                        <Line options={options} data={data} style={{ height: '24.375rem' }} />
                      )
                    }

                  </div>
                </div>
                )
          }
        </>
      </div>
    </>
  )
}
ClientAssessmentsChart.propTypes = {
  clientUserId: PropTypes.string,
  comingFrom: PropTypes.string
}
