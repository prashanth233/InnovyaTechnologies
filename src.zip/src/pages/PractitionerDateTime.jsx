import React from 'react'
import { Col, Row, Form } from 'react-bootstrap'
import TextField from '@mui/material/TextField'
import AdapterDateFns from '@mui/lab/AdapterDateFns'
import LocalizationProvider from '@mui/lab/LocalizationProvider'
import StaticDatePicker from '@mui/lab/StaticDatePicker'

// import Calendar from 'react-calendar'
import 'react-calendar/dist/Calendar.css'
import '../styles/App.css'
import { timeSlots } from '../CommonData/Data'
import PropTypes from 'prop-types'

export const PractitionerDateTime = ({ scheduleLink, timeErrors, handleTimeDataChange, handleDateTime, value, handleDateSelect, appointmentDetails }) => {
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone // moment.tz.zone(moment.tz.guess()).abbr(new Date().getTimezoneOffset())

  return (
        <>
            <Row style={{ fontFamily: 'Roboto, light', fontSize: '18px', color: '#6A6A6A', margin: '2vw' }}>Select Date & Time *</Row>
            <Row className="justify-content-center">
                <Col md="auto">
                    <LocalizationProvider dateAdapter={AdapterDateFns}>

                        <StaticDatePicker
                            minDate={new Date()}
                            displayStaticWrapperAs="desktop"
                            openTo="day"
                            value={value}
                            onChange={handleDateSelect}
                            renderInput={(params) => <TextField {...params} />}
                        />
                    </LocalizationProvider>

                </Col>
                <Col md="auto">
                    <Row style={{ fontFamily: 'Roboto, light', fontSize: '20px', color: '#gray', margin: '0 0 2vw 2vw' }}>Available Time Slots</Row>
                    <Row style={{ fontFamily: 'Roboto, light', fontSize: '22px', color: '#139ED7', margin: '0 0 2vw 2vw', width: '10vw' }} >
                        <Form.Label style={{ fontFamily: 'Roboto', fontSize: '14px' }}>Start Time *</Form.Label>
                        <Form.Control as="select" name="startTime" value={appointmentDetails.startTime} onChange={handleTimeDataChange}>
                            {
                                timeSlots.map((x, y) =>
                                    <option key={y}>{x}</option>)
                            }
                        </Form.Control>
                        {
                            timeErrors.startTimeError && (
                                <Form.Label style={{ fontFamily: 'Roboto', fontSize: '12px', color: 'red' }}>{timeErrors.startTimeError}</Form.Label>
                            )
                        }
                    </Row>
                    <Row style={{ fontFamily: 'Roboto, light', fontSize: '22px', color: '#139ED7', margin: '0 0 2vw 2vw', width: '10vw' }} >
                        <Form.Label style={{ fontFamily: 'Roboto', fontSize: '14px' }}>End Time *</Form.Label>
                        <Form.Control as="select" name="endTime" value={appointmentDetails.endTime} onChange={handleTimeDataChange}>
                            {
                                timeSlots.map((x, y) =>
                                    <option key={y}>{x}</option>)
                            }
                        </Form.Control>
                        {
                            timeErrors.endTimeError && (
                                <Form.Label style={{ fontFamily: 'Roboto', fontSize: '12px', color: 'red' }}>{timeErrors.endTimeError}</Form.Label>
                            )
                        }
                    </Row>
                    <Row style={{ fontFamily: 'Roboto, light', fontSize: '22px', color: '#139ED7', margin: '0 0 2vw 2vw', width: '30vw' }} >
                        <Form.Label style={{ fontFamily: 'Roboto', fontSize: '14px' }}>Current Time Zone : </Form.Label>
                        <Form.Label style={{ fontFamily: 'Roboto', fontSize: '14px', color: 'black', paddingLeft: '10px' }}>{timeZone}</Form.Label>
                    </Row>
                </Col>
            </Row>
            <Row style={{ fontFamily: 'Roboto, light', fontSize: '18px', color: '#6A6A6A', marginLeft: '2vw' }}>Add Meeting Link *</Row>
            <Row style={{ fontFamily: 'Roboto, light', fontSize: '18px', color: '#6A6A6A', marginLeft: '1vw' }}>
                <Col md="9">
                    <input
                        id="meetingLink"
                        type="text"
                        value={scheduleLink}
                        onChange={handleDateTime}
                        style={{ width: '70vw', border: '1px solid #DFDFDF' }}
                    />
                </Col>
            </Row>
        </>
  )
}

PractitionerDateTime.propTypes = {
  scheduleLink: PropTypes.string,
  value: PropTypes.string,
  appointmentDetails: PropTypes.object,
  timeErrors: PropTypes.object,
  handleTimeDataChange: PropTypes.func.isRequired,
  handleDateTime: PropTypes.func.isRequired,
  handleDateSelect: PropTypes.func.isRequired

}
