/* eslint-disable no-unreachable */
import React, { useState, useEffect } from 'react'
import { Button } from 'react-bootstrap'
import { AzMediaPlayerModal, LoaderModalPopUp } from '../CommonData/ModalPopUp'
import '../styles/App.css'
import config from '../config'
import moment from 'moment'
import { useMsal, useAccount } from '@azure/msal-react'
import { Divider } from '@mui/material'
import calImg from '../Assets/Calendar.png'
import GreenDot from '../Assets/greenDot.png'
import { AssessmentsActivitiesTab } from './AssessmentActivitiesTab'
import { showJoinOption } from '../CommonData/CommonFunction'
import RtmClient from '../components/rtm-client'
import { callApiForActivityStatus, callApiForRegistration } from '../fetch'
import {
  getAgoraToken,
  LoggingAppointmentsData,
  AppointmentsCommonUrl
} from '../CommonData/APIListing'

import PropTypes from 'prop-types'
import {
  createAgoraTokenUrl,
  videoStatusUpdateUrl
} from '../CommonData/CreateAPIUrl'

const AppointmentDetailsHeader = ({
  appointmentDetail,
  currentRole,
  isPastAppointment,
  joinMeetingHandler,
  isMeetingStarted
}) => {
  const dateConst = moment(appointmentDetail.meetingStartDateTime).format(
    'MMM DD, yyyy'
  )
  const timeConst = moment(appointmentDetail.meetingStartDateTime).format(
    'hh:mm A'
  )
  const endTimeConst = moment(appointmentDetail.meetingEndDateTime).format(
    'hh:mm A'
  )

  const showJoin = showJoinOption(
    appointmentDetail.meetingStartDateTime,
    appointmentDetail.meetingEndDateTime
  )

  const showJoinButton =
    config.APP_ENV_NAME === 'local' ||
    (!isPastAppointment &&
      showJoin &&
      appointmentDetail.status === 'Scheduled')
  // const showJoinButton = showJoin

  return (
    <div
      style={{
        paddingTop: 10,
        paddingLeft: '15px',
        display: 'flex',
        justifyContent: 'space-between'
      }}
    >
      <p
        style={{
          color: '#139ED7',
          fontFamily: 'Roboto, Light',
          fontSize: '20px'
        }}
      >
        {' '}
        {`Appointment with ${
          appointmentDetail.clientName
            ? appointmentDetail.clientName
            : appointmentDetail.practitionerName
        }`}
      </p>
      <div
        style={{
          paddingLeft: '20px',
          marginTop: '5px',
          color: '#2D2D34',
          fontFamily: 'Roboto, Regular',
          fontSize: '14px'
        }}
      >
        <img src={calImg} width={15}></img>
        <span> </span>

        {`${dateConst} | ${timeConst}-${endTimeConst}`}
      </div>
      {currentRole !== 'Coordinator' && !isMeetingStarted && showJoinButton && (
        <Button
          variant="danger"
          id="details"
          style={{
            marginLeft: '20px',
            backgroundColor: '#F24B5D',
            height: 35,
            fontSize: '14px'
          }}
          onClick={joinMeetingHandler}
        >
          JOIN
        </Button>
      )}
      {isMeetingStarted && (
        <div
          style={{
            paddingLeft: '20px',
            marginTop: '5px',
            color: '#4C927E',
            fontFamily: 'Roboto, Regular',
            fontSize: '14px'
          }}
        >
          <img src={GreenDot} width={9}></img>
          <span> </span>
          Meeting in progress
        </div>
      )}
    </div>
  )
}
AppointmentDetailsHeader.propTypes = {
  currentRole: PropTypes.string.isRequired,
  appointmentDetail: PropTypes.object.isRequired,
  joinMeetingHandler: PropTypes.func.isRequired,
  isMeetingStarted: PropTypes.bool.isRequired,
  isPastAppointment: PropTypes.bool.isRequired
}
const rtm = new RtmClient()
let videoUrlData
// let myAZPlayer

export const AppointmentDetails = ({
  toggleDetailsView,
  appointmentDetail,
  isPastAppointment,
  selectedTab
}) => {
  // console.log('appointmentDetail::', appointmentDetail)
  const currentRole = JSON.parse(localStorage.getItem('UserType'))
  const { accounts } = useMsal()
  const msalAccount = useAccount(accounts[0] || {})

  const [isMeetingStarted, setIsMeetingStarted] = useState(false)
  const [isAPICalling, setisAPICalling] = useState(false)
  const [isVideoStarted, setIsVideoStarted] = useState(false)
  // const azureMediaPlayerRef = useRef(null)
  const [activityData, setActivityData] = useState({})
  const [playerDuration, setPlayerDuration] = useState(0)
  const [refreshData, setRefreshData] = useState(false)

  // Agora related code
  // const [rtm, setRtm] = useState(new RtmClient())
  const appID = config.APP_AGORA_CLIENT_ID // '5958ba4c54614096a0350e1b5141f5f3'
  const channelName = appointmentDetail.appointmentId
  const account = appointmentDetail.practitionerId

  // console.log('ConnectionStateChanged listener added::')

  const joinAgoraSession = (agoraToken) => {
    try {
      rtm.init(appID)
      window.rtm = rtm
      rtm
        .login(account, agoraToken)
        .then(() => {
          // console.log('login success')
          rtm._logined = true
          rtm
            .joinChannel(channelName)
            .then(() => {
              setisAPICalling(false)

              rtm.channels[channelName].joined = true
              // console.log('Join Channel success acc name::', rtm.accountName + ' join channel success' + channelName)
              // Opening the Teams in new tab
              setIsMeetingStarted(true)

              window.open(`${appointmentDetail.meetingLink}`, '_blank')
            })
            .catch((err) => {
              setisAPICalling(false)

              // Toast.error('Join channel failed, please open console see more details.')
              console.error(
                'Join channel failed, please open console see more details.',
                err
              )
            })
          // Toast.notice('Login: ' + params.accountName, ' token: ', params.token)
        })
        .catch((err) => {
          setisAPICalling(false)

          console.log(err)
        })
    } catch (err) {
      setisAPICalling(false)

      // Toast.error('Login failed, please open console see more details')
      console.error('err in login', err)
    }
  }
  const getAgoraTokenCall = () => {
    setisAPICalling(true)
    // setRtm(new RtmClient())
    const reqData = {
      accountName: appointmentDetail.practitionerId, // data["appointmentId"],
      uid: ''
    }

    const agoraUrl = createAgoraTokenUrl(getAgoraToken)
    callApiForRegistration(agoraUrl, reqData).then((response) => {
      // console.log('Agora Token API Resp:-', response)
      const finalResp = response && response.length ? response : ''

      joinAgoraSession(finalResp)
    })
  }

  /// ///Agora code ends here

  // Get Play video call from ActivitiesAssessmentsData
  const playVideoHandler = (e) => {
    // console.log('activity data::', e)
    videoUrlData = e.activityLink
    // videoUrlData = '//henri360devmedia-euwe.streaming.media.azure.net/4d746816-7836-40e3-a772-d43ca38ba0ed/7d8dc625-b89d-45cb-85ce-3dc5a331.ism/manifest'
    // videoUrlData = '//willzhanmswest.streaming.mediaservices.windows.net/1f2dd2dd-ee99-40be-aae9-d0c2209982eb/DroneFlightOverLasVegasStripH3Pro7.ism/Manifest'
    if (e.status === 'partially seen') {
      const duration = e.videoWatchDuration.split(':')
      const secondsDuration = Number(duration[0]) * 60 + Number(duration[1])
      // console.log('Final time::', secondsDuration)
      setPlayerDuration(secondsDuration)
    }
    // return
    setIsVideoStarted(true)
    setRefreshData(false)
    setActivityData(e)
    const data = {
      action: 'Start',
      url: videoUrlData,
      title: e.activityName,
      id: e.id,
      status: e.status,
      time: e.videoWatchDuration,
      activity: e.isVREnabled
    }
    rtm
      .sendChannelMessage(data, channelName)
      .then(() => {
        console.log('Send Start as channel message success after')
      })
      .catch((err) => {
        console.error('Send message to channel err ', err)
      })
  }
  const closeVideoHandler = (e) => {
    rtm
      .sendChannelMessage('Close', channelName)
      .then(() => {
        console.log('Send Close as channel message success after')
        setIsVideoStarted(false)
        setRefreshData(true)
      })
      .catch((err) => {
        console.error('Send message to channel err ', err)
      })
  }

  const joinMeetingHandler = () => {
    getAgoraTokenCall()
  }

  const videoStatusUpdateCall = (status, duration) => {
    const activityStatusUpdate = videoStatusUpdateUrl(
      msalAccount,
      AppointmentsCommonUrl
    )
    const reqUrl = `${activityStatusUpdate}${appointmentDetail.appointmentId}?appointmentActivityId=${activityData.id}&status=${status}&watchDuration=${duration} mins`
    callApiForActivityStatus(reqUrl, {}).then((response) => {
      // console.log('videoStatusUpdateCall API Resp:-', response)
      const finalResp = response && response.length ? response : ''
      console.log('Final resp appdDet::', finalResp)
    })
  }

  const handleAzurePlayerClick = (buttonText, playerDuration) => {
    // console.log('Azure media player click::', e.target, e)

    // const buttonText = e
    if (buttonText === 'Play') {
      rtm
        .sendChannelMessage('Play', channelName)
        .then(() => {
          console.log('Send Play as channel message success after')
        })
        .catch((err) => {
          console.error('Send message to channel err ', err)
        })
      // videoStatusUpdateCall('started', '0:00')
    }
    if (buttonText === 'Play Video') {
      rtm
        .sendChannelMessage('Play', channelName)
        .then(() => {
          console.log('Send Play as channel message success after')
        })
        .catch((err) => {
          console.error('Send message to channel err ', err)
        })
      videoStatusUpdateCall('started', '0:00')
    }
    if (buttonText === 'Pause') {
      rtm
        .sendChannelMessage('Pause', channelName)
        .then(() => {
          console.log('Send Pause as channel message success after')
        })
        .catch((err) => {
          console.error('Send message to channel err ', err)
        })
    }
    if (buttonText === 'Mute') {
      rtm
        .sendChannelMessage('Mute', channelName)
        .then(() => {
          console.log('Send Mute as channel message success after')
        })
        .catch((err) => {
          console.error('Send message to channel err ', err)
        })
    }
    if (buttonText === 'Unmute') {
      rtm
        .sendChannelMessage('Unmute', channelName)
        .then(() => {
          console.log('Send Unmute as channel message success after')
        })
        .catch((err) => {
          console.error('Send message to channel err ', err)
        })
    }
    if (buttonText === 'Seeking') {
      const data = { action: 'Seeking', playerDuration: playerDuration }

      rtm
        .sendChannelMessage(data, channelName)
        .then(() => {
          console.log('Send Seek as channel message success after')
        })
        .catch((err) => {
          console.error('Send message to channel err ', err)
        })
    }
    if (buttonText === 'Ended') {
      rtm
        .sendChannelMessage('Ended', channelName)
        .then(() => {
          console.log('Send End as channel message success after')
        })
        .catch((err) => {
          console.error('Send message to channel err ', err)
        })
    }
  }

  const handleModalPopUp = () => {
    closeVideoHandler()
  }
  // Log Appt Details
  const logAppointmentDetails = () => {
    // setisAPICalling(true)
    const dataToSend = {
      appointmentId: appointmentDetail.appointmentId,
      clientId: appointmentDetail.clientId,
      practitionerId: appointmentDetail.practitionerId,
      meetingLink: appointmentDetail.meetingLink,
      meetingStartDateTime: appointmentDetail.meetingStartDateTime,
      meetingEndDateTime: appointmentDetail.meetingEndDateTime,
      coordinatorId: appointmentDetail.coordinatorId,
      tenantId: appointmentDetail.tenantId,
      status: appointmentDetail.status
    }
    callApiForRegistration(LoggingAppointmentsData, dataToSend).then(
      (response) => {
        // setisAPICalling(false)
        // console.log('logAppointmentDetails data response::', response)
      }
    )
  }
  useEffect(() => {
    rtm.on('ConnectionStateChanged', (newState, reason) => {
      console.log('ConnectionStateChanged reason::', reason)
      // console.log('ConnectionStateChanged newState::', newState)
    })

    rtm.on('MemberJoined', ({ channelName, args }) => {
      const memberId = args[0]
      console.log(
        'MemberJoined apptDet :: channel ',
        channelName,
        ' member: ',
        memberId,
        'args::',
        args
      )
      rtm
        .getChannelMembers(channelName)
        .then((data) => {
          // console.log('getChannelMembers :: data ', data)
          if (data && data.length > 1) {
            logAppointmentDetails()
          }
        })
        .catch((err) => {
          console.error('getChannelMembers err::', err)
        })
    })

    rtm.on('MemberLeft', ({ channelName, args }) => {
      const memberId = args[0]
      console.log('MemberLeft:: channel ', channelName, ' member: ', memberId)
    })

    return () => {
      // console.log('inside cleanup appointment details')
      // myAZPlayer && myAZPlayer.dispose()
      // removeEventListener('play')
      rtm
        .leaveChannel(channelName)
        .then(() => {
          // console.log('inside leave joined channel: useeffect::')

          if (rtm.channels[channelName]) {
            rtm.channels[channelName].joined = false
            rtm.channels[channelName] = null
          }
          rtm._logined && rtm.logout()
        })
        .catch((err) => {
          rtm._logined && rtm.logout()

          console.error(err)
        })
    }
  }, [])

  return (
    <>
      {/* {console.log('Render data::', playerDuration)} */}
      <LoaderModalPopUp show={isAPICalling} message="Loading..." />
      <AzMediaPlayerModal
        show={isVideoStarted}
        videoUrlData={videoUrlData}
        handleModalPopUp={handleModalPopUp}
        showClose={true}
        handleAzurePlayerClick={handleAzurePlayerClick}
        title={activityData.activityName}
        playerDuration={playerDuration}
        activityDetails={activityData}
      />
      <div>
        <div
          style={{
            backgroundColor: 'white',
            borderRadius: '20px',
            border: '2px'
          }}
        >
          <div
            style={{
              paddingLeft: 20,
              paddingTop: 10,
              fontFamily: 'Roboto, Regular',
              fontSize: '13px',
              color: '#2D2D34'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <>
                <AppointmentDetailsHeader
                  isPastAppointment={isPastAppointment}
                  appointmentDetail={appointmentDetail}
                  currentRole={currentRole}
                  isMeetingStarted={isMeetingStarted}
                  joinMeetingHandler={joinMeetingHandler}
                />
                <Button
                  variant="danger"
                  id="details"
                  style={{
                    marginTop: '10px',
                    backgroundColor: 'white',
                    color: '#F24B5D',
                    border: 'none',
                    height: 35
                  }}
                  onClick={toggleDetailsView}
                >
                  {currentRole === 'Coordinator'
                    ? 'ALL APPOINTMENTS'
                    : 'UPCOMING APPOINTMENTS'}
                </Button>
              </>
            </div>

            <Divider variant="middle" />

            <div style={{ padding: '10px', width: '97vw' }}>
              <AssessmentsActivitiesTab
                appointmentDetail={appointmentDetail}
                selectedTab={selectedTab}
                isMeetingStarted={isMeetingStarted}
                playVideoHandler={playVideoHandler}
                refreshData={refreshData}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

AppointmentDetails.propTypes = {
  selectedTab: PropTypes.string.isRequired,
  appointmentDetail: PropTypes.object.isRequired,
  toggleDetailsView: PropTypes.func.isRequired,
  isPastAppointment: PropTypes.bool.isRequired
}
