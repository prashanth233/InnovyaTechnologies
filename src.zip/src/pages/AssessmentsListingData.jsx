/* eslint-disable array-callback-return */
import React, { useState, useEffect } from 'react'
import { useMsal, useAccount } from '@azure/msal-react'
import { useHistory } from 'react-router-dom'
import { TableComponent } from '../components/TableComponent'
import { Button } from 'react-bootstrap'
import { AssignActivitiesAssessmentsModal, LoaderModalPopUp } from '../CommonData/ModalPopUp'
import { NoActivitiesFound } from '../CommonData/WorkInProgress'
import '../styles/App.css'
import { AppointmentsCommonUrl } from '../CommonData/APIListing'
import { callApiForListing, callApiForUpdate } from '../fetch'
import { AssessmentsListingColumns } from '../CommonData/Data'
import PropTypes from 'prop-types'
import { createCoordinatorAppointmentsUrl } from '../CommonData/CreateAPIUrl'

export const AssessmentsListingData = ({ appointmentDetail, type, widthData, isMeetingStarted, playVideoHandler }) => {
  const currentRole = JSON.parse(localStorage.getItem('UserType'))
  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})
  // const columnData = currentRole === "Client" ? ClientAssessmentsListingColumns : AssessmentsListingColumns
  const history = useHistory()

  const columnData = AssessmentsListingColumns

  const [isAPICalling, setisAPICalling] = useState(false)

  const [assessmentsData, setAssessmentsData] = useState([])

  const [showAssignModal, setShowAssignModal] = useState(false)

  const getAssessmentsData = () => {
    setisAPICalling(true)
    const getAssessmentsUrl = `${createCoordinatorAppointmentsUrl(account, AppointmentsCommonUrl)}/${appointmentDetail.appointmentId}/${type}`
    // const getAssessmentsUrl = `${CoordinatorAppointments}/${appointmentDetail.appointmentId}/${type}`
    callApiForListing(getAssessmentsUrl)
      .then((response) => {
        const finalResp = response && typeof (response) === 'object' ? response : []

        if (finalResp.length) {
          finalResp.map(obj => {
            obj.meetingStatus = `NotStarted:${obj.status}`

            if (isMeetingStarted) {
              // obj.meetingStatus = "InProgress";
              obj.meetingStatus = `InProgress:${obj.status}`
            }
          })
        }

        setisAPICalling(false)
        setAssessmentsData(finalResp)
        // setCardData(finalResp)
      })
  }
  const onAssignClick = () => {
    // if (type === "assessments") {
    setShowAssignModal(true)

    // }
  }

  // Remove AAssessments
  const removeAssessment = (forData) => {
    setisAPICalling(true)
    const apiUrl = `${createCoordinatorAppointmentsUrl(account, AppointmentsCommonUrl)}/${forData.appointmentId}/assessments`

    // const apiUrl = `${CoordinatorAppointments}/${forData.appointmentId}/assessments`
    let dataToSend = {}

    dataToSend = {
      addAppointmentAssessments: [

      ],
      removeAppointmentAssessment: [
        {
          id: forData.id,
          clientId: forData.clientId,
          assessmentId: forData.id,
          status: 'Remove',
          appointmentId: forData.appointmentId,
          assessmentType: forData.type,
          videoWatchDuration: forData.videoWatchDuration,
          tenantId: forData.tenantId
        }

      ]
    }
    callApiForUpdate(apiUrl, dataToSend)
      .then((response) => {
        setisAPICalling(false)
        if (response && response[0]) {
          const finalData = assessmentsData.filter(data => data.id !== response[0].assessmentId)
          setAssessmentsData(finalData)
        }
      })
  }

  /// /////Table Click handler=============
  const onRowClicked = (row, e) => {
    const buttonClick = e.target.innerText
    // console.log('assessment assess table event Data::', e.target.id, e.target.innerText, e.target.nodeName)
    if (e.target.nodeName === 'BUTTON') {
      if (buttonClick === 'REMOVE') {
        removeAssessment(row.original)
      }
      if (buttonClick === 'PLAY' || buttonClick === 'RESUME' || buttonClick === 'PLAY AGAIN') {
        playVideoHandler(row.original)
      }
    }
    if (e.target.id === 'assessmentsData' && currentRole === 'Client') {
      history.push('/assessments')
    }
  }
  /// //////
  const handleModalPopUp = () => {
    setShowAssignModal(false)
    getAssessmentsData()
  }

  useEffect(() => {
    getAssessmentsData()
    // console.log('Assessments tab effect')
  }, [type, isMeetingStarted, appointmentDetail])
  return (
    <>
      <LoaderModalPopUp show={isAPICalling} message='Fetching Activities and Assessments data...' />
      <AssignActivitiesAssessmentsModal show={showAssignModal} data={appointmentDetail} handleModalPopUp={handleModalPopUp} listingData={assessmentsData} type={type}></AssignActivitiesAssessmentsModal>

      <div style={{ backgroundColor: 'white', border: '2px solid #EEEEEE', minHeight: '60vh', height: '100%', borderRadius: '0 0 8px 8px', borderTop: 'none' }}>
        <div style={{ width: widthData }}>

        <div style={{ display: 'flex', justifyContent: 'right', paddingLeft: 10, paddingTop: 10 }}>
                {currentRole !== 'Client' && <Button variant="danger" id="details" style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', backgroundColor: 'white', color: '#F24B5D', border: 'none', height: 35 }} onClick={onAssignClick}>ASSIGN</Button> }
              </div>

          <div style={{ padding: 10 }}>
            {
              assessmentsData && assessmentsData.length
                ? (<TableComponent columns={columnData} data={assessmentsData} onRowClicked={onRowClicked} showHeader={true} tableWidth={widthData} />)
                : (<NoActivitiesFound type={type} />)
            }
          </div>

        </div>
      </div>
    </>
  )
}
AssessmentsListingData.propTypes = {
  type: PropTypes.string,
  isMeetingStarted: PropTypes.bool,
  appointmentDetail: PropTypes.object,
  widthData: PropTypes.string,
  playVideoHandler: PropTypes.func
}
