/* eslint-disable react/no-unescaped-entities */
import React, { useState, useRef, useEffect } from 'react'
import '../Home/Landing.css'
import InsuranceImg from '../Assets/Insurance.png'
import '../styles/App.css'
import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import { useMsal, useAccount } from '@azure/msal-react'
import { Avatar, Badge, Divider } from '@mui/material'
import Loader from './Loader'
import { Col, Row } from 'react-bootstrap'
import { userDataAPI } from '../CommonData/APIListing'
import { callApiForProfile } from '../fetch'
import { LoaderModalPopUp } from '../CommonData/ModalPopUp'
import moment from 'moment'
import PropTypes from 'prop-types'
import { createProfileBaseUrl } from '../CommonData/CreateAPIUrl'

export const UserDetails = ({ userId, handleEditProfile }) => {
  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})
  const profileFile = useRef(null)
  const [isLoading, setLoading] = useState(false)
  const [imgFile, setImgFile] = useState(ProfilePlaceholder)
  const [isAPICalling, setIsAPICalling] = useState(false)
  const [profileData, setProfileData] = useState({
    photo: '',
    email: '',
    age: '',
    firstName: '',
    laststName: '',
    gender: '',
    practiceName: '',
    referralName: '',
    insurenceId: '',
    insurenceName: '',
    insurencePlan: '',
    mrnNo: '',
    babyDOB: '',
    mobileNo: '',
    zipCode: '',
    state: '',
    city: '',
    address: '',
    dob: ''
  })

  const handleFileChange = (event) => {
    setLoading(true)
    const file = event.target.files[0]
    const reader = new FileReader()

    reader.onload = () => {
      setImgFile(reader.result)
      setLoading(false)
    }
    reader.readAsDataURL(file)
  }

  const getUserDetails = () => {
    setIsAPICalling(true)
    const profileUrl = createProfileBaseUrl(account, userDataAPI)

    callApiForProfile(profileUrl, userId, 'client')
      .then((response) => {
        // console.log("Client profile API Resp:-", response);
        // const finalResp = response || {}
        const finalResp = response && typeof (response) === 'object' ? response : {}

        setImgFile(finalResp.photo === '' ? ProfilePlaceholder : finalResp.photo)
        setIsAPICalling(false)
        setProfileData(finalResp)
      })
  }

  useEffect(() => {
    getUserDetails()
  }, [])

  return (
        <div style={{ border: '1px solid #EEEEEE', paddingTop: 8, height: '100%' }}>
            <LoaderModalPopUp show={isAPICalling} message='Fetching Details...' />

            <div style={{ marginTop: '10px', textAlign: 'center', display: 'block' }}>

                {
                    isLoading
                      ? (
                        <Loader />
                        )
                      : (
                            <>
                                <Badge
                                    overlap="circular"
                                    anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                                >
                                    <Avatar
                                        src={imgFile}
                                        rounded
                                        sx={{ width: 130, height: 130 }}
                                    />
                                </Badge>
                                <input
                                    id="profile"
                                    ref={profileFile}
                                    type="file"
                                    style={{ display: 'none' }}
                                    accept="image/*"
                                    onChange={handleFileChange}
                                />
                            </>
                        )
                }

                <p style={{ marginTop: '20px', fontFamily: 'Roboto', fontSize: '20px', color: '#139ED7', marginBottom: '10px' }}>{profileData.firstName && `${profileData.firstName} ${profileData.lastName}`}</p>
            </div>
            <Divider variant="middle" />
            <Row style={{ paddingTop: '10px', paddingBottom: '10px' }}>
                <Col md="4" style={{ marginLeft: 10, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#9E9E9E' }}>
                    Age
                </Col>
                <Col style={{ paddingLeft: 2, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#2D2D34' }}>
                    {profileData.age && `${profileData.age}y`}
                </Col>
            </Row>
            <Row style={{ paddingTop: '10px', paddingBottom: '10px' }}>
                <Col md="4" style={{ marginLeft: 10, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#9E9E9E' }}>
                    Gender
                </Col>
                <Col style={{ paddingLeft: 2, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#2D2D34' }}>
                    {profileData && (profileData.gender.charAt(0).toUpperCase() + profileData.gender.slice(1))}
                </Col>
            </Row>
            <Row style={{ paddingTop: '10px', paddingBottom: '10px' }}>
                <Col md="4" style={{ marginLeft: 10, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#9E9E9E' }}>
                    Date of Birth
                </Col>
                <Col style={{ paddingLeft: 2, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#2D2D34' }}>
                    {profileData.dob && moment(new Date(profileData.dob)).format('DD/MM/yyyy')}
                </Col>
            </Row>
            <Row style={{ paddingTop: '10px', paddingBottom: '10px' }}>
                <Col md="4" style={{ marginLeft: 10, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#9E9E9E' }}>
                    Email
                </Col>
                <Col md="7" style={{ paddingLeft: 2, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#2D2D34', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {profileData.email}
                </Col>
            </Row>
            <Row style={{ paddingTop: '10px', paddingBottom: '10px' }}>
                <Col md="4" style={{ marginLeft: 10, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#9E9E9E' }}>
                    Address
                </Col>
                <Col md="7" style={{ paddingLeft: 2, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#2D2D34' }}>
                    {profileData.address && `${profileData.address} ${profileData.city}, ${profileData.state}-${profileData.zipCode}`}
                </Col>
            </Row>
            <Row style={{ paddingTop: '10px', paddingBottom: '10px' }}>
                <Col md="4" style={{ marginLeft: 10, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#9E9E9E' }}>
                    Mobile Number
                </Col>
                <Col style={{ paddingLeft: 2, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#2D2D34' }}>
                    {profileData.mobileNo}
                </Col>
            </Row>
            <Row style={{ paddingTop: '10px', paddingBottom: '10px' }}>
                <Col md="4" style={{ marginLeft: 10, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#9E9E9E' }}>
                    Baby's DoB
                </Col>
                <Col style={{ paddingLeft: 2, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#2D2D34' }}>
                    {profileData.babyDOB === null ? '-' : profileData.babyDOB && moment(new Date(profileData.babyDOB)).format('DD/MM/yyyy')}
                </Col>
            </Row>
            <Row style={{ paddingTop: '10px', paddingBottom: '10px' }}>
                <Col md="4" style={{ marginLeft: 10, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#9E9E9E' }}>
                    MRN Number
                </Col>
                <Col style={{ paddingLeft: 2, paddingRight: 0, fontFamily: 'Roboto', fontSize: '14px', color: '#2D2D34' }}>
                    {profileData.mrnNo}
                </Col>
            </Row>
            {/* <div style={{ backgroundColor:'green', marginLeft: 10, marginTop: '10px', textAlign: 'center', display: 'block' }}> */}
            <div style={{ width: '226px', height: '167px', margin: 'auto', backgroundColor: '#FFFBF0' }}>
                <div style={{ fontFamily: 'Roboto, Light', paddingLeft: 20, paddingTop: 15, fontSize: '20px', color: '#2D2D34' }}>

                    <img src={InsuranceImg} width={20}></img>
                    <span>  </span>

                    {'INSURANCE'}
                </div>
                {
                    profileData.insurencePlan === ''
                      ? (<>
                        <div style={{ fontFamily: 'Roboto, Regular', paddingLeft: 20, paddingTop: 15, fontSize: '14px', color: '#2D2D34' }}>
                            {profileData.insurenceName}
                        </div>
                        <div style={{ fontFamily: 'Roboto, Regular', paddingLeft: 20, paddingTop: 15, fontSize: '14px', color: '#2D2D34' }}>
                            {`${profileData.insurenceId}`}
                        </div></>
                        )
                      : (
                        <div style={{ fontFamily: 'Roboto, Regular', paddingLeft: 20, paddingTop: 15, fontSize: '14px', color: '#2D2D34' }}>No Insurance Plan</div>
                        )
                }
            </div>
            {/* </div> */}

            <Row style={{ marginLeft: -6, paddingTop: '20px', fontFamily: 'Roboto', fontSize: '14px', color: '#9E9E9E' }}>
                <Col>
                    Referring Provider
                </Col>
            </Row>
            <Row style={{ marginLeft: -6, paddingTop: '10px', fontFamily: 'Roboto', fontSize: '14px', color: '#2D2D34' }}>
                <Col>                {profileData.referralName}
                </Col>
            </Row>
            <Row style={{ marginLeft: -6, paddingTop: '10px', fontFamily: 'Roboto', fontSize: '14px', color: '#9E9E9E' }}>
                <Col> Practice Name</Col>
            </Row>
            <Row style={{ marginLeft: -6, paddingTop: '10px', fontFamily: 'Roboto', fontSize: '14px', color: '#2D2D34' }}>

                <Col>{profileData.practiceName}</Col>
            </Row>
        </div>
  )
}

UserDetails.propTypes = {
  userId: PropTypes.string,
  handleEditProfile: PropTypes.func.isRequired
}
UserDetails.defaultProps = {
  userId: ''

}
