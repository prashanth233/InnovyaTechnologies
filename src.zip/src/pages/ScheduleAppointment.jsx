/* eslint-disable dot-notation */
import React, { useEffect, useState } from 'react'
import '../styles/App.css'
import { useMsal, useAccount } from '@azure/msal-react'
import { Button } from 'react-bootstrap'
import { callApiForListing, callApiForRegistration } from '../fetch'
import moment from 'moment'
import SearchComponent from '../components/SearchComponent'
import { LoaderModalPopUp, ModalPopUp } from '../CommonData/ModalPopUp'
import { getDateFromString } from '../CommonData/CommonFunction'
import { appointMentInitialData } from '../CommonData/RegistrationInitialData'
import { ClientAppointmentCard } from '../Cards/ClientAppointmentCard'

import ScheduleAppointmentCard from '../Cards/ScheduleAppointmentCard'
import { ScheduleAppointmentProgress } from './ScheduleAppointmentProgress'
import { AppointmentConfirm } from './AppointmentConfirm'
import { PractitionerDateTime } from './PractitionerDateTime'
import { AppointmentsCommonUrl, CoordinatorBaseURL } from '../CommonData/APIListing'
import PropTypes from 'prop-types'
import { coordinatorClientSearch, coordinatorPractitionerSearch, timeSlots } from '../CommonData/Data'
import { createAppointmentUrl, getClientListingUrl, getPractitionerListingUrl } from '../CommonData/CreateAPIUrl'

export const ScheduleAppointment = ({ handleAppointmentChange, editAppointmentData, forClientId }) => {
  const [selectedIndex, setSelectedIndex] = useState('')
  const [selectedUser, setSelectedUser] = useState('')
  const [editAppointment, setEditAppointment] = useState(editAppointmentData.isEdit)

  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})

  const [isClient, setIsClient] = useState(true)
  const [isPractitioner, setIsPractitioner] = useState(false)
  const [isConfirm, setIsConfirm] = useState(false)
  const [appointmentData, setAppointmentData] = useState([])
  const [appointmentDetails, setAppointmentDetails] = useState({})

  const [showModal, setShowModal] = useState(false)
  const [showErrorModal, setShowErrorModal] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')
  const [isAPICalling, setisAPICalling] = useState(false)

  const [cardData, setCardData] = useState([])
  const [cardDataDefault, setcardDataDefault] = useState([])

  const [pageNo, setPageNo] = useState(1)
  const [pageCount, setPageCount] = useState(1)
  const [show, setShow] = useState(false)

  // For Coordinator Schedulling appt from Client Profile. Get Client ID
  const [forSelectedClientId, setForSelectedClientId] = useState(forClientId)

  const searchFilterData = isClient ? coordinatorClientSearch : coordinatorPractitionerSearch

  const [searchData, setSearchData] = useState('')
  const [searchKey, setSearchKey] = useState('userName')
  const [filterName, setFilterName] = useState('Filter')

  // For DAte time and Meeting URL
  const [value, onValueChange] = useState(appointmentDetails.date ? appointmentDetails.date : new Date())
  const [scheduleLink, setScheduleLink] = useState('')
  const [timeErrors, setTimeErrors] = useState({})
  // SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

  // DAte time and Meeting Link handlers
  const handleTimeDataChange = (e) => {
    const { name, value } = e.target
    if (value === '' || value === 'Select') {
      const timeData = appointmentDetails
      delete timeData[name]
      setAppointmentDetails(timeData)
      const errorKey = `${name}Error`
      setTimeErrors({ [errorKey]: 'Please select time' })
    } else {
      const startTime = name === 'startTime' ? value : appointmentDetails && appointmentDetails.startTime
      const endTime = name === 'endTime' ? value : appointmentDetails && appointmentDetails.endTime

      if (startTime >= endTime) {
        setTimeErrors({ endTimeError: 'Select correct end time' })
      } else {
        setTimeErrors({})
      }
    }

    if (appointmentDetails && !appointmentDetails.date) {
      const dateStr = moment(new Date()).format('dddd, D MMMM YYYY') // Monday, 24 June 2019
      setAppointmentDetails(oldState => ({ ...oldState, date: dateStr }))
    }
    if (name === 'startTime' && value !== 'Select' && appointmentDetails && !appointmentDetails.endTime) {
      // console.log('value+1::', value + 1)
      const index = timeSlots.findIndex(time => time === value)
      const endTime = index + 1 < timeSlots.length ? timeSlots[index + 1] : value

      setAppointmentDetails(oldState => ({ ...oldState, endTime: endTime }))
    }
    setAppointmentDetails(oldState => ({ ...oldState, [name]: value }))
  }
  const handleDateSelect = (e) => {
    // console.log('Selected date::', e)
    const dateStr = moment(e).format('dddd, D MMMM YYYY') // Monday, 24 June 2019
    setAppointmentDetails(oldState => ({ ...oldState, date: dateStr }))
    onValueChange(e)
  }
  const handleDateTime = (e) => {
    // console.log("Add Click", e.target.id);
    const { value } = e.target
    if (e.target.value === '') {
      setScheduleLink(value)
      const linkData = appointmentDetails
      delete linkData.link
      setAppointmentDetails(linkData)
    } else {
      setScheduleLink(value)
      setAppointmentDetails(oldState => ({ ...oldState, link: value }))
    }
  }
  /// //

  const handleSearch = (event) => {
    const searchValue = event.target.id === 'clear' ? '' : event.target.value
    // console.log("Handle search name1:-", event.target.id, searchValue);
    const searchedCards = cardDataDefault.filter((item) => {
      return Object.values(item[searchKey]).join('').toLowerCase().includes(searchValue && searchValue.toLowerCase())
    })
    setPageNo(1)
    handlePagination(searchValue === '' ? cardDataDefault : searchedCards)
    setSearchData(searchValue)
  }
  const handlePagination = (data) => {
    const pageCount = data.length % 15 ? ~~(data.length / 15) + 1 : ~~(data.length / 15)

    setPageCount(pageCount)
    const showData = data.slice((pageNo - 1) * 15, pageNo * 15)
    // console.log('Handle pagination called::')

    setCardData([...showData])
  }
  const handlePageChange = (event, value) => {
    setPageNo(value)
    // console.log('Handle page change called=:', cardData, cardDataDefault)

    const showData = cardDataDefault.slice((value - 1) * 15, value * 15)
    // console.log("showData Result=:", showData);

    setCardData([...showData])
    // console.log("Selectd page:-", value);
  }

  // Handle User's Card Selection
  const handleCardSelect = (event) => {
    if (event.target.id === '') {
      const index = cardDataDefault.findIndex(card => card.id === cardData[event.target.alt].id)

      setSelectedIndex(index)
      setSelectedUser(cardData[event.target.alt]['id'])
    } else {
      const index = cardDataDefault.findIndex(card => card.id === cardData[event.target.id].id)
      setSelectedIndex(index)
      setSelectedUser(cardData[event.target.id]['id'])
    }
  }

  // Handle Top Progress Click to move
  const handleSchedulProgress = (e) => {
    const { id } = e.target
    // setCurrentStep(id)
    // console.log('Top Progress click::', id)
    switch (id) {
      case 'step1':
        if (appointmentData.length > 0) {
          setSearchData('')
          setSelectedUser(appointmentData[0].id)
          setPageNo(1)
          setIsClient(true)
          setIsConfirm(false)
          setIsPractitioner(false)
        }

        break
      case 'step2':
        if (appointmentData.length > 1) {
          const index = cardData.findIndex(card => card.id === appointmentData[1].id)
          const dateStr = moment.utc(appointmentDetails.date).format('ddd D MMMM YYYY') // Monday, 24 June 2019
          setSearchData('')
          onValueChange(dateStr)
          setSelectedIndex(index)
          setSelectedUser(appointmentData[1].id)
          setPageNo(1)
          setIsClient(false)
          setIsPractitioner(true)
          setIsConfirm(false)
        }

        break
      case 'step3':

        if (appointmentData.length > 1) {
          setIsClient(true)
          setIsConfirm(true)
        }

        break

      default:
        break
    }
  }

  // Handle Next Button CLick for Scheduling Wizard
  const handleNext = () => {
    const index = isClient ? 0 : 1
    setSelectedIndex('')
    setSelectedUser('')
    setSearchData('')
    setPageNo(1)
    setIsClient(!isClient)
    setIsPractitioner(true)
    if (appointmentData.length > index) {
      const data = [...appointmentData]
      data[index] = cardDataDefault[selectedIndex]
      setAppointmentData(data)
    } else {
      setAppointmentData(appointmentData.concat(cardDataDefault[selectedIndex]))
    }

    if (isPractitioner) {
      setIsConfirm(true)
    }
    // handlePagination(cardDataDefault)
  }

  // Handle Create Appintment API call
  const createNewAppointment = () => {
    let apptData = Object.assign({}, appointMentInitialData)
    const dateTimeStr = `${appointmentDetails.date} ${appointmentDetails.startTime}`
    const dateTime = moment.utc(getDateFromString(`${dateTimeStr}`)).format('yyyy-MM-DDTHH:mm:ss.SSS')
    const endDateTimeStr = `${appointmentDetails.date} ${appointmentDetails.endTime}`
    const endDateTime = moment.utc(getDateFromString(`${endDateTimeStr}`)).format('yyyy-MM-DDTHH:mm:ss.SSS')
    const currentUser = JSON.parse(localStorage.getItem('currentUser'))

    // console.log('currentUser createNewAppointment', currentUser)
    apptData = {
      ...apptData,
      coordinatorId: currentUser.sub,
      createdBy: `${currentUser && currentUser.extension_FirstName} ${currentUser && currentUser.extension_LastName}`,
      tenantId: currentUser.extension_Organization,
      updatedBy: `${currentUser && currentUser.extension_FirstName} ${currentUser && currentUser.extension_LastName}`,
      clientId: appointmentData[0].id,
      practitionerId: appointmentData[1].id,
      meetingLink: appointmentDetails.link,
      meetingStartDateTime: `${dateTime.toString()}Z`,
      meetingEndDateTime: `${endDateTime.toString()}Z`

    }

    // console.log("Create Appt req::", apptData);
    setisAPICalling(true)
    const apptUrl = createAppointmentUrl(account, AppointmentsCommonUrl)
    callApiForRegistration(apptUrl, apptData)
      .then((response) => {
        // console.log("Create appointment API Resp:-", response);
        setisAPICalling(false)
        if (response && response === 'New Appointment Created Successfully.') {
          setShowModal(true)
        } else {
          setShowErrorModal(true)
        }
        setErrorMessage(response)
      })
      .catch(error => console.log('API Catch eror main class', error))
  }

  // Handle Update Appintment API call
  const updateAppointment = () => {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'))
    const TENANTNAME = currentUser && currentUser.extension_Organization
    const dateTimeStr = `${appointmentDetails.date} ${appointmentDetails.startTime}`
    const dateTime = moment.utc(getDateFromString(`${dateTimeStr}`)).format('yyyy-MM-DDTHH:mm:ss.SSS')
    const endDateTimeStr = `${appointmentDetails.date} ${appointmentDetails.endTime}`
    const endDateTime = moment.utc(getDateFromString(`${endDateTimeStr}`)).format('yyyy-MM-DDTHH:mm:ss.SSS')
    const reqUrl = `${createAppointmentUrl(account, AppointmentsCommonUrl)}/${editAppointmentData.appointmentId}`
    // const reqUrl = `${CreateAppointment}/${editAppointmentData.appointmentId}`
    const apptData = {
      appointmentId: editAppointmentData.appointmentId,
      status: 'Scheduled',
      coordinatorId: `${currentUser && currentUser.sub}`,
      tenantId: TENANTNAME,
      clientId: appointmentData[0].id,
      practitionerId: appointmentData[1].id,
      meetingLink: appointmentDetails.link,
      meetingStartDateTime: `${dateTime.toString()}Z`,
      meetingEndDateTime: `${endDateTime.toString()}Z`

    }

    setisAPICalling(true)
    callApiForRegistration(reqUrl, apptData)
      .then((response) => {
        // console.log("Create appointment API Resp:-", response);
        setisAPICalling(false)
        if (response && response === 'Appointment Updated Successfully.') {
          setShowModal(true)
        } else {
          setShowErrorModal(true)
        }
        setErrorMessage(response)
      })
      .catch(error => console.log('API Catch eror main class', error))
  }

  // Handle Filter change
  const handleFilterChange = (event, value) => {
    // console.log('Value::', value)
    if (event.target.id !== 'filter') {
      // console.log('inside if handleFilterChange::')

      const filterNameValue = event.target.name === '' ? filterName : event.target.name
      setFilterName(filterNameValue)
      setSearchKey(event.target.id)
    }

    setShow(!show)
  }

  // Get listing of the Practitioner
  const getAllPractitionerListing = () => {
    setisAPICalling(true)
    setcardDataDefault([])
    setCardData([])
    const practitionerListingUrl = getPractitionerListingUrl(account, CoordinatorBaseURL)
    callApiForListing(practitionerListingUrl)
      .then((response) => {
        // console.log('Practitioner Listing API Resp:-', response)
        const finalResp = response && typeof (response) === 'object' ? response : []
        setSearchKey('userName')
        setisAPICalling(false)
        setcardDataDefault([...finalResp])
        setCardData([...finalResp])
        if (editAppointment) {
          const index = finalResp.findIndex(card => card.id === editAppointmentData.practitionerId)
          setSelectedUser(editAppointmentData.practitionerId)
          setEditAppointment(false)
          setAppointmentData(appointmentData.concat(finalResp[index]))
          setSelectedIndex(index)
          const dateStr = moment(editAppointmentData.meetingStartDateTime).format('dddd, D MMMM YYYY') // Monday, 24 June 2019
          const timeConst = moment(new Date(new Date(editAppointmentData.meetingStartDateTime).setHours(new Date(editAppointmentData.meetingStartDateTime).getHours()))).format('HH:mm')
          const endTimeConst = moment(new Date(new Date(editAppointmentData.meetingEndDateTime).setHours(new Date(editAppointmentData.meetingEndDateTime).getHours()))).format('HH:mm')
          setScheduleLink(editAppointmentData.meetingLink)
          onValueChange(dateStr)
          setAppointmentDetails({
            date: dateStr,
            startTime: timeConst,
            endTime: endTimeConst,
            link: editAppointmentData.meetingLink
          })
        } else {
          setForSelectedClientId('')
          if (appointmentData.length > 1) {
            const index = finalResp.findIndex(card => card.id === appointmentData[1].id)
            // console.log('selectedIndex step2::', index)
            setSelectedIndex(index)
          }
        }
        handlePagination([...finalResp])
      })
  }

  // Get listing for the clients
  const getAllClientListing = () => {
    setisAPICalling(true)

    const clientListingUrl = getClientListingUrl(account, CoordinatorBaseURL)
    callApiForListing(clientListingUrl)
      .then((response) => {
        // console.log('Client Listing API Resp:-', response)

        const finalResp = response && typeof (response) === 'object' ? response : []
        setisAPICalling(false)
        setcardDataDefault([...finalResp])
        setCardData([...finalResp])
        if (editAppointment) {
          const index = finalResp.findIndex(card => card.id === editAppointmentData.clientId)
          setSelectedUser(editAppointmentData.clientId)
          setAppointmentData(appointmentData.concat(finalResp[index]))
          setSelectedIndex(index)
          setPageNo(1)
          setIsClient(false)
          setIsPractitioner(true)
          setIsConfirm(false)
          // handleNext()
        } else if (forSelectedClientId !== '') {
          const index = finalResp.findIndex(card => card.id === forSelectedClientId)
          setSelectedUser(forSelectedClientId)
          setAppointmentData(appointmentData.concat(finalResp[index]))
          setSelectedIndex(index)
          setPageNo(1)
          setIsClient(false)
          setIsPractitioner(true)
          setIsConfirm(false)
          // handleNext()
        } else {
          if (appointmentData.length > 0) {
            const index = finalResp.findIndex(card => card.id === appointmentData[0].id)
            setSelectedIndex(index)
          }
          handlePagination([...finalResp])
        }
      })
  }

  useEffect(() => {
    getAllClientListing()
  }, [])
  useEffect(() => {
    if (!isConfirm && isClient && !editAppointment) {
      getAllClientListing()
    }
    if (!isConfirm && isPractitioner) {
      getAllPractitionerListing()
    }

    //    handlePagination(cardDataDefault)
  }, [isConfirm, isPractitioner, isClient])

  const handleModalPopUp = () => {
    setShowModal(!showModal)
    // handleAllClientChange()
    const message = `You have successfully scheduled an appointment for ${appointmentData[0].userName} with ${appointmentData[1].userName}!`
    handleAppointmentChange(message)
  }
  const handleErrorModalPopUp = () => {
    setShowErrorModal(false)
  }

  const clientDataArr = []
  return (
    <>
      <ModalPopUp handleModalPopUp={handleModalPopUp} show={showModal} header="Schedule Appointment" messageBody={errorMessage} />
      <ModalPopUp handleModalPopUp={handleErrorModalPopUp} show={showErrorModal} header="Error!" messageBody={errorMessage} />
      <LoaderModalPopUp show={isAPICalling} message='Appointment Scheduling...' />
      <div style={{ backgroundColor: 'white', borderRadius: '20px', border: '2px' }}>
        <div style={{ padding: '20px', color: '#139ED7', fontFamily: 'Roboto, light', fontSize: '20px', display: 'flex', justifyContent: 'space-between' }}>

        </div>
        <ScheduleAppointmentProgress isClient={isClient} isPractitioner={isPractitioner} isConfirm={isConfirm} handleSchedulProgress={handleSchedulProgress} />
        {isPractitioner && !isClient && (
          <>
          {/* {console.log('isConfirm ? appointmentData : clientDataArr.concat(appointmentData[0])} />', isConfirm, appointmentData, clientDataArr.concat(appointmentData[0]))} */}
            <ClientAppointmentCard appointmentData={isConfirm ? appointmentData : clientDataArr.concat(appointmentData[0])} />
          </>
        )}
        <div style={{
          position: 'relative',
          float: 'right',
          marginRight: '30px'
        }}>
          {!isConfirm && <SearchComponent filterArr={searchFilterData} onSearchClick={handleSearch} searchValue={searchData} handleFilterChange={handleFilterChange} filterName={filterName} />}
        </div>
        <div style={{ marginLeft: '30px' }}>

          {isConfirm
            ? <AppointmentConfirm appointmentData={appointmentData} appointmentDetails={appointmentDetails} />
            : (
            <>
            <ScheduleAppointmentCard isClient={isClient} isPractitioner={isPractitioner} selectedUser={selectedUser} cardData={cardData} pageNo={pageNo} pageCount={pageCount} handlePageChange={handlePageChange} handleCardSelect={handleCardSelect} />
            </>
              )}
        </div>
        <div>
          {isPractitioner && !isConfirm && (
            <PractitionerDateTime handleTimeDataChange={handleTimeDataChange} handleDateTime={handleDateTime} value={value} scheduleLink={scheduleLink} handleDateSelect={handleDateSelect} timeErrors={timeErrors} appointmentDetails={appointmentDetails} />
          )}
        </div>
        {!isConfirm && (
          <div style={{ float: 'right', paddingRight: '20px' }}>
            <Button style={{ backgroundColor: '#F24B5D', borderRadius: '5px', border: 'none', color: 'white' }} onClick={handleNext} disabled={!isPractitioner ? selectedUser === '' : (selectedUser === '' || Object.keys(appointmentDetails).length < 4 || Object.keys(timeErrors).length > 0)} >NEXT</Button>
          </div>
        )}
        {isConfirm && (
          <div style={{ float: 'right' }}>
            <Button style={{ backgroundColor: '#F24B5D', borderRadius: '5px', border: 'none', color: 'white', marginRight: 20 }} onClick={editAppointmentData.isEdit ? updateAppointment : createNewAppointment} >CONFIRM APPOINTMENT</Button>
          </div>
        )}
      </div>
      <br />
      <br />
    </>
  )
}

ScheduleAppointment.propTypes = {
  handleAppointmentChange: PropTypes.func.isRequired,
  editAppointmentData: PropTypes.object,
  forClientId: PropTypes.string
}
