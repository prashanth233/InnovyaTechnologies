import React from 'react'
import { Avatar, Divider } from '@mui/material'
import { Col, Row } from 'react-bootstrap'
import PropTypes from 'prop-types'

export const ScheduleAppointmentProgress = ({ isPractitioner, isConfirm, handleSchedulProgress }) => {
  // console.log("All props data:-",props.isClient, props.isPractitioner, props.isConfirm);
  const step1Color = isPractitioner ? '#4C927E' : '#F24B5D'
  const step2Color = isPractitioner && !isConfirm ? '#F24B5D' : isConfirm ? '#4C927E' : '#B2B2B9'
  const step3Color = isConfirm ? '#F24B5D' : '#B2B2B9'

  return (
        <>
            <Row className="justify-content-center">
                <Col md="auto" >
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                        <Avatar id="step1" onClick={handleSchedulProgress} sx={{ border: '5px double white', bgcolor: step1Color }} >1</Avatar>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                        <label variant="info" style={{ fontFamily: 'Roboto', fontSize: '18px', color: step1Color }}>Select Client</label>
                    </div>
                </Col>
                <Divider variant="middle" style={{ padding: '15px', marginLeft: '-35px', marginRight: '-120px', marginTop: '-10px', width: '130px' }} />

                <Col md="auto" >
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                        <Avatar id="step2" onClick={handleSchedulProgress} sx={{ border: '5px double white', bgcolor: step2Color }}>2</Avatar>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'center', textAlign: 'center' }}>
                        <label variant="info" style={{ fontFamily: 'Roboto', fontSize: '18px', color: step2Color, width: 270 }}>Select Practitioner, Time & Date, Add Meeting Link</label>
                    </div>
                </Col>
                <Divider variant="middle" style={{ padding: '15px', marginLeft: '-120px', marginRight: '-15px', marginTop: '-10px', width: '130px' }} />
                <Col md="auto" >
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                        <Avatar id="step3" onClick={handleSchedulProgress} sx={{ border: '5px double white', bgcolor: step3Color }}>3</Avatar>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                        <label variant="info" style={{ fontFamily: 'Roboto', fontSize: '18px', color: step3Color }}>Confirm</label>
                    </div>
                </Col>
            </Row>

        </>
  )
}

ScheduleAppointmentProgress.propTypes = {
  isPractitioner: PropTypes.bool.isRequired,
  isConfirm: PropTypes.bool.isRequired,
  handleSchedulProgress: PropTypes.func.isRequired
}
