import React, { useEffect, useState } from 'react'
import { useMsal, useAccount } from '@azure/msal-react'
import { Button, Col, Image, Row } from 'react-bootstrap'
import { UserDetails } from './UserDetails'
import { EditProfile } from './EditProfile'
import { ClientAppointmentsListing } from './ClientAppointmentsListing'
import { useHistory, useParams } from 'react-router-dom'
import { Assessments } from './Assessments'
import { NotesSection } from './NotesSection'
import { WellBeingProfile } from './WellBeingProfile'
import { ClientAssessmentsChart } from './ClientAssessmentsChart'
import calImg from '../Assets/Calendar.png'
import fileDocImg from '../Assets/filedocument.png'
import notesImg from '../Assets/notes.png'
import wellbeingImg from '../Assets/wellbeing.png'
import chartImg from '../Assets/chart.png'
import { Divider } from '@mui/material'
import { ModalPopUp } from '../CommonData/ModalPopUp'

const currentRole = JSON.parse(localStorage.getItem('UserType'))

export const ClientProfile = () => {
  const [editProfile, setEditProfile] = useState(false)
  const { accounts, instance } = useMsal()
  const account = useAccount(accounts[0] || {})
  const userDataLocal = JSON.parse(localStorage.getItem('UserData'))
  const [showLogOutErrorModal, setShowLogOutErrorModal] = useState(false)

  const [userData, setUserData] = useState({})
  const history = useHistory()
  const params = useParams()
  const userId = params.userId.substring(1)
  // console.log('inside ClientProfile::', params.userId.substring(1))
  const handleEditProfile = (event) => {
    setUserData(event)
    setEditProfile(!editProfile)
  }
  const viewAppointmentClicked = (obj, tabSelected) => {
    // console.log("Client profile A/ppt Details::", obj, tabSelected);
    history.push('/appointments', { apptDet: obj, tabSelected: tabSelected })
    window.location.reload('false')
  }
  const scheduleAppointmentClicked = () => {
    // console.log("Client profile A/ppt Details::", obj, tabSelected);
    history.push('/appointments', { userId: userId })
  }
  const allClientsClicked = () => {
    // console.log("Client profile A/ppt Details::", obj, tabSelected);
    history.push('/clients')
  }
  // This useeffect is used to check if any other user is logged in in other tab or not
  useEffect(() => {
    if (account.idTokenClaims.sub !== userDataLocal.id) {
      setShowLogOutErrorModal(true)
    }
  })
  const logOutUser = () => {
    // localStorage.clear()
    instance.logoutRedirect({ postLogoutRedirectUri: '/' })
  }

  return (
    // <WorkInProgress />
    <>
      <ModalPopUp handleModalPopUp={logOutUser} show={showLogOutErrorModal} header="Error!" messageBody='Another user is logged in. You will be logout' />

      <div style={{ backgroundColor: '#FFF5F6', padding: '20px' }}>
        <div style={{ backgroundColor: 'white', borderRadius: '20px', border: '2px' }}>
          <div style={{ padding: '20px', color: '#139ED7', fontFamily: 'Roboto, light', fontSize: '20px', display: 'flex', justifyContent: 'space-between' }}>
            <p></p>
            <Button variant="danger" style={{ backgroundColor: 'white', color: '#F24B5D', border: 'none' }} onClick={allClientsClicked} >ALL CLIENTS</Button>
          </div>
          <Divider variant="middle" />
          {
            editProfile
              ? (
                <div style={{ margin: '20px' }}>
                  <EditProfile handleEditProfile={handleEditProfile} userData={userData} />
                </div>
                )
              : (

                <Row style={{ paddingBottom: '30px', margin: '20px 5px' }}>
                  <Col >
                    <UserDetails handleEditProfile={handleEditProfile} userId={userId} />
                  </Col>
                  <Col>
                    {
                      currentRole === 'Practitioner' && (
                        <Row style={{ width: '72vw' }}>
                          <Col style={{ width: '33vw' }}>
                            <>
                              <div style={{ fontFamily: 'Roboto', fontSize: '20px', color: '#139ED7', width: '100%', marginLeft: '-15px' }}>
                                {/* {'Well-being Profile'} */}
                                <div>
                                  <Image style={{ marginTop: '-3px', width: '24px', height: '24px' }} src={wellbeingImg} />
                                  <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto, Light', fontSize: '20px', color: '#139ED7' }}>{'Well-being Profile'}</label>
                                </div>
                              </div>
                              <div style={{ width: '100%', marginLeft: '-15px' }}>
                                <WellBeingProfile clientUserId={userId} />
                              </div>
                            </>
                          </Col>
                          <Col style={{ width: '33vw' }}>
                            <>
                              <div style={{ fontFamily: 'Roboto', fontSize: '20px', color: '#139ED7', width: '100%', display: 'flex', justifyContent: 'space-between' }}>
                                <div>
                                  <Image style={{ marginTop: '-3px', width: '24px', height: '24px' }} src={chartImg} />
                                  <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto, Light', fontSize: '20px', color: '#139ED7' }}>{'Assessment Chart'}</label>
                                </div>
                              </div>
                              <div style={{ width: '100%' }}>
                                <ClientAssessmentsChart clientUserId={userId} comingFrom='' />
                              </div>
                            </>
                          </Col>
                        </Row>
                      )
                    }
                    <Row style={{ width: '72vw' }}>
                      <>
                        <div style={{ fontFamily: 'Roboto', fontSize: '20px', color: '#139ED7', width: '100%', paddingTop: '10px' }}>
                          <div>
                            <Image style={{ marginTop: '-3px', width: '24px', height: '24px' }} src={calImg} />
                            <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto, Light', fontSize: '20px', color: '#139ED7' }}>{'Appointments'}</label>
                          </div>
                          <ClientAppointmentsListing userId={userId} scheduleAppointmentClicked={scheduleAppointmentClicked} viewAppointmentClicked={viewAppointmentClicked} />
                        </div>
                      </>
                    </Row>
                    {
                      currentRole === 'Coordinator' && (
                        <Row style={{ width: '72vw' }}>
                          <>
                            <div style={{ fontFamily: 'Roboto', fontSize: '20px', color: '#139ED7', width: '100%', display: 'flex', justifyContent: 'space-between', paddingTop: '10px' }}>

                              <div>
                                <Image style={{ marginTop: '-3px', width: '24px', height: '24px' }} src={fileDocImg} />
                                <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto, Light', fontSize: '20px', color: '#139ED7' }}>{'Assessments'}</label>
                              </div>
                            </div>
                            <div style={{ width: '100%' }}>
                              <Assessments clientId={userId} widthData="71vw" viewAppointmentClicked={viewAppointmentClicked} />
                            </div>
                          </>
                        </Row>
                      )
                    }
                    {
                      currentRole === 'Practitioner' && (
                        <Row >
                          <Col style={{ width: '33vw' }}>
                            <>
                              <div style={{ fontFamily: 'Roboto', fontSize: '20px', color: '#139ED7', width: '100%', display: 'flex', justifyContent: 'space-between', paddingTop: '10px', marginLeft: '-15px' }}>
                                <div>
                                  <Image style={{ marginTop: '-3px', width: '24px', height: '24px' }} src={fileDocImg} />
                                  <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto, Light', fontSize: '20px', color: '#139ED7' }}>{'Assessments'}</label>
                                </div>
                              </div>
                              <div style={{ width: '100%', marginLeft: '-15px' }}>
                                <Assessments clientId={userId} widthData="32vw" viewAppointmentClicked={viewAppointmentClicked} />
                              </div>
                            </>
                          </Col>
                          <Col style={{ width: '33vw' }}>
                            <>
                              <div style={{ fontFamily: 'Roboto', fontSize: '20px', color: '#139ED7', width: '100%', display: 'flex', justifyContent: 'space-between', paddingTop: '10px' }}>

                                <div>
                                  <Image style={{ marginTop: '-3px', width: '24px', height: '24px' }} src={notesImg} />
                                  <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto, Light', fontSize: '20px', color: '#139ED7' }}>{'Notes'}</label>
                                </div>
                              </div>
                              <div style={{ width: '100%' }}>
                                <NotesSection userId={userId} comingFrom='profile' />
                              </div>
                            </>
                          </Col>
                        </Row>
                      )
                    }

                  </Col>
                </Row>

                )
          }
        </div>
      </div>
    </>
  )
}
