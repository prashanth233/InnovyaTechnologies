import React from 'react'
import loaderImg from '../Assets/spp.gif'

const Loader = () => {
  return (
  // eslint-disable-next-line
        <img src={loaderImg }style={{ width:'200px', margin:'auto' , display:'block' , alt:'Loading'}}/>

  )
}

export default Loader
