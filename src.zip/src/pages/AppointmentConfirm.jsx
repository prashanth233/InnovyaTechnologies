import React from 'react'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import Typography from '@mui/material/Typography'
import { Avatar, Grid } from '@mui/material'
import { Col, Row, Image } from 'react-bootstrap'
import phoneImg from '../Assets/phoneIcon.png'
import { getDateFromString, getFormatedDateFromString } from '../CommonData/CommonFunction'
import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import PropTypes from 'prop-types'
import moment from 'moment'

export const AppointmentConfirm = ({ appointmentDetails, appointmentData }) => {
  const startDateTimeStr = `${appointmentDetails.date} ${appointmentDetails.startTime}`
  const startDateTime = moment(getDateFromString(`${startDateTimeStr}`)).format('hh:mm A')
  const endDateTimeStr = `${appointmentDetails.date} ${appointmentDetails.endTime}`
  const endDateTime = moment(getDateFromString(`${endDateTimeStr}`)).format('hh:mm A')
  return (
        <>
            <Grid
                container
                spacing={8}
                direction="row"
                // marginLeft="10px"
                justifyContent="center"
                alignItems="center"
            >
                {appointmentData && appointmentData.map(elem => (
                    <Grid item key={appointmentData.indexOf(elem)} >
                        <div style={{ color: '#6A6A6A', fontFamily: 'Roboto', fontSize: '18px' }}>{appointmentData.indexOf(elem) === 0 ? 'Client' : 'Practitioner'}</div>
                        <Card id={appointmentData.indexOf(elem)} variant="outlined" sx={{ width: 216, height: 280, border: '2px solid #EEEEEE' }} >

                            <div style={{ display: 'flex', justifyContent: 'center', marginTop: '15px' }}>
                                <Avatar
                                    src={elem.photoId === '' ? ProfilePlaceholder : elem.photoId}
                                    sx={{ width: 180, height: 180, justifyContent: 'center', alignItems: 'center' }}
                                />
                            </div>
                            <CardContent spacing={1}>
                                <div style={{ fontFamily: 'Roboto', fontSize: '16px', textAlign: 'center', color: '#139ED7' }}>
                                    <Typography gutterBottom>
                                        {elem.userName}
                                    </Typography>
                                    {appointmentData.indexOf(elem) === 0
                                      ? (
                                            <Typography >
                                                <p style={{ fontSize: '12px', color: '#9E9E9E' }}>DOB  <span style={{ fontSize: '15px', color: '#2D2D34', marginLeft: '10px' }}>{getFormatedDateFromString(elem.dob)}</span> </p>
                                            </Typography>
                                        )
                                      : (
                                            <Typography>
                                                <Row className="justify-content-center">
                                                    <Col md='auto'>
                                                        <Image style={{ width: '18px', height: '18px' }} src={phoneImg} />
                                                        <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto', fontSize: '16px', color: '#6A6A6A' }}>{elem.mobileNo}</label>
                                                    </Col>
                                                </Row>
                                            </Typography>
                                        )
                                    }
                                </div>
                            </CardContent>
                        </Card>
                    </Grid>
                ))}

                <div style={{ marginTop: '-150px', paddingLeft: '3vw' }}>
                    <div style={{ color: '#6A6A6A', fontFamily: 'Roboto, Light', fontSize: '18px' }}>
                        Date & Time
                    </div>

                    <p style={{ fontFamily: 'Roboto, Regular', fontSize: '16px', color: '#2D2D34' }}>On  <span style={{ fontFamily: 'Roboto, Regular', fontSize: '16px', color: '#139ED7' }}>{appointmentDetails.date}</span> </p>
                    <p style={{ fontFamily: 'Roboto, Regular', fontSize: '16px', color: '#2D2D34', marginTop: '-15px' }}>at  <span style={{ fontFamily: 'Roboto, Regular', fontSize: '16px', color: '#139ED7' }}>{appointmentDetails && startDateTime}</span> to <span style={{ fontFamily: 'Roboto, Regular', fontSize: '16px', color: '#139ED7' }}>{appointmentDetails && endDateTime}</span> </p>
                </div>
            </Grid>
            <br />
            <br />

        </>
  )
}

AppointmentConfirm.propTypes = {
  appointmentDetails: PropTypes.object,
  appointmentData: PropTypes.array
}
