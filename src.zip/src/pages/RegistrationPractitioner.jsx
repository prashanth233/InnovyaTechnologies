/* eslint-disable no-unreachable */
/* eslint-disable array-callback-return */
import React, { useState, useRef } from 'react'
import '../styles/App.css'
import { Form, Col, Row, Button } from 'react-bootstrap'
import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import ProfileEdit from '../Assets/ProfileEdit.png'
import { Avatar, Badge, Checkbox } from '@mui/material'
import { styled } from '@mui/material/styles'
import { LabelComponent, LabelComponentRequired, LabelHeaderComponent } from './LabelComponent'
import Radio from '@mui/material/Radio'
import RadioGroup from '@mui/material/RadioGroup'
import FormControlLabel from '@mui/material/FormControlLabel'
import Loader from './Loader'
import { LoaderModalPopUp, ModalPopUp } from '../CommonData/ModalPopUp'
import { practitionerInitialData } from '../CommonData/RegistrationInitialData'
import { callApiForRegistration } from '../fetch'
import { PractitionerRegistration } from '../CommonData/APIListing'
import PropTypes from 'prop-types'

export const RegistrationPractitioner = ({ handleAllPractitionerChange }) => {
  const profileFile = useRef(null)
  const [isLoading, setLoading] = useState(false)
  const [imgFile, setImgFile] = useState(ProfilePlaceholder)
  const [errors, setErrors] = useState([])

  const [registrationData, setRegistrationData] = useState(practitionerInitialData)

  const [showModal, setShowModal] = useState(false)
  const [showErrorModal, setShowErrorModal] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')

  const [isAPICalling, setIsAPICalling] = useState(false)
  const currentUser = JSON.parse(localStorage.getItem('currentUser'))

  const handleSubmit = (event) => {
    const requiredDataCheck = Object.assign({}, registrationData)

    const deleteKeysData = ['middleName', 'languagePreference', 'insurenceName', 'insurenceId', 'noInsurencePlan', 'photoId', 'consultationRate', 'npi', 'tenantId', 'specialties', 'services', 'practitionerPracticeName', 'address', 'city', 'state', 'zip', 'userName']
    deleteKeysData.forEach(element => {
      delete requiredDataCheck[element]
    })

    const errorsData = []
    if (registrationData.consultationRate && registrationData.consultationRate.length > 0) {
      const numericValidation = /[0-9]+$/.exec(registrationData.consultationRate)
      const validNumber = !numericValidation
      validNumber && errorsData.push('consultationRate')
    }
    Object.entries(requiredDataCheck).map(([key, value]) => {
      value.length === 0 && errorsData.push(key)
      if (key === 'email') {
        const expression = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+\.)+([a-zA-Z]{2,4})+$/ /// \S+@\S+/;
        const validEmail = expression.test(String(value).toLowerCase())
        if (!validEmail) {
          errorsData.push(key)
        }
      }
      if (key === 'mobileNo') {
        // eslint-disable-next-line no-useless-escape
        const res = /^[+0-9]+$/.exec(value)
        const validUserName = !res
        if (validUserName) {
          errorsData.push(key)
        }
      }
      if (!Number(value) && ['mobileNo'].indexOf(key) !== -1) {
        errorsData.push(key)
      }
      setErrors(errorsData)
    })
    console.log('Error data', errorsData.length)
    if (errorsData.length === 0) {
      // console.log('Inside Validation data', errorsData);

      event.stopPropagation()
      saveFormData()
    }
  }
  const handleReset = (event) => {
    setRegistrationData({})
    setImgFile(ProfilePlaceholder)
    // event.preventDefault();
    // event.stopPropagation();
  }
  const SmallAvatar = styled(Avatar)(({ theme }) => ({
    left: -10,
    top: -5,
    width: 30,
    height: 30,
    border: '1px solid #F24B5D' // ${theme.palette.background.paper}
  }))

  const hasError = (key) => {
    return errors.indexOf(key) !== -1
  }

  const handleDataChange = (e) => {
    const { name, value, checked, type } = e.target
    // console.log('Target name, value, checked, type ::', name, value, checked, type)
    const errors = []

    if (!Number(value) && ['mobileNo', 'consultationRate'].indexOf(name) !== -1) {
      errors.push(name)
    }

    if (name === 'mobileNo') {
      // eslint-disable-next-line no-useless-escape
      const res = /^[+0-9]+$/.exec(value)
      const validUserName = !res
      if (validUserName) {
        errors.push(name)
      }
    }

    // email
    // const expression = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/
    const expression = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/

    const validEmail = expression.test(String(value).toLowerCase())

    if (!validEmail && name === 'email') {
      errors.push(name)
    }
    setErrors(errors)
    setRegistrationData(oldState => ({ ...oldState, [name]: type === 'checkbox' ? checked : value }))
  }

  const handleFileChange = (event) => {
    setLoading(true)
    const file = event.target.files[0]
    const reader = new FileReader()

    reader.onload = () => {
      // console.log('Img data::', reader.result)
      setImgFile(reader.result)
      setLoading(false)
      setRegistrationData(oldState => ({ ...oldState, [event.target.id]: reader.result }))
    }
    reader.readAsDataURL(file)
  }

  // Registration API
  const saveFormData = () => {
    let saveData = Object.assign({}, registrationData)

    delete saveData.services
    // console.log('saveData after delete:-', saveData)

    const servicesData = registrationData.coaching && registrationData.services
      ? 'coaching, psychotherapy'
      : registrationData.coaching ? 'coaching' : registrationData.services ? 'psychotherapy' : ''
    // console.log('servicesData:-', servicesData)

    saveData = {
      ...saveData,
      // languagePreference: langPrefCode,
      practiceName: currentUser.extension_PracticeName,
      tenantId: currentUser.extension_Organization,
      services: servicesData
    }

    // console.log('saveData Resp:-', saveData, registrationData)

    setIsAPICalling(true)

    callApiForRegistration(PractitionerRegistration, saveData)
      .then((response) => {
        // console.log("API Resp:-", response);
        setIsAPICalling(false)
        if (response && response === 'New Practitioner Created Successfully.') {
          setShowModal(true)
        } else {
          setShowErrorModal(true)
        }
        setErrorMessage(response)
      })
  }
  const handleModalPopUp = () => {
    setShowModal(!showModal)
    handleAllPractitionerChange()
  }
  const handleErrorModalPopUp = () => {
    setShowErrorModal(false)
  }

  return (
    <>
    <ModalPopUp handleModalPopUp={handleModalPopUp} show={showModal} header="Practitioner Registration" messageBody={errorMessage} />
    <ModalPopUp handleModalPopUp={handleErrorModalPopUp} show={showErrorModal} header="Error!" messageBody={errorMessage} />
    <LoaderModalPopUp show={isAPICalling} message='Practitioner Registration is in progress...' />
    <Form noValidate onReset={handleReset}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <div>
          <Row>
            <Form.Group as={Col} md="4" controlId="validationCustom01">
              <LabelComponentRequired name="First Name " />
              <Form.Control
                required
                type="text"
                placeholder="First Name"
                name='firstName'
                value={registrationData.firstName}
                onChange={handleDataChange}
                style={{ borderColor: hasError('firstName') ? '#F24B5D' : '', boxShadow: 'none' }}
                />
                <div
                  className={hasError('firstName') ? 'inline-errormsg' : 'hidden'}
                >
                  Please provide First Name
                </div>
            </Form.Group>
            <Form.Group as={Col} md="4" controlId="validationCustom02">
              <LabelComponent name="Middle Name " />
              <Form.Control
                type="text"
                placeholder="Middle Name"
                name='middleName'
                value={registrationData.middleName}
                onChange={handleDataChange}
              />
            </Form.Group>
            <Form.Group as={Col} md="4" controlId="validationCustom02">
              <LabelComponentRequired name="Last Name " />
              <Form.Control
                required
                type="text"
                placeholder="Last Name"
                name='lastName'
                value={registrationData.lastName}
                onChange={handleDataChange}
                style={{ borderColor: hasError('lastName') ? '#F24B5D' : '', boxShadow: 'none' }}
                />
                <div
                  className={hasError('lastName') ? 'inline-errormsg' : 'hidden'}
                >
                  Please provide Last Name
                </div>
            </Form.Group>
          </Row>
          <Row className="mb-3">
            <Form.Group as={Col} md="4" controlId="validationCustom03">
              <LabelComponentRequired name="Email " />
              <Form.Control type="text" name="email" value={registrationData.email} onChange={handleDataChange} placeholder="Email" style={{ borderColor: hasError('email') ? '#F24B5D' : '', boxShadow: 'none' }} required />
              <div
                className={hasError('email') ? 'inline-errormsg' : 'hidden'}
              >
                Email is invalid or missing
              </div>
            </Form.Group>
            <Form.Group as={Col} md="4" controlId="validationCustom03">
              <LabelComponentRequired name="Mobile Number " />
              <Form.Control type="text" name="mobileNo" value={registrationData.mobileNo} onChange={handleDataChange} placeholder="Mobile Number" required style={{ borderColor: hasError('mobileNo') ? '#F24B5D' : '', boxShadow: 'none' }} />
              <div
                className={hasError('mobileNo') ? 'inline-errormsg' : 'hidden'}
              >
                Please enter valid mobile number
              </div>
            </Form.Group>
            <Form.Group as={Col} md="4" controlId="validationCustom03">
              <LabelComponent name="NPI " />
              <Form.Control type="text" name="npi" value={registrationData.npi} onChange={handleDataChange} placeholder="NPI" />
            </Form.Group>
          </Row>
          <Row>
      </Row>
        </div>
        <div>
          <p>Upload Photo</p>
          <div style={{ marginRight: '35px', paddingTop: '13px', width: '160px', height: '160px', border: '1px solid #DFDFDF', display: 'flex', justifyContent: 'center', marginTop: '-15px' }}>
            {
              isLoading
                ? (
                <Loader />
                  )
                : (
                  <>
                    <Badge
                      overlap="circular"
                      anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                      badgeContent={
                        <SmallAvatar onClick={() => profileFile.current.click()} src={ProfileEdit} />
                      }
                    >
                      <Avatar
                        src={imgFile}
                        rounded
                        sx={{ width: 132, height: 132 }}
                      />
                    </Badge>
                    <input
                      id="photoId"
                      ref={profileFile}
                      type="file"
                      style={{ display: 'none' }}
                      accept="image/*"
                      onChange={handleFileChange}
                    />
                  </>
                  )
            }

          </div>
        </div>
      </div>
      <Row>
      <Form.Group as={Col} md="4" controlId="validationCustom03">
          <LabelComponent name="Coordinator's Practice Name " />
          <Form.Control type="text" value={registrationData.practiceId} name="practiceId" disabled />
        </Form.Group>
        <Form.Group as={Col} md="4" controlId="validationCustom03">
          <LabelComponent name="Practitioner's Practice Name " />
          <Form.Control type="text" value={registrationData.practitionerPracticeName} name="practitionerPracticeName" onChange={handleDataChange} placeholder="Practitioner's Practice Name" />
        </Form.Group>
      </Row>
      <Row>
        <Form.Group as={Col} md="8" controlId="validationCustom03">
          <LabelComponentRequired name="Gender " />
          <RadioGroup row aria-label="gender" name="gender" style={{ fontFamily: 'Roboto', fontSize: '5px', color: 'gray' }} onChange={handleDataChange}>
            <FormControlLabel value="female" control={<Radio style={{ fontFamily: 'Roboto', fontSize: '5px', marginLeft: '10px' }} />} label="Female" />
            <FormControlLabel value="male" control={<Radio style={{ paddingLeft: '20px' }} />} label="Male" />
            <FormControlLabel value="other" control={<Radio style={{ paddingLeft: '20px' }} />} label="Other" />
          </RadioGroup>
          <div
            className={hasError('gender') ? 'inline-errormsg' : 'hidden'}
          >
            Please select gender
          </div>
        </Form.Group>
      </Row>
      <Row>
      <Form.Group as={Col} md="3" controlId="validationCustom03">
          <LabelComponent name="Services " />
          <RadioGroup row aria-label="services" name="services" style={{ fontFamily: 'Roboto', fontSize: '5px', color: 'gray' }}>
            <FormControlLabel name="services" value="services" control={<Checkbox name="services" onChange={handleDataChange} style={{ fontFamily: 'Roboto', fontSize: '5px', marginLeft: '10px' }} />} label="Psychotherapy" />
            <FormControlLabel name="coaching" value="coaching" control={<Checkbox name="coaching" onChange={handleDataChange} style={{ paddingLeft: '20px' }} />} label="Coaching" />
          </RadioGroup>
        </Form.Group>
      </Row>
      <Row className="mb-3">
        <Form.Group as={Col} md="6" controlId="validationCustom03">
          <LabelComponent name="Specialties " />
          <Form.Control type="text" placeholder="Specialties" name="specialties" onChange={handleDataChange} value={registrationData.specialties} style={{ boxShadow: 'none' }} />
        </Form.Group>
      </Row>
      <Form.Group controlId="validationCustom03">
        <LabelHeaderComponent name="Insurance Details " />
        <Row>
          <Form.Group as={Col} md="3" controlId="validationCustom03">
            <LabelComponent name="Insurance Name " />
            <Form.Control type="text" placeholder="Insurance Name" name="insuranceName" onChange={handleDataChange} value={registrationData.insuranceName} />
          </Form.Group>
        </Row>
        <Form.Group className="mb-3">
        <FormControlLabel value="noInsurencePlan" style={{ fontFamily: 'Roboto', fontSize: '2px', color: 'gray' }} control={<Checkbox onChange={handleDataChange} style={{ fontFamily: 'Roboto', fontSize: '2px', marginLeft: '10px' }} />} label="No Insurance Plan" />
        </Form.Group>
      </Form.Group>

      <Form.Group controlId="validationCustom03">
        <Row >
          <Form.Group as={Col} md="3" controlId="validationCustom03">
            <LabelComponent name="Consultation Hourly Rate (Dollars) " />
            <Form.Control type="text" placeholder="Consultation Rate" name="consultationRate" onChange={handleDataChange} value={registrationData.consultationRate} style={{ borderColor: hasError('consultationRate') ? '#F24B5D' : '', boxShadow: 'none' }} />
            <div
            className={hasError('consultationRate') ? 'inline-errormsg' : 'hidden'}
          >
            Please enter numeric data
          </div>
          </Form.Group>
        </Row>
      </Form.Group>
      <Form.Group>
        <Row className="mb-9">
          <Form.Group as={Col} md="9">
          </Form.Group>
          <Form.Group as={Col} controlId="validationCustom03">
            <Button style={{ backgroundColor: '#F24B5D', borderRadius: '5px', border: 'none', color: 'white' }} onClick={handleSubmit} >REGISTER</Button>
          </Form.Group>
          <Form.Group as={Col} controlId="validationCustom03">
            <button type="reset" style={{ backgroundColor: 'white', border: 'none', color: '#F24B5D' }} >RESET</button>
          </Form.Group>
        </Row>
      </Form.Group>
    </Form>
    </>
  )
}

RegistrationPractitioner.propTypes = {
  handleAllPractitionerChange: PropTypes.func.isRequired
}
