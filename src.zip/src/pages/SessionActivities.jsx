/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react'
import { useMsal, useAccount } from '@azure/msal-react'
import {
  Button,
  Col,
  Row, // eslint-disable-next-line no-unused-vars
  OverlayTrigger,
  Form,
  Popover
} from 'react-bootstrap'
import {
  AzMediaPlayerModal,
  LoaderModalPopUp,
  ModalPopUp
} from '../CommonData/ModalPopUp'
import '../styles/App.css'
import config from '../config'
import moment from 'moment'
import { Divider } from '@mui/material'
import calImg from '../Assets/Calendar.png'
import GreenDot from '../Assets/greenDot.png'
import { AssessmentsActivitiesTab } from './AssessmentActivitiesTab'
import { showJoinOption } from '../CommonData/CommonFunction'
import RtmClient from '../components/rtm-client'
import { callApiForActivityStatus, callApiForRegistration } from '../fetch'
import {
  AppointmentsCommonUrl,
  getAgoraToken,
  LoggingAppointmentsData
} from '../CommonData/APIListing'
import { useLocation } from 'react-router'
import { useHistory } from 'react-router-dom'
import PropTypes from 'prop-types'
import { NoAppointmentFound } from '../CommonData/WorkInProgress'
import { fourteenPx } from '../CommonData/Data'
import {
  createAgoraTokenUrl,
  videoStatusUpdateUrl
} from '../CommonData/CreateAPIUrl'
import { isIOS } from 'react-device-detect'

const AppointmentDetailsHeader = ({
  appointmentDetail,
  joinMeetingHandler,
  isMeetingStarted
}) => {
  const dateConst = moment(appointmentDetail.meetingStartDateTime).format(
    'MMM DD, yyyy'
  )
  const timeConst = moment(appointmentDetail.meetingStartDateTime).format(
    'hh:mm A'
  )
  const endTimeConst = moment(appointmentDetail.meetingEndDateTime).format(
    'hh:mm A'
  )

  const showJoin = showJoinOption(
    appointmentDetail.meetingStartDateTime,
    appointmentDetail.meetingEndDateTime
  )

  return (
    <div
      style={{
        paddingTop: 10,
        paddingLeft: '15px',
        display: 'flex',
        justifyContent: 'space-between'
      }}
    >
      <p
        style={{
          color: '#139ED7',
          fontFamily: 'Roboto, Light',
          fontSize: '20px'
        }}
      >
        {' '}
        {`Appointment with ${
          appointmentDetail.practitionerName
            ? appointmentDetail.practitionerName
            : ''
        }`}
      </p>
      <div
        style={{
          paddingLeft: '20px',
          marginTop: '5px',
          color: '#2D2D34',
          fontFamily: 'Roboto, Regular',
          fontSize: fourteenPx
        }}
      >
        <img src={calImg} width={15}></img>
        <span> </span>

        {`${dateConst} | ${timeConst}-${endTimeConst}`}
      </div>
      {!isMeetingStarted &&
        showJoin &&
        appointmentDetail.status === 'Scheduled' && (
          <Button
            variant="danger"
            id="details"
            style={{
              marginLeft: '20px',
              backgroundColor: '#F24B5D',
              height: 35,
              fontSize: fourteenPx
            }}
            onClick={joinMeetingHandler}
          >
            JOIN
          </Button>
      )}
      {isMeetingStarted && (
        <div
          style={{
            paddingLeft: '20px',
            marginTop: '5px',
            color: '#4C927E',
            fontFamily: 'Roboto, Regular',
            fontSize: fourteenPx
          }}
        >
          <img src={GreenDot} width={9}></img>
          <span> </span>
          Meeting in progress
        </div>
      )}
    </div>
  )
}
AppointmentDetailsHeader.propTypes = {
  appointmentDetail: PropTypes.object.isRequired,
  joinMeetingHandler: PropTypes.func.isRequired,
  isMeetingStarted: PropTypes.bool.isRequired
}
const rtm = new RtmClient()
// let myAZPlayer
// Agora related code
let channelName
let agoraAccount
let activityId
let sameSession = true
let isVREnabled = false
const appID = config.APP_AGORA_CLIENT_ID // '5958ba4c54614096a0350e1b5141f5f3'
export const SessionActivities = () => {
  // console.log('localStorage.getItem', localStorage.getItem('AppointmentDetails'))
  const { accounts, instance } = useMsal()
  const account = useAccount(accounts[0] || {})
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const [showLogOutErrorModal, setShowLogOutErrorModal] = useState(false)
  const [clientPlayVideo, setClientPlayVideo] = useState(false)
  const [activityData, setActivityData] = useState({})
  const apptData =
    localStorage.getItem('AppointmentDetails') &&
    JSON.parse(localStorage.getItem('AppointmentDetails'))

  const [appointmentDetail, setAppointmentDetail] = useState(apptData || {})
  const history = useHistory()
  const [isMeetingStarted, setIsMeetingStarted] = useState(false)

  const location = useLocation()
  const redirectionData = location.state

  // const currentRole = JSON.parse(localStorage.getItem('UserType'))
  const [isAPICalling, setisAPICalling] = useState(false)
  const [videoSourceUrl, setVideoSourceUrl] = useState('')
  const [title, setTitle] = useState('')
  const [refreshData, setRefreshData] = useState(false)

  const [isVideoStarted, setIsVideoStarted] = useState(false)
  const joinMeetingHandler = () => {
    getAgoraTokenCall(appointmentDetail)
  }

  const joinAgoraSession = (appointmentDetail, agoraAccessToken) => {
    try {
      rtm.init(appID)
      window.rtm = rtm
      rtm
        .login(agoraAccount, agoraAccessToken)
        .then(() => {
          rtm._logined = true

          rtm
            .joinChannel(channelName)
            .then(() => {
              setisAPICalling(false)

              rtm.channels[channelName].joined = true
              console.log(
                'Join Channel success acc name::',
                rtm.accountName + ' join channel success' + channelName
              )
              setIsMeetingStarted(true)
              sameSession = true
              // Opening the Teams in new tab
              window.open(`${appointmentDetail.meetingLink}`, '_blank')
            })
            .catch((err) => {
              // Toast.error('Join channel failed, please open console see more details.')
              console.error(
                'Join channel failed, please open console see more details.',
                err
              )
            })
        })
        .catch((err) => {
          setisAPICalling(false)

          console.log(err)
        })
    } catch (err) {
      setisAPICalling(false)
      // Toast.error('Login failed, please open console see more details')
      console.error('err in login', err)
    }
  }

  const getAgoraTokenCall = (data) => {
    setisAPICalling(true)

    const reqData = {
      accountName: data.clientId, // data["appointmentId"],
      uid: ''
    }

    const agoraUrl = createAgoraTokenUrl(getAgoraToken)
    callApiForRegistration(agoraUrl, reqData).then((response) => {
      const finalResp = response && response.length ? response : ''

      joinAgoraSession(data, finalResp)
    })
  }

  /// ///Agora code ends here

  // Get Play video call from ActivitiesAssessmentsData
  const playVideoHandler = (e) => {
    console.log('activity data session::', e)
    if (isIOS && e.isVREnabled) {
      DeviceMotionEvent.requestPermission().then((response) => {
        if (response === 'granted') {
          console.log('accelerometer permission granted')
          // Do stuff here
        }
        setVideoSourceUrl(e.activityLink)
        isVREnabled = e.isVREnabled
        setIsVideoStarted(true)
        setRefreshData(false)
        setTitle(e.activityName)
        setActivityData(e)
      })
    } else {
      setVideoSourceUrl(e.activityLink)
      isVREnabled = e.isVREnabled
      setIsVideoStarted(true)
      setRefreshData(false)
      setTitle(e.activityName)
      setActivityData(e)
    }
  }
  // const closeVideoHandler = (e) => {
  //   rtm.sendChannelMessage('Close', channelName).then(() => {
  //     console.log('Send Close as channel message success after')
  //     setIsVideoStarted(false)
  //     setRefreshData(true)
  //   }).catch((err) => {
  //     console.error('Send message to channel err ', err)
  //   })
  // }

  /// //Upcoming Appointment Button Click
  const callUpcomingAppt = () => {
    history.push('/appointments')
    window.location.reload('flase')
  }
  const popover = (
    <Popover id="popover-basic" style={{ maxWidth: '40vw' }}>
      <Popover.Title as="h3">Please follow below instructions</Popover.Title>
      <Popover.Content>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>
              1. To start your meeting, click <strong>JOIN</strong> next to your
              appointment time.
            </Form.Label>
          </Form.Group>
        </Row>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>
              2. Ensure you have good connectivity in order to view and hear
              media during your session.
            </Form.Label>
          </Form.Group>
        </Row>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>
              3.If you have enrolled in the VR experience, make sure your mobile
              device is able to move from vertical to horizontal viewing. Turn
              horizontally to view in full screen, then click on the VR icon
              prior to inserting the goggles onto your device.{' '}
            </Form.Label>
          </Form.Group>
        </Row>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>
              4. Complete any assessments assigned to you prior to your session
              for personalized care.
            </Form.Label>
          </Form.Group>
        </Row>
      </Popover.Content>
    </Popover>
  )

  // API call to submit status on backend when Close is called
  const videoStatusUpdateCall = (status, duration) => {
    const activityStatusUpdate = videoStatusUpdateUrl(
      account,
      AppointmentsCommonUrl
    )
    const reqUrl = `${activityStatusUpdate}${
      appointmentDetail.appointmentId
    }?appointmentActivityId=${
      clientPlayVideo ? activityData.activityId : activityId
    }&status=${status}&watchDuration=${duration} mins`
    callApiForActivityStatus(reqUrl, {}).then((response) => {
      // console.log('videoStatusUpdateCall API Resp:-', response)
      const finalResp = response && response.length ? response : ''
      console.log('Final resp::', finalResp)
      setRefreshData(true)
    })
  }
  // API call ends here
  const handleModalPopUp = (currenttime, fulltime, status, videoEnded) => {
    // console.log('media time::', currenttime, fulltime, status, videoEnded)
    setRefreshData(!refreshData)
    setIsVideoStarted(false)
    sameSession = false
    const duration = currenttime // myAZPlayer.currentTime()
    const minitesDuration = (duration / 60).toString().split('.')[0]

    const seconds = (duration % 60).toString().split('.')[0]
    const secondsDuration = seconds < 10 ? '0' + seconds : seconds
    const currentDuration = minitesDuration + ':' + secondsDuration

    const statusText =
      currenttime === fulltime || videoEnded ? 'seen' : 'partially seen'
    if (status === 'play') {
      videoStatusUpdateCall(statusText, currentDuration)
    }
  }

  // Log Appt Details
  const logAppointmentDetails = () => {
    // setisAPICalling(true)
    // console.log('logAppointmentDetails api Call::')
    const dataToSend = {
      appointmentId: appointmentDetail.appointmentId,
      clientId: appointmentDetail.clientId,
      practitionerId: appointmentDetail.practitionerId,
      meetingLink: appointmentDetail.meetingLink,
      meetingStartDateTime: appointmentDetail.meetingStartDateTime,
      meetingEndDateTime: appointmentDetail.meetingEndDateTime,
      coordinatorId: appointmentDetail.coordinatorId,
      tenantId: appointmentDetail.tenantId,
      status: appointmentDetail.status
    }
    callApiForRegistration(LoggingAppointmentsData, dataToSend).then(
      (response) => {
        // setisAPICalling(false)
        console.log('logAppointmentDetails data response::', response)
      }
    )
  }

  useEffect(() => {
    // Assigning values to agora related data
    channelName = appointmentDetail.appointmentId
    agoraAccount = appointmentDetail.clientId

    rtm.on('ConnectionStateChanged', (newState, reason) => {
      console.log('ConnectionStateChanged reason::', reason)
      // console.log('ConnectionStateChanged newState::', newState)
    })

    rtm.on('MemberJoined', ({ channelName, args }) => {
      const memberId = args[0]
      console.log(
        'MemberJoined session act :: channel ',
        channelName,
        ' member: ',
        memberId,
        'args::',
        args
      )
      rtm
        .getChannelMembers(channelName)
        .then((data) => {
          // console.log('getChannelMembers :: data ', data)
          if (data && data.length > 1) {
            logAppointmentDetails()
          }
        })
        .catch((err) => {
          console.error('getChannelMembers session err::', err)
        })
    })

    rtm.on('MemberLeft', ({ channelName, args }) => {
      const memberId = args[0]
      console.log('MemberLeft:: channel ', channelName, ' member: ', memberId)
    })

    rtm.on('ChannelMessage', async ({ channelName, args }) => {
      const [message, memberId, messagePros] = args
      console.log(
        'Session activity comp ChannelMessage:: channel ',
        channelName,
        ', messsage: ',
        message.text,
        ', memberId: ',
        memberId,
        ',currentTime::',
        args,
        message,
        messagePros
      )
      // console.log('JSON.parse(message)::', JSON.parse(message.text).action)
      const messageData = JSON.parse(message.text)
      if (messageData && messageData.action === 'Start') {
        setTitle(messageData.title)
        isVREnabled = messageData.activity
        setVideoSourceUrl(messageData.url)
        setIsVideoStarted(true)
        setRefreshData(false)
        activityId = messageData.id
      }
    })

    return () => {
      rtm.removeAllListeners()
      rtm
        .leaveChannel(channelName)
        .then(() => {
          if (rtm.channels[channelName]) {
            rtm.channels[channelName].joined = false
            rtm.channels[channelName] = null
          }
          rtm._logined && rtm.logout()
        })
        .catch((err) => {
          rtm._logined && rtm.logout()
          console.error(err)
        })
    }
  }, [])

  useEffect(() => {
    //
    // console.log('Inside use effect 1', redirectionData, redirectionData && redirectionData.comingForView)
    if (
      redirectionData &&
      !redirectionData.comingForView &&
      redirectionData.apptDet
    ) {
      // console.log('Inside use effect if 1')
      if (isIOS) {
        DeviceMotionEvent.requestPermission().then((response) => {
          if (response === 'granted') {
            console.log('accelerometer permission granted')
            // Do stuff here
          }
          channelName = redirectionData.apptDet.appointmentId
          setAppointmentDetail(redirectionData.apptDet)
          getAgoraTokenCall(redirectionData.apptDet)
          setClientPlayVideo(false)
        })
      } else {
        channelName = redirectionData.apptDet.appointmentId
        setAppointmentDetail(redirectionData.apptDet)
        getAgoraTokenCall(redirectionData.apptDet)
        setClientPlayVideo(false)
      }
    }
    if (
      redirectionData &&
      redirectionData.comingForView &&
      redirectionData.apptDet
    ) {
      // console.log('Inside use effect if 2')

      setAppointmentDetail(redirectionData.apptDet)
      setClientPlayVideo(true)
    }
  }, [redirectionData && redirectionData.apptDet.appointmentId])

  // This useeffect is used to check if any other user is logged in in other tab or not
  useEffect(() => {
    if (account.idTokenClaims.sub !== userData.id) {
      setShowLogOutErrorModal(true)
    }
  })
  const logOutUser = () => {
    // localStorage.clear()
    instance.logoutRedirect({ postLogoutRedirectUri: '/' })
  }

  return (
    <>
      <LoaderModalPopUp show={isAPICalling} message="Loading..." />
      <ModalPopUp
        handleModalPopUp={logOutUser}
        show={showLogOutErrorModal}
        header="Error!"
        messageBody="Another user is logged in. You will be logout"
      />
      <AzMediaPlayerModal
        show={isVideoStarted}
        videoUrlData={videoSourceUrl}
        handleModalPopUp={handleModalPopUp}
        showClose={clientPlayVideo}
        rtm={rtm}
        title={title}
        sameSession={sameSession}
        isVREnabled={isVREnabled}
      />
      <div
        style={{
          paddingLeft: 20,
          paddingTop: 10,
          fontFamily: 'Roboto, Regular',
          fontSize: fourteenPx,
          color: '#2D2D34'
        }}
      >
{ /*         <div
          style={{ paddingRight: 20 }}
        >{`Please join the below MS Teams link for your next appointment ${
          appointmentDetail.practitionerName &&
          appointmentDetail.meetingStatus === 'Scheduled'
            ? 'with ' + appointmentDetail.practitionerName
            : ''
        }. Before joining the appointment please go through this instructions for effective use of your headset for a great virtual experience!`}</div>
        <div>
         OverlayTrigger
          trigger="click"
          placement="bottom"
          overlay={popover}
          rootClose
        >
          <Button
            variant="danger"
            id="details"
            style={{
              padding: 0,
              textAlign: "left",
              backgroundColor: "white",
              color: "#F24B5D",
              border: "none",
              height: 35,
            }}
            onClick={() => {
              console.log("Instructions click");
            }}
          >
            INSTRUCTIONS
          </Button>
        </OverlayTrigger>
    */}
      </div>
        <div
          style={{
            marginLeft: '-20px',
            backgroundColor: '#FCEEEF',
            padding: '20px'
          }}
        >
          <div style={{ backgroundColor: 'white', borderRadius: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <>
                <AppointmentDetailsHeader
                  appointmentDetail={appointmentDetail}
                  joinMeetingHandler={joinMeetingHandler}
                  isMeetingStarted={isMeetingStarted}
                />
                <Button
                  variant="danger"
                  id="details"
                  style={{
                    marginTop: '10px',
                    backgroundColor: 'white',
                    color: '#F24B5D',
                    border: 'none'
                  }}
                  onClick={callUpcomingAppt}
                >
                  UPCOMING APPOINTMENTS
                </Button>
              </>
            </div>

            <Divider variant="middle" />

            <div style={{ padding: '10px', width: '97vw' }}>
              {appointmentDetail.appointmentId
                ? (
                <AssessmentsActivitiesTab
                  appointmentDetail={appointmentDetail}
                  selectedTab="activities"
                  refreshData={refreshData}
                  clientPlayVideo={clientPlayVideo}
                  playVideoHandler={playVideoHandler}
                />
                  )
                : (
                <NoAppointmentFound></NoAppointmentFound>
                  )}
            </div>
          </div>
        </div>
    </>
  )
}
