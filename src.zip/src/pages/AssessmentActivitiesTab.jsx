import { ActivitiesAssessmentsData } from './ActivitiesListingData'
import React, { useState } from 'react'
import { Tabs, Tab } from 'react-bootstrap'
import '../styles/App.css'
import { AssessmentsListingData } from './AssessmentsListingData'
import PropTypes from 'prop-types'
import { isMobile } from 'react-device-detect'
const tableWidthData = isMobile ? '40vw' : '30vw'
export const AssessmentsActivitiesTab = ({ appointmentDetail, selectedTab, isMeetingStarted, playVideoHandler, refreshData, clientPlayVideo }) => {
  const [key, setKey] = useState(selectedTab)

  return (
      <div style={{ paddingLeft: 20 }}>
        <Tabs
        id="controlled-tab-example"
        activeKey={key}
        onSelect={(k) => setKey(k)}
        className="tabTitleAssessment"
        // style={{color:'red'}}
      >
        <Tab eventKey="activities" title="Activities">
          <ActivitiesAssessmentsData type="activities" appointmentDetail={appointmentDetail} widthData="30vw" isMeetingStarted={isMeetingStarted} playVideoHandler={playVideoHandler} refreshData={refreshData} clientPlayVideo={clientPlayVideo} />
        </Tab>
        <Tab eventKey="assessments" title="Assessments">
          <AssessmentsListingData type="assessments" appointmentDetail={appointmentDetail} widthData={tableWidthData} isMeetingStarted={isMeetingStarted} playVideoHandler={playVideoHandler} />
        </Tab>
      </Tabs>
      </div>
  )
}

AssessmentsActivitiesTab.propTypes = {
  selectedTab: PropTypes.string,
  isMeetingStarted: PropTypes.bool,
  clientPlayVideo: PropTypes.bool,
  refreshData: PropTypes.bool,
  appointmentDetail: PropTypes.object,
  playVideoHandler: PropTypes.func
}
