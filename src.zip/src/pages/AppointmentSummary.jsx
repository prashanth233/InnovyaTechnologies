/* eslint-disable array-callback-return */
import React, { useEffect, useState } from 'react'
import { useMsal, useAccount } from '@azure/msal-react'
import { TableComponent } from '../components/TableComponent'
import calImg from '../Assets/Calendar.png'
import PropTypes from 'prop-types'
import moment from 'moment'
import { Button } from 'react-bootstrap'
import { AppointmentSummaryColumns } from '../CommonData/Data'
import { ClientAppointments } from '../CommonData/APIListing'
import { callApiForListing, callApiForUpdate } from '../fetch'
import Loader from './Loader'

export const AppointmentSummary = ({
  appointmentDetail,
  handleViewDetails
}) => {
  const dateConst = moment(
    appointmentDetail && appointmentDetail.meetingStartDateTime
  ).format('MMM DD, yyyy')
  const timeConst = moment(
    appointmentDetail && appointmentDetail.meetingStartDateTime
  ).format('hh:mm A')
  const endTimeConst = moment(
    appointmentDetail && appointmentDetail.meetingEndDateTime
  ).format('hh:mm A')

  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})
  const [isAPICalling, setIsAPICalling] = useState(false)
  const isMounted = React.useRef(true)

  const [appointmentSummaryData, setAppointmentSummaryData] = useState([])

  const getAppointmentSummaryListing = () => {
    setIsAPICalling(true)

    const tenantId = account.idTokenClaims.extension_Organization
    const userData = JSON.parse(localStorage.getItem('UserData'))
    const currentRole = JSON.parse(localStorage.getItem('UserType'))

    const practiceName =
      currentRole !== 'Coordinator'
        ? userData && userData.practiceName
        : account.idTokenClaims.extension_PracticeName
    const appointmentId = appointmentDetail && appointmentDetail.appointmentId
    const appointmentSummary = `${ClientAppointments}${tenantId}/${practiceName}/appointments/${appointmentId}/summary`

    callApiForListing(appointmentSummary).then((response) => {
      const finalResp =
        response && typeof response === 'object' ? response : []
      // console.log('getAppointmentSummaryListing API Resp:-', finalResp)
      const sumarryData = finalResp.assignActivities.concat(
        finalResp.assignedAssessments
      )
      // console.log('sumarryData API Resp:-', sumarryData)
      if (isMounted.current) {
        // if (finalResp.todaysAppointmentCount >= 0) {
        sumarryData.map((obj) => {
          obj.updatedStatus = `${obj.status};${obj.type}`
        })
        // }
        setIsAPICalling(false)
        setAppointmentSummaryData(sumarryData)
      }
    })
  }
  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    // console.log('Inside separate useEffect');
    getAppointmentSummaryListing()
  }, [appointmentDetail && appointmentDetail.appointmentId])

  const removeActivityData = (forData) => {
    setIsAPICalling(true)

    const tenantId = account.idTokenClaims.extension_Organization
    const userData = JSON.parse(localStorage.getItem('UserData'))
    const currentRole = JSON.parse(localStorage.getItem('UserType'))

    const practiceName =
      currentRole !== 'Coordinator'
        ? userData && userData.practiceName
        : account.idTokenClaims.extension_PracticeName
    const appointmentId = appointmentDetail && appointmentDetail.appointmentId
    const removeActivity = `${ClientAppointments}${tenantId}/${practiceName}/appointments/${appointmentId}/activities`

    const dataToSend = {
      addAppointmentActivities: [],
      removeAppointmentActivities: [
        {
          id: forData.activityId, // forData.masterActivityId,
          clientId: appointmentDetail.clientId,
          activityId: forData.activityId,
          status: 'REMOVE',
          appointmentId: appointmentDetail.appointmentId,
          activityType: forData.type,
          videoWatchDuration: forData.videoWatchDuration, // `${forData.duration} mins`,
          tenantId: tenantId
        }
      ]
    }
    callApiForUpdate(removeActivity, dataToSend).then((response) => {
      // console.log('Assign/Remove resp::', response)
      setIsAPICalling(false)

      getAppointmentSummaryListing()
    })
  }
  // Table Column Button View Details Click handler
  const onRowClicked = (row, e) => {
    // console.log('table event Data::', row.original, e.target.innerText)
    if (e.target.nodeName === 'BUTTON' && e.target.innerText === 'REMOVE') {
      removeActivityData(row.original)
    }
  }
  // /// //////

  return (
    <div style={{ border: '1px solid #EEEEEE', borderRadius: 5 }}>
      {isAPICalling
        ? (
        <Loader />
          )
        : (
        <>
          <div
            style={{
              padding: '15px 20px 5px 20px',
              display: 'flex',
              justifyContent: 'space-between'
            }}
          >
            <div
              style={{
                paddingTop: '5px',
                color: '#139ED7',
                fontFamily: 'Roboto, Regular',
                fontSize: '14px'
              }}
            >
              {`Appointment with ${
                appointmentDetail && appointmentDetail.clientName
              }`}
            </div>
            <div
              style={{
                paddingTop: '5px',
                color: '#2D2D34',
                fontFamily: 'Roboto, Regular',
                fontSize: '14px'
              }}
            >
              <img src={calImg} width={15}></img>
              <span> </span>

              {`${dateConst} | ${timeConst}-${endTimeConst}`}
            </div>
            <div>
              <Button
                variant="danger"
                id="details"
                style={{
                  backgroundColor: '#F24B5D',
                  height: 35,
                  fontSize: '14px',
                  color: 'white'
                }}
                onClick={handleViewDetails}
              >
                VIEW DETAILS
              </Button>
            </div>
          </div>
          <div style={{ padding: '0px 20px 20px' }}>
            <TableComponent
              columns={AppointmentSummaryColumns}
              data={appointmentSummaryData}
              onRowClicked={onRowClicked}
              showHeader={false}
              tableWidth="54vw"
            />
          </div>
        </>
          )}
    </div>
  )
}
AppointmentSummary.propTypes = {
  appointmentDetail: PropTypes.object,
  handleViewDetails: PropTypes.func
}
