import React from 'react'
import { Row, Col, Form, Popover } from 'react-bootstrap'

export const NeedHelp = () => {
  return (
        <>
        <Popover id="popover-basic">
          <Popover.Title as="h3">For Help, contact us</Popover.Title>
          <Popover.Content>
          <Row className="auto">
            <Form.Group as={Col} md="6" controlId="validationCustom01">
            <Form.Label style={{ marginLeft: '-10px', fontFamily: 'Roboto', fontSize: '18px' }}>Name :</Form.Label>
            </Form.Group>
            <Form.Group as={Col} md="10" controlId="validationCustom01">
            <Form.Label style={{ marginLeft: '-10px', fontFamily: 'Roboto', fontSize: '18px' }}>Contact Person Name</Form.Label>
            </Form.Group>
          </Row>
          <Row className="auto">
            <Form.Group as={Col} md="6" controlId="validationCustom01">
            <Form.Label style={{ marginLeft: '-10px', fontFamily: 'Roboto', fontSize: '18px' }}>Contact No. :</Form.Label>
            </Form.Group>
            <Form.Group as={Col} md="6" controlId="validationCustom01">
            <Form.Label style={{ marginLeft: '-10px', fontFamily: 'Roboto', fontSize: '18px' }}>09189786777</Form.Label>
            </Form.Group>
          </Row>
          </Popover.Content>
        </Popover>
        </>
  )
}
