import React, { useEffect, useState } from 'react'
import { useMsal, useAccount } from '@azure/msal-react'
import '../styles/App.css'
import { viewGraphFrequency } from '../CommonData/Data'
import PropTypes from 'prop-types'
import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip
  // Legend,
} from 'chart.js'
import { Radar } from 'react-chartjs-2'
import { getPastDate, getFutureDateWithFormat } from '../CommonData/CommonFunction'
import { callApiForListing } from '../fetch'
import { ClientAssessmentsBaseUrl } from '../CommonData/APIListing'
import Loader from './Loader'
import { createClientAssessmentsListingUrl } from '../CommonData/CreateAPIUrl'

ChartJS.register(
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip
)

const options = {

  scales: { // <-- Note change in options from scale to scales
    r: {
      grid: {
        circular: true
      },
      beginAtZero: true,
      backgroundColor: '#FFF5D9'
    }
  }
}

export const WellBeingProfile = ({ clientUserId }) => {
  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})
  const [dropDownData, setDropDownData] = useState('Weekly')
  // console.log('account', account)
  const [isAPICalling, setIsAPICalling] = useState(false)
  const [chartData, setChartData] = useState({
    labels: ['IES', 'PSS', 'PROMIS', 'CES-D', '1IES', '1PSS', '1PROMIS', '1CES-D'],
    datasets: [
      {
        label: '',
        data: [2, 19, 3, 5, 6, 22, 7, 9],
        backgroundColor: 'rgba(105, 191, 168, 0.7)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 0
      }
    ]
  })

  const handleDataChange = (e) => {
    // console.log('handleDataChange', e.target, e.target.value)
    const dropdownVal = e.target.value
    setDropDownData(dropdownVal)
    getWellBeingProfileData(dropdownVal === 'Weekly' ? 7 : dropdownVal === 'Monthly' ? 30 : 364)
  }

  const getWellBeingProfileData = (interval) => {
    setIsAPICalling(true)
    const url = `${createClientAssessmentsListingUrl(account, ClientAssessmentsBaseUrl)}${clientUserId}/wellbeingProfile?fromdate=${getFutureDateWithFormat(-interval, 'yyyy-MM-DDTHH:mm:ss.SSS')}Z&todate=${getFutureDateWithFormat(0, 'yyyy-MM-DDTHH:mm:ss.SSS')}Z`

    callApiForListing(url)
      .then((response) => {
        // console.log('getTodaysAppointment Listing API Resp:-', response)
        const finalResp = response && typeof (response) === 'object' ? response : []
        // console.log('finalResp Listing API Resp:-', finalResp)

        setIsAPICalling(false)
        const labelData = finalResp.map(obj => obj.assessmentName)

        const valueData = finalResp.map(obj => obj.score)
        // console.log('Labeldata:-', labelData, +'Value data::', valueData)

        const currentChartData = {
          labels: labelData,
          datasets: [
            {
              label: 'Score',
              data: valueData,
              backgroundColor: 'rgba(105, 191, 168, 0.7)',
              borderColor: 'rgba(255, 99, 132, 1)',
              borderWidth: 0
            }
          ]
        }
        setChartData(currentChartData)
      })
  }

  useEffect(() => {
    // console.log('Inside separate useEffect');
    getWellBeingProfileData(7)
  }, [])

  return (
    <div style={{ border: '1px solid #EEEEEE' }}>
      <>
        {
          isAPICalling
            ? (
              <Loader />
              )
            : (
              <div style={{ padding: '10px', color: '#2D2D34' }} >
                <div style={{ fontFamily: 'Roboto,Regular', fontSize: 12, display: 'flex' }} >
                  <label style={{ paddingTop: '5px', color: '#2D2D34' }} >View : </label>
                  <div style={{ paddingLeft: '10px', color: '#2D2D34' }} >
                    <select name="radar" id="radar" value={dropDownData} onChange={handleDataChange} style={{ padding: '5px', border: '1px solid grey', borderRadius: '5px' }} >
                      {
                        viewGraphFrequency.map((x, y) =>
                          <option key={y}>{x}</option>)
                      }
                    </select>
                  </div>
                </div>
                <div style={{ marginTop: '-30px', textAlign: 'right', fontFamily: 'Roboto,Regular', fontSize: 13 }} >
                  {`${getPastDate(dropDownData === 'Weekly' ? 7 : dropDownData === 'Monthly' ? 30 : 364)} - ${getPastDate(0)}`}
                </div>
                <div style={{ width: '400px', height: '400px' }}>
                  <Radar data={chartData} options={options} />
                </div>
              </div>
              )
        }
      </>
    </div>
  )
}
WellBeingProfile.propTypes = {
  clientUserId: PropTypes.string

}
