import React, { useState, useEffect } from 'react'
import { LoaderModalPopUp } from '../CommonData/ModalPopUp'
import '../styles/App.css'
import { useMsal, useAccount } from '@azure/msal-react'
import { AssessmentsTypeTab } from './AssessmentsTypeTab'
import { ClientAssessmentsBaseUrl } from '../CommonData/APIListing'
import { callApiForListing } from '../fetch'
import { fourteenPx } from '../CommonData/Data'
import { createClientAssessmentsListingUrl } from '../CommonData/CreateAPIUrl'

export const ClientAssessments = () => {
  const [isAPICalling, setisAPICalling] = useState(false)
  const { accounts } = useMsal()
  const [cardData, setCardData] = useState([])

  const account = useAccount(accounts[0] || {})

  const getAllAssessmentsListing = () => {
    setisAPICalling(true)
    const clientId = account && account.idTokenClaims.sub
    const assessmentsUrl = `${createClientAssessmentsListingUrl(account, ClientAssessmentsBaseUrl)}${clientId}/assessments/all`

    callApiForListing(assessmentsUrl)
      .then((response) => {
        const finalResp = response && typeof (response) === 'object' ? response : []

        setisAPICalling(false)
        setCardData(finalResp)
      })
  }

  useEffect(() => { //
    setisAPICalling(true)
    getAllAssessmentsListing()
  }, [])
  return (
    <>
      <LoaderModalPopUp show={isAPICalling} message='Loading...' />
      <br />
      <div style={{ paddingLeft: 20, paddingTop: 10, fontFamily: 'Roboto, Regular', fontSize: fourteenPx, color: '#2D2D34' }} >
      <div style={{ position: 'relative', top: '0.5rem' }}>
        <div>These forms below help the Provider guide you in your personalized care journey. You will need to complete these with the unique <strong>Assessment Number</strong> (can be pasted from clipboard) provided with each form. </div>
        <div>For your convenience, the assessments are also emailed to you. You could complete it here or by accessing your email.</div>
        <div style={{ marginLeft: '-20px', backgroundColor: '#FCEEEF', padding: '20px' }}>
          <div style={{ backgroundColor: 'white', borderRadius: '10px' }}>

            <div style={{ padding: '10px', width: '97vw' }}>
              <AssessmentsTypeTab selectedTab='baseline' cardData={cardData} />
            </div>

          </div>
        </div>
      </div>
    </div>
    </>
  )
}
