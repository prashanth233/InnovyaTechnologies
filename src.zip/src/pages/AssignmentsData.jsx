/* eslint-disable array-callback-return */
/* eslint-disable react/prop-types */
import React, { useState, useEffect } from 'react'
import { useMsal, useAccount } from '@azure/msal-react'
import { activitiesSearch, assessmentsSearch, assignActivitiesColumns, assignAssessmentsColumns } from '../CommonData/Data'
import { TableComponent } from '../components/TableComponent'
import SearchModalComponent from '../components/SearchModalComponent'
import { NoAssignActivitiesFound } from '../CommonData/WorkInProgress'
import '../styles/App.css'
import moment from 'moment'

import { callApiForListing, callApiForUpdate } from '../fetch'
import { AppointmentsCommonUrl, LibraryBaseURL } from '../CommonData/APIListing'
import Loader from './Loader'
import { createCoordinatorAppointmentsUrl } from '../CommonData/CreateAPIUrl'

export const AssignmentsData = ({ toggleDetailsView, appointmentDetail, type, data, listingData }) => {
  const currentUser = JSON.parse(localStorage.getItem('currentUser'))
  const TENANTNAME = currentUser && currentUser.extension_Organization
  const [isAPICalling, setisAPICalling] = useState(false)
  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})
  const [assignmentsData, setAssignmentsData] = useState([])
  const [assignmentsDataDefault, setAssignmentsDataDefault] = useState([])
  const [show, setShow] = useState(false)

  // Search and Filter related
  const [searchData, setSearchData] = useState('')
  const [searchKey, setSearchKey] = useState(type === 'activities' ? 'activityName' : 'name')
  const [filterName, setFilterName] = useState('Filter')

  const tableColumns = type === 'activities' ? assignActivitiesColumns : assignAssessmentsColumns
  const searchFilterData = type === 'activities' ? activitiesSearch : assessmentsSearch

  const handleSearch = (event) => {
    // console.log('handleFilterChange::', event.target.id, searchKey)

    const searchValue = event.target.id === 'clear' ? '' : event.target.value
    // console.log("Handle search name1:-", event.target.id, searchValue);
    const searchedCards = assignmentsDataDefault.filter((item) => {
      return Object.values(item[searchKey]).join('').toLowerCase().includes(searchValue && searchValue.toLowerCase())
    })
    // console.log("Searched Result=:", searchedCards);
    // setPageNo(1)
    // handlePagination(searchedCards)
    setAssignmentsData(searchValue === '' ? assignmentsDataDefault : searchedCards)
    setSearchData(searchValue)
  }

  const handleFilterChange = (event, value) => {
    // console.log('handleFilterChange::', event.target.id)
    if (event.target.id !== 'filter') {
      // console.log('inside if handleFilterChange::')

      const filterNameValue = event.target.name === '' ? filterName : event.target.name
      setFilterName(filterNameValue)
      setSearchKey(event.target.id)
    }

    setShow(!show)
  }
  /// //////

  /// /////Table Click handler=============
  // Table Column Button View Details Click handler   BUTTON
  const onRowClicked = (row, e) => {
    // console.log('Assign table event Data::', e.target.innerText, e.target.nodeName)
    if (!isAPICalling && e.target.nodeName === 'BUTTON' && (e.target.innerText.toLowerCase() === 'assign' || e.target.innerText.toLowerCase() === 'remove')) {
      if (type === 'activities') {
        assignRemoveActivities(row.original, e.target.innerText)
      } else {
        assignRemoveAssessments(row.original, e.target.innerText)
      }
    }
  }
  /// //////
  /// ///////////////////

  // Assign/ REmove activities API call
  const assignRemoveActivities = (forData, status) => {
    setisAPICalling(true)
    // console.log('ForData value::', forData)
    const apiUrl = `${createCoordinatorAppointmentsUrl(account, AppointmentsCommonUrl)}/${data.appointmentId}/activities`

    // const apiUrl = `${CoordinatorAppointments}/${data.appointmentId}/activities`
    let dataToSend = {}
    if (status.toLowerCase() === 'assign') {
      dataToSend = {
        addAppointmentActivities: [
          {
            id: '',
            clientId: data.clientId,
            activityId: forData.id,
            status: 'ASSIGN',
            appointmentId: data.appointmentId,
            activityType: forData.type,
            videoWatchDuration: `${forData.duration} mins`,
            tenantId: forData.tenantId
          }
        ],
        removeAppointmentActivities: [
        ]
      }
    } else {
      dataToSend = {
        addAppointmentActivities: [

        ],
        removeAppointmentActivities: [
          {
            id: forData.removeId,
            clientId: data.clientId,
            activityId: forData.id,
            status: 'REMOVE',
            appointmentId: data.appointmentId,
            activityType: forData.type,
            videoWatchDuration: `${forData.duration} mins`,
            tenantId: forData.tenantId
          }

        ]
      }
    }
    callApiForUpdate(apiUrl, dataToSend)
      .then((response) => {
        // console.log('Assign/Remove resp::', response, response[0])
        setisAPICalling(false)

        const finalResp = [...assignmentsData]

        finalResp.map(obj => {
          if (obj.id === forData.id) {
            obj.assignStatus = obj.assignStatus.toLowerCase() === 'assign' ? 'REMOVE' : 'ASSIGN'
            obj.removeId = response[0].id
          }
        })
        finalResp.sort((a, b) => {
          const fa = a.assignStatus.toLowerCase()
          const fb = b.assignStatus.toLowerCase()

          if (fa < fb) {
            return 1
          }
          if (fa > fb) {
            return -1
          }
          return 0
        })

        setAssignmentsData(finalResp)
      })
  }

  // Assign/ REmove Assessments API call
  const assignRemoveAssessments = (forData, status) => {
    setisAPICalling(true)
    // console.log('ForData value::', forData)
    const dateTime = `${moment.utc(new Date()).format('yyyy-MM-DDTHH:mm:ss.SSS')}Z`
    const apiUrl = `${createCoordinatorAppointmentsUrl(account, AppointmentsCommonUrl)}/${data.appointmentId}/assessments`

    // const apiUrl = `${CoordinatorAppointments}/${data.appointmentId}/assessments`
    let dataToSend = {}

    if (status.toLowerCase() === 'assign') {
      dataToSend = {
        addAppointmentAssessments: [
          {
            id: '',
            clientId: data.clientId,
            assessmentId: forData.id,
            status: 'ASSIGN',
            appointmentId: data.appointmentId,
            dueDate: dateTime,
            type: forData.type,
            tenantId: forData.tenantId
          }
        ],
        removeAppointmentAssessments: [
        ]
      }
    } else {
      dataToSend = {
        addAppointmentAssessments: [

        ],
        removeAppointmentAssessments: [
          {
            id: forData.removeId,
            clientId: data.clientId,
            assessmentId: forData.id,
            status: 'REMOVE',
            appointmentId: data.appointmentId,
            dueDate: dateTime,
            type: forData.type,
            tenantId: forData.tenantId
          }

        ]
      }
    }
    callApiForUpdate(apiUrl, dataToSend)
      .then((response) => {
        // console.log('Assessments Assign/Remove resp::', response)
        setisAPICalling(false)

        const finalResp = [...assignmentsData]

        finalResp.map(obj => {
          if (obj.id === forData.id && obj.type === forData.type) {
            obj.assignStatus = obj.assignStatus.toLowerCase() === 'assign' ? 'REMOVE' : 'ASSIGN'
            obj.removeId = response[0].id
          }
        })
        finalResp.sort((a, b) => {
          const fa = a.assignStatus.toLowerCase()
          const fb = b.assignStatus.toLowerCase()

          if (fa < fb) {
            return 1
          }
          if (fa > fb) {
            return -1
          }
          return 0
        })

        setAssignmentsData(finalResp)
      })
  }

  // Get list of master data from Library
  const getAssignActivitiesData = () => {
    setisAPICalling(true)
    const AssignActivities = `${LibraryBaseURL}${TENANTNAME}/activities/all`
    const AssignAssessments = `${LibraryBaseURL}${TENANTNAME}/assessment/`

    const reqUrl = type === 'activities' ? AssignActivities : `${AssignAssessments}all`

    callApiForListing(reqUrl)
      .then((response) => {
        const finalResp = response && response.length ? response : []
        if (finalResp.length) {
          // console.log('getAssignActivitiesData API resp::', finalResp)

          finalResp.map(obj => {
            obj.assignStatus = 'ASSIGN'
            const keyData = type === 'activities' ? 'activityId' : 'assessmentId'
            listingData.length && listingData.map(data => {
              if (type === 'activities' && obj.id === data[keyData]) {
                // console.log('Condition match listing id::', data.id)
                obj.assignStatus = 'REMOVE'
                obj.removeId = data.id
              }
              if (type !== 'activities' && obj.id === data[keyData] && obj.type === data.type) {
                // console.log('Condition match listing id::', data.id)
                obj.assignStatus = 'REMOVE'
                obj.removeId = data.id
              }
            }
            )
          })
        }

        finalResp.sort((a, b) => {
          const fa = a.assignStatus.toLowerCase()
          const fb = b.assignStatus.toLowerCase()

          if (fa < fb) {
            return 1
          }
          if (fa > fb) {
            return -1
          }
          return 0
        })
        setisAPICalling(false)
        setAssignmentsData(finalResp)
        setAssignmentsDataDefault(finalResp)
      })
  }

  useEffect(() => {
    // console.log('Get Assignments data effect')
    getAssignActivitiesData()
  }, [])
  return (
    <>
      {
        isAPICalling
          ? (
            <Loader></Loader>
            )
          : (
            <div >
              <div style={{ width: type === 'activities' ? '91vw' : '36vw', backgroundColor: 'white', borderRadius: '20px', border: '2px' }}>
                {/* {userRole === "Coordinator" ? */}

                <SearchModalComponent filterArr={searchFilterData} onSearchClick={handleSearch} searchValue={searchData} handleFilterChange={handleFilterChange} filterName={filterName} />

                <div style={{ padding: '10px' }}>
                  {
                    assignmentsData && assignmentsData.length
                      ? (<TableComponent columns={tableColumns} data={assignmentsData} onRowClicked={onRowClicked} showHeader={true} tableWidth={type === 'activities' ? '90vw' : '35vw'} />)
                      : (<NoAssignActivitiesFound></NoAssignActivitiesFound>)
                  }
                </div>

              </div>
            </div>
            )
      }

    </>
  )
}
