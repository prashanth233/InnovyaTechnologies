/* eslint-disable no-dupe-keys */
/* eslint-disable multiline-ternary */
import React, { useEffect, useState } from 'react'

import {
  MsalAuthenticationTemplate,
  useMsal,
  useAccount
} from '@azure/msal-react'
import { InteractionType } from '@azure/msal-browser'
import { Button } from 'react-bootstrap'
// , Col, Row, OverlayTrigger, Form, Popover
import { Avatar } from '@mui/material'
import { loginRequest } from '../authConfig'
import { AppointmentDetails } from './AppointmentDetails'
import { useLocation } from 'react-router'
import { useHistory } from 'react-router-dom'
import '../styles/App.css'
import moment from 'moment'

import { ScheduleAppointment } from './ScheduleAppointment'
import { AppointmentsListing } from './AppointmentsListing'
import { ModalPopUp } from '../CommonData/ModalPopUp'
// import { fourteenPx } from "../CommonData/Data";

const AppointmentContent = () => {
  const { instance, accounts } = useMsal()
  const account = useAccount(accounts[0] || {})
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const [showLogOutErrorModal, setShowLogOutErrorModal] = useState(false)

  const userRole = JSON.parse(localStorage.getItem('UserType'))

  const [isPastAppointment, setIsPastAppointment] = useState(false)
  const [clientProfile, setClientProfile] = useState(false)
  const [appointments, setAppointments] = useState(true)
  const [showAppointmentDetails, setShowAppointmentDetails] = useState(false)
  const [appointmentDetailObj, setAppointmentDetailObj] = useState({})
  const [showSuccessMessage, setShowSuccessMessage] = useState('')
  const [selectedTab, setSelectedTab] = useState('activities')
  const [editAppointmentData, setEditAppointmentData] = useState({})
  const [firstAppointmentData, setFirstAppointmentData] = useState({})
  const [forClientId, setForClientId] = useState('')

  const location = useLocation()
  const history = useHistory()
  const redirectionData = location.state
  const [appointmentFilter, setAppointmentFilter] = useState(
    redirectionData && redirectionData.apptFilter
      ? redirectionData.apptFilter
      : 'all'
  )

  // console.log('apptData Appointments', apptData)
  const handleAppointmentChange = (message) => {
    // console.log('From scheduled App message::',message);
    // clientProfile ? setAppointments(true) : setAppointments(!appointments);
    clientProfile
      ? history.push('/appointments', {})
      : setAppointments(!appointments)

    setClientProfile(false)
    setShowSuccessMessage(message)
    setEditAppointmentData({})
    setForClientId('')
    // getAllAppointmentsListing()
  }

  const handleAppointmentType = () => {
    // console.log("Is past appoint::",isPastAppointment);
    setIsPastAppointment(!isPastAppointment)
  }

  // Edit Appointment handler
  const handleEditAppointment = (rowData) => {
    setClientProfile(false)
    setAppointments(false)
    setEditAppointmentData({ ...rowData, isEdit: true })
  }
  const viewAppointmentClicked = (obj, tabSelect) => {
    // console.log("A/ppt Details::", obj);
    setSelectedTab(tabSelect)
    setShowAppointmentDetails(true)
    setAppointmentDetailObj(obj)
  }
  const toggleDetailsView = () => {
    // console.log("details toggle::", e.target.id);
    setShowAppointmentDetails(!showAppointmentDetails)
  }

  const handleFirstAppointmentData = (data) => {
    // console.log('First Appt data::', data)
    setFirstAppointmentData(data)
  }
  // console.log('First Appt data123::', firstAppointmentData)

  useEffect(() => { //
    // console.log('Appointment useEffect called::', redirectionData)
    if (redirectionData && redirectionData.tabSelected) {
      // console.log('Appointment useEffect redirectionData.tabSelected::', redirectionData)
      setForClientId('')
      setSelectedTab(redirectionData.tabSelected)
      setShowAppointmentDetails(true)
      setAppointmentDetailObj(redirectionData.apptDet)
      setAppointmentFilter('all')
    }
    if (redirectionData && redirectionData.userId) {
      // console.log('Appointment useEffect redirectionData.userId for scheduled::', redirectionData)
      setForClientId(redirectionData.userId)
      setShowAppointmentDetails(false)
      setAppointments(false)
      setAppointmentFilter('all')
    }
  }, [redirectionData])
  // '#FFF5F6'
  // This useeffect is used to check if any other user is logged in in other tab or not
  useEffect(() => {
    if (account.idTokenClaims.sub !== userData.id) {
      setShowLogOutErrorModal(true)
    }
  })
  const logOutUser = () => {
    // localStorage.clear()
    instance.logoutRedirect({ postLogoutRedirectUri: '/' })
  }

  /** const popover = (
    <Popover id="popover-basic" style={{ maxWidth: '40vw' }}>
      <Popover.Title as="h3">Please follow below instructions</Popover.Title>
      <Popover.Content >
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>1. To start your meeting, click <strong>JOIN</strong> next to your appointment time.</Form.Label>
          </Form.Group>
        </Row>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>2. Ensure you have good connectivity in order to view and hear media during your session.</Form.Label>
        </Row>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>3. If you have enrolled in the VR experience, make sure your mobile device is able to move from vertical to horizontal viewing. Turn horizontally to view in full screen, then click on the VR icon prior to inserting the goggles onto your device. </Form.Label>
          </Form.Group>
        </Row>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>4. Complete any assessments assigned to you prior to your session for personalized care.</Form.Label>
        </Form.Group>
        </Row>
      </Popover.Content>
    </Popover>
  )
*/
  const dateConst = moment(firstAppointmentData.meetingStartDateTime).format(
    'MMM DD, yyyy'
  )
  const timeConst = moment(firstAppointmentData.meetingStartDateTime).format(
    'hh:mm A'
  )
  const topMessageText = showAppointmentDetails
    ? `Please join the below MS Teams link for your next appointment with ${appointmentDetailObj.clientName}. You can assign the related videos for her assessment from below.`
    : `Your next appointment with ${firstAppointmentData.clientName} will start at ${dateConst} | ${timeConst}.`

  return (
    <>
      <ModalPopUp
        handleModalPopUp={logOutUser}
        show={showLogOutErrorModal}
        header="Error!"
        messageBody="Another user is logged in. You will be logged out"
      />
      {userRole === 'Client' && (
        <div
          style={{
            paddingLeft: 20,
            paddingTop: 10,
            fontFamily: 'Roboto, Regular',
            fontSize: '14px',
            color: '#2D2D34'
          }}
        >
       <div style={{ position: 'relative', top: '3.5rem' }}>
          <div>{'Join the virtual link below for your next appointment. You can use Help for detailed instructions and support.'}
          </div>
       </div>
          {/* <OverlayTrigger trigger="click" placement="bottom" overlay={popover} rootClose>
          <Button variant="danger" id="details" style={{ padding: 0, textAlign: 'left', backgroundColor: 'white', color: '#F24B5D', border: 'none', height: 35 }} onClick={() => { console.log('Instructions click') }}>INSTRUCTIONS</Button>
        </OverlayTrigger>
    */}
        </div>
      )}

      <div style={{ background: 'linear-gradient(#E9E9E9, #FFFFFF)', height: '6px', position: 'relative', bottom: '5px' }}> </div>
      {showSuccessMessage.length > 0 && (
        <div
          style={{
            display: 'flex',
            marginLeft: '10px',
            marginTop: '15px',
            color: '#4C927E',
            fontFamily: 'Roboto, Regular',
            fontSize: '14px',
            height: '50px'
          }}
        >
          {' '}
          <Avatar
            sx={{
              marginRight: 1,
              width: '24px',
              height: '24px',
              border: '5px double white',
              bgcolor: '#4C927E',
              fontSize: 10
            }}
          >
            ✔
          </Avatar>{' '}
          <span> </span>
          {showSuccessMessage}
        </div>
      )}
      {userRole === 'Practitioner' &&
        !isPastAppointment &&
        firstAppointmentData.clientName && (
          <div
            style={{
              backgroundColor: 'white',
              marginLeft: '10px',
              height: '50px',
              paddingTop: 10,
              fontFamily: 'Roboto, Regular',
              fontSize: '14px'
            }}
          >
            {topMessageText}
          </div>
      )}

      <div style={{ backgroundColor: '#FFFFFF', padding: '10px' }}>
        {showAppointmentDetails ? (
          <AppointmentDetails
            toggleDetailsView={toggleDetailsView}
            appointmentDetail={appointmentDetailObj}
            isPastAppointment={isPastAppointment}
            selectedTab={selectedTab}
          />
        ) : (
          <div
            style={{
              backgroundColor: 'white',
              borderRadius: '20px',
              border: '1px',
              position: 'relative',
              top: '40.5px'
            }}
          >
            {userRole === 'Coordinator' ? (
              <div
                style={{
                  padding: '10px',
                  color: '#139ED7',
                  fontFamily: 'Roboto',
                  fontSize: '20px',
                  display: 'flex',
                  justifyContent: 'space-between'
                }}
              >
                {clientProfile
                  ? (
                  <>
                    <p> </p>
                    <Button
                      variant="danger"
                      style={{
                        backgroundColor: 'white',
                        color: '#F24B5D',
                        border: 'none',
                        height: 35
                      }}
                      onClick={handleAppointmentChange}
                    >
                      ALL CLIENTS
                    </Button>
                  </>
                    )
                  : (
                  <>
                    <p>
                      {' '}
                      {appointments ? 'Appointments' : 'Schedule Appointment'}
                    </p>
                    <Button
                      variant="danger"
                      style={{
                        backgroundColor: appointments ? '#7EC0B7' : 'white',
                        color: appointments ? 'white' : '#7EC0B7',
                        border: 'none',
                        height: 35
                      }}
                      onClick={handleAppointmentChange}
                    >
                      {appointments
                        ? 'SCHEDULE APPOINTMENT'
                        : 'ALL APPOINTMENTS'}
                    </Button>
                  </>
                    )}
              </div>
            ) : (
              <div
                style={{
                  padding: '10px 10px 10px 10px',
                  color: '#314C76',
                  fontFamily: 'Roboto',
                  fontSize: '20px',
                  display: 'flex',
                  border: '1px solid #E9E9E9',
                  height: '3.6rem',
                  width: '28rem',
                  position: 'relative',
                  paddingTop: '8px',
                  borderRadius: '5px',
                  backgroundColor: '#F8F8F8',
                  top: '57.5px',
                  left: '11px'
                  // alignItems: "center"

                }}
              >
                <>
                  <p
                   style={{
                     backgroundColor: '#314C76',
                     color: 'white',
                     border: 'none',
                     height: 39,
                     width: '13rem',
                     borderRadius: '6px',
                     justifyContent: 'center',
                     display: 'flex',
                     alignItems: 'center',
                     fontSize: '16px'
                     // top:"30px",
                     // left:"11px"
                   }}>
                    {' '}
                    {!isPastAppointment ? 'Upcoming Appointments' : 'Past Appointments'}
                  </p>
                  <Button
                    id='Upcoming'
                    onClick={handleAppointmentType}
                  >
                    {!isPastAppointment
                      ? 'Past Appointments'
                      : 'Upcoming Appointments'}
                  </Button>
                </>
              </div>
            )}
            <div>
              {appointments ? (
                // <div style={{height:"50vh"}}>
                <AppointmentsListing
                  isPastAppointment={isPastAppointment}
                  viewAppointmentClicked={viewAppointmentClicked}
                  handleEditAppointment={handleEditAppointment}
                  handleFirstAppointmentData={handleFirstAppointmentData}
                  appointmentFilterData={appointmentFilter}
                />
              ) : (
                // </div>
                <ScheduleAppointment
                  handleAppointmentChange={handleAppointmentChange}
                  editAppointmentData={editAppointmentData}
                  forClientId={forClientId}
                ></ScheduleAppointment>
              )}
            </div>
          </div>
        )}
      </div>
    </>
  )
}

/**
 * The `MsalAuthenticationTemplate` component will render its children if a user is authenticated
 * or attempt to sign a user in. Just provide it with the interaction type you would like to use
 * (redirect or popup) and optionally a [request object](https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/request-response-object.md)
 * to be passed to the login API, a component to display while authentication is in progress or a component to display if an error occurs. For more, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-react/docs/getting-started.md
 */
export const Appointments = () => {
  const authRequest = {
    ...loginRequest
  }

  return (
    <MsalAuthenticationTemplate
      interactionType={InteractionType.Redirect}
      authenticationRequest={authRequest}
    >
      <AppointmentContent />
    </MsalAuthenticationTemplate>
  )
}
