import React from 'react'
import '../styles/App.css'
import moment from 'moment'
import triangleImg from '../Assets/triangle.png'
import PropTypes from 'prop-types'
import { NoAppointmentFound } from '../CommonData/WorkInProgress'
import { Row } from 'react-bootstrap'
import Loader from './Loader'

export const TodaysAppointment = React.memo(({ generSelected, selectedId, isAPICalling, appointmentsData }) => {
  return (
    <div style={{ border: '1px solid #EEEEEE', borderRadius: 5 }}>
      {
        isAPICalling
          ? (<Loader />)
          : (

              appointmentsData && appointmentsData.length
                ? (
                <div style={{ padding: '10px' }}>
                  <Row style={{ fontFamily: 'Roboto, light', fontSize: '22px', color: '#139ED7', margin: '0 0 2vw 2vw', width: '25vw' }} ><TodaysAppointmentGenres appointmentsData={appointmentsData} generSelected={generSelected} selectedId={selectedId} /></Row>

                </div>
                  )
                : (<NoAppointmentFound></NoAppointmentFound>)

            )
      }

    </div>
  )
})
TodaysAppointment.propTypes = {
  generSelected: PropTypes.func,
  selectedId: PropTypes.string,
  isAPICalling: PropTypes.bool,
  appointmentsData: PropTypes.array
}

const TodaysAppointmentGenres = React.memo(({ appointmentsData, selectedId, generSelected }) => {
  // console.log('TodaysAppointmentGenres appointmentsData::', appointmentsData)
  return (
    <>
      {appointmentsData.map((appointment, idx) => {
        const timeConst = moment(new Date(new Date(appointment.meetingStartDateTime).setHours(new Date(appointment.meetingStartDateTime).getHours()))).format('HH:mm')

        const hourlyTimeDisplay = moment(new Date(new Date(appointment.meetingStartDateTime).setHours(new Date(appointment.meetingStartDateTime).getHours()))).format('HH')
        const hourlyTimeDisplayPrev = idx > 0 && moment(new Date(new Date(appointmentsData[idx - 1].meetingStartDateTime).setHours(new Date(appointmentsData[idx - 1].meetingStartDateTime).getHours()))).format('HH')
        const hourlyTimeDisplayLast = idx + 1 === appointmentsData.length && moment(new Date(new Date(appointmentsData[idx].meetingStartDateTime).setHours(new Date(appointmentsData[idx].meetingStartDateTime).getHours() + 1))).format('HH')

        const clientName = appointment.clientName
        const data = `${timeConst}    ${clientName}`

        return (
          <>
            {
              Number(hourlyTimeDisplay) !== Number(hourlyTimeDisplayPrev) && (
                <div key={idx} style={{ fontFamily: 'Roboto,Light', display: 'flex' }}>
              <button id={idx} className='noBadge'>
                {`${hourlyTimeDisplay} : 00`}
              </button>
              <div>
                <label style={{ backgroundColor: '#44546A', width: 8, height: 8, borderRadius: 4 }}></label>
              </div>
            </div>
              )
            }
            <div key={`green${idx}`} style={{ fontFamily: 'Roboto,Regular', display: 'flex', paddingLeft: '130px' }}>

              {
                Number(selectedId) === Number(idx) && (
                  <div style={{ marginLeft: '-57px' }}>
                    <img src={triangleImg} style={{ width: 11, height: 12, marginTop: '-12px' }}></img>
                  </div>
                )
              }
              <div style={{ paddingRight: '8px', marginLeft: Number(selectedId) === Number(idx) ? '47px' : '0px' }}>
                <label style={{ backgroundColor: Number(selectedId) === Number(idx) ? '#5CAA93' : '#F24B5D', width: 8, height: 8, borderRadius: 4 }}></label>
              </div>
              <button id={idx} onClick={generSelected} className={Number(selectedId) === Number(idx) ? 'badge1selected' : 'badge1'}>
                {data}
              </button>
            </div>
            {
              idx + 1 === appointmentsData.length && (
                <div key={`down${idx}`} style={{ fontFamily: 'Roboto,Light', display: 'flex' }}>
              <button id={idx} className='noBadge'>
                {`${hourlyTimeDisplayLast} : 00`}
              </button>
              <div>
                <label style={{ backgroundColor: '#44546A', width: 8, height: 8, borderRadius: 4, marginLeft: '-3px' }}></label>
              </div>
            </div>
              )
            }
          </>
        )
      })}
    </>
  )
})

TodaysAppointmentGenres.propTypes = {
  appointmentsData: PropTypes.array,
  generSelected: PropTypes.func,
  selectedId: PropTypes.number
}
