/* eslint-disable no-unreachable */
/* eslint-disable array-callback-return */
import React, { useState, useRef } from 'react'
import '../styles/App.css'
import { useMsal, useAccount } from '@azure/msal-react'
import { Form, Col, Row, Button } from 'react-bootstrap'
import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import ProfileEdit from '../Assets/ProfileEdit.png'
import { Avatar, Badge } from '@mui/material'
import { styled } from '@mui/material/styles'
import { raceData, ethnicityData, languagePref } from '../CommonData/Data'
import { LabelComponent, LabelComponentRequired, LabelHeaderComponentRequired, LabelHeaderComponent } from './LabelComponent'
import Radio from '@mui/material/Radio'
import RadioGroup from '@mui/material/RadioGroup'
import FormControlLabel from '@mui/material/FormControlLabel'
import Loader from './Loader'
import { clientInitialData } from '../CommonData/RegistrationInitialData'
import { callApiForRegistration } from '../fetch'
import { getDateFromString } from '../CommonData/CommonFunction'
import { LoaderModalPopUp, ModalPopUp } from '../CommonData/ModalPopUp'
import PropTypes from 'prop-types'
import { ClientRegistrationUrl } from '../CommonData/CreateAPIUrl'
import { CoordinatorBaseURL } from '../CommonData/APIListing'
import moment from 'moment'

export const Registration = ({ handleAllClientChange }) => {
  // const [validated, setValidated] = useState(false)
  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})

  const inputFile = useRef(null)
  const hippaId = useRef(null)
  const treatmentConsentId = useRef(null)

  const [isLoading, setLoading] = useState(false)

  const [imgFile, setImgFile] = useState(ProfilePlaceholder)
  const [errors, setErrors] = useState([])
  const [registrationData, setRegistrationData] = useState(clientInitialData)
  const [imagesData, setImagesData] = useState({})

  const [showModal, setShowModal] = useState(false)
  const [showErrorModal, setShowErrorModal] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')

  const [isAPICalling, setIsAPICalling] = useState(false)

  const currentUser = JSON.parse(localStorage.getItem('currentUser'))
  // console.log("User data stored in regi::", currentUser);

  const handleSubmit = (event) => {
    const requiredDataCheck = Object.assign({}, registrationData)

    const deleteKeysData = ['middleName', 'babyDOB', 'race', 'ethnicity', 'languagePreference', 'emergencyRelationship', 'insurenceName', 'insurenceId', 'insurencePlan', 'photoId', 'referralCode', 'referralName', 'referralPracticeName', 'referralEmail', 'referralMobileNo', 'referralWebsite', 'referralNPI', 'practiceId', 'createdBy', 'address', 'city', 'state', 'zip', 'userName']
    deleteKeysData.forEach(element => {
      delete requiredDataCheck[element]
    })
    const errorsData = []
    // let isValidated = true;
    if (registrationData.babyDOB.length > 0) {
      const dateNow = new Date()
      const calculatedNextYearDate = new Date(dateNow.setDate(dateNow.getDate() + 365))
      const inputYaer = new Date(registrationData.babyDOB).getFullYear()
      const curreDateNextYear = moment(calculatedNextYearDate).format('MM/DD/YYYY')
      const inputDate = moment(new Date(registrationData.babyDOB)).format('MM/DD/YYYY')
      if (inputYaer < 2000 || new Date(inputDate).getTime() > new Date(curreDateNextYear).getTime()) {
        errorsData.push('babyDOB')
      }
    }
    Object.entries(requiredDataCheck).map(([key, value]) => {
      value.length === 0 && errorsData.push(key)
      if (key === 'dob') {
        const curreYaer = new Date().getFullYear()
        const inputYaer = new Date(value).getFullYear()
        const curreDate = moment(new Date()).format('MM/DD/YYYY')
        const inputDate = moment(new Date(value)).format('MM/DD/YYYY')
        if ((new Date(inputDate).getTime() > new Date(curreDate).getTime() || inputYaer < 1950 || inputYaer > curreYaer || key.length === 0)) {
          errorsData.push(key)
        }
      }
      if (['mobileNo', 'emergencyMobileNo'].indexOf(key) !== -1) {
        // const res = /^[a-z0-9]{0,}\d*$|(?=\w{3,})^[a-z-_]{1,}\d+$/i.exec(value)
        const res = /^[+0-9]+$/.exec(value)
        const validUserName = !res
        if (validUserName) {
          errorsData.push(key)
        }
      }

      if (key === 'email') {
        const expression = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+\.)+([a-zA-Z]{2,4})+$/ /// \S+@\S+/;
        const validEmail = expression.test(String(value).toLowerCase())
        if (!validEmail) {
          errorsData.push(key)
        }
      }
      if (['mobileNo', 'emergencyMobileNo'].indexOf(key) !== -1 && !Number(value)) {
        errorsData.push(key)
      }

      setErrors(errorsData)
    })

    console.log('Errors Data:', errorsData.length)
    if (errorsData.length === 0) {
      event.stopPropagation()
      setIsAPICalling(true)
      saveFormData()
    }
  }
  const handleReset = (event) => {
    // console.log("Reset called");
    setRegistrationData({})
    setImagesData({})
    setImgFile(ProfilePlaceholder)
  }
  const SmallAvatar = styled(Avatar)(({ theme }) => ({
    left: -10,
    top: -5,
    width: 30,
    height: 30,
    border: '1px solid #F24B5D' // ${theme.palette.background.paper}
  }))

  const hasError = (key) => {
    return errors.indexOf(key) !== -1
  }

  const handleDataChange = (e) => {
    const { name, value, type, checked } = e.target
    // console.log('Data Values:', name, value)
    const errors = []

    if (name === 'dob') {
      const curreYaer = new Date().getFullYear()
      const inputYaer = new Date(value).getFullYear()
      const curreDate = moment(new Date()).format('MM/DD/YYYY')
      const inputDate = moment(new Date(value)).format('MM/DD/YYYY')
      if ((new Date(inputDate).getTime() > new Date(curreDate).getTime() || inputYaer < 1950 || inputYaer > curreYaer)) {
        errors.push(name)
      }
    }
    if (name === 'babyDOB') {
      const dateNow = new Date()
      const calculatedNextYearDate = new Date(dateNow.setDate(dateNow.getDate() + 365))
      const inputYaer = new Date(value).getFullYear()
      const curreDateNextYear = moment(calculatedNextYearDate).format('MM/DD/YYYY')
      const inputDate = moment(new Date(value)).format('MM/DD/YYYY')
      // console.log('curreYaer baby::', inputDate, curreDateNextYear, inputDate > curreDateNextYear)
      if (inputYaer < 2000 || new Date(inputDate).getTime() > new Date(curreDateNextYear).getTime()) {
        errors.push(name)
      }
    }

    // Username validation
    if (name === 'userName') {
      // const res = /^[a-z0-9]{0,}\d*$|(?=\w{3,})^[a-z-_]{1,}\d+$/i.exec(value)
      const res = /^[a-zA-Z0-9_-]+$/.exec(value)
      const validUserName = !res
      if (validUserName) {
        errors.push(name)
      }
    }
    if (name === 'mobileNo') {
      // const res = /^[a-z0-9]{0,}\d*$|(?=\w{3,})^[a-z-_]{1,}\d+$/i.exec(value)
      const res = /^[+0-9]+$/.exec(value)
      const validUserName = !res
      if (validUserName) {
        errors.push(name)
      }
    }

    if (['mobileNo', 'emergencyMobileNo'].indexOf(name) !== -1 && !Number(value)) {
      errors.push(name)
    }

    // email
    // '/\S+@\S+\.\S+/'
    // const expression = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,4})+$/ /// \S+@\S+/;
    const expression = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+\.)+([a-zA-Z]{2,4})+$/ /// \S+@\S+/;

    const validEmail = expression.test(String(value).toLowerCase())

    if (!validEmail && name === 'email') {
      errors.push(name)
    }
    setErrors(errors)
    setRegistrationData(oldState => ({ ...oldState, [name]: type === 'checkbox' ? checked : value }))
  }

  const handleFileChange = (event) => {
    const file = event.target.files[0]
    // console.log('Id Data::', file, file.size)

    const reader = new FileReader()
    reader.readAsDataURL(file)
    if (event.target.id === 'profile') {
      setLoading(true)

      reader.onload = () => {
        setImgFile(reader.result)
        setLoading(false)
        setImagesData(oldState => ({ ...oldState, [event.target.id]: reader.result }))
      }
    } else {
      reader.onload = () => {
        // console.log("doc data::-",reader.result);
        // const errorData = errors.filter(item => item !== event.target.id)
        // setErrors(errorData)
        if (file.size === 0) {
          setErrors(event.target.id)
        } else {
          setRegistrationData(oldState => ({ ...oldState, [event.target.id]: file.name }))
          setImagesData(oldState => ({ ...oldState, [event.target.id]: reader.result }))
          // setImagesData(oldState => ({ ...oldState, [event.target.id]: file }))
        }
      }
    }
  }

  // Registration API
  // const saveFormData = async () => {
  const saveFormData = () => {
    let saveData = Object.assign({}, registrationData)
    // console.log("Save data before::", saveData);

    const deleteKeysData = ['dd', 'mm', 'yyyy', 'babydd', 'babymm', 'babyyyyy', 'hippaId', 'treatmentConsentId']
    deleteKeysData.forEach(element => {
      delete saveData[element]
    })

    let langPrefCode = 'en-US'
    languagePref.forEach(element => {
      if (element.language === saveData.languagePreference) {
        langPrefCode = element.code
      }
    })
    const dob = getDateFromString(`${registrationData.dob}`)
    const babyDob = registrationData.babyDOB.length > 0 ? getDateFromString(`${registrationData.babyDOB}`) : null

    saveData = {
      ...saveData,
      treatmentConsentId: imagesData.treatmentConsentId,
      hippaId: imagesData.hippaId,
      photoId: imagesData.profile ? imagesData.profile : '',
      languagePreference: langPrefCode,
      dob: dob,
      babyDOB: babyDob || null,
      practiceName: currentUser && currentUser.extension_PracticeName,
      tenantId: currentUser.extension_Organization,
      createdBy: `${currentUser && currentUser.extension_FirstName} ${currentUser && currentUser.extension_LastName}`

    }

    // console.log('saveData Data:-', saveData)
    // setIsAPICalling(false)

    // return
    const reqUrl = `${ClientRegistrationUrl(account, CoordinatorBaseURL)}`
    callApiForRegistration(reqUrl, saveData)
      .then((response) => {
        setIsAPICalling(false)
        if (response && response === 'New Client Created Successfully.') {
          setShowModal(true)
        } else {
          setShowErrorModal(true)
        }
        setErrorMessage(response)
      })
      .catch(error => console.log('API Catch eror main class', error))
  }
  const handleModalPopUp = () => {
    setShowModal(!showModal)
    handleAllClientChange()
  }
  const handleErrorModalPopUp = () => {
    setShowErrorModal(false)
  }

  //   useEffect(() => {
  // });

  return (
    <>
      <ModalPopUp handleModalPopUp={handleModalPopUp} show={showModal} header="Client Registration" messageBody={errorMessage} />
      <ModalPopUp handleModalPopUp={handleErrorModalPopUp} show={showErrorModal} header="Error!" messageBody={errorMessage} />
      <LoaderModalPopUp show={isAPICalling} message='Client Registration is in progress...' />

      <Form noValidate onReset={handleReset}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <div>
            <Row >
            <Form.Group as={Col} md="4" controlId="validationCustom01">
              <LabelComponentRequired name="First Name " />
              <Form.Control
                required
                type="text"
                placeholder="First Name"
                name='firstName'
                value={registrationData.firstName}
                onChange={handleDataChange}
                style={{ borderColor: hasError('firstName') ? '#F24B5D' : '', boxShadow: 'none' }}
              />
              <div
                className={hasError('firstName') ? 'inline-errormsg' : 'hidden'}
              >
                Please provide First Name
              </div>
            </Form.Group>
            <Form.Group as={Col} md="4" controlId="validationCustom02">
              <LabelComponent name="Middle Name " />
              <Form.Control
                type="text"
                placeholder="Middle Name"
                // defaultValue="Otto"
                name='middleName'
                value={registrationData.middleName}
                onChange={handleDataChange}
              />
            </Form.Group>
            <Form.Group as={Col} md="4" controlId="validationCustom02">
              <LabelComponentRequired name="Last Name " />
              <Form.Control
                required
                type="text"
                placeholder="Last Name"
                // defaultValue="Otto"
                name='lastName'
                value={registrationData.lastName}
                onChange={handleDataChange}
                style={{ borderColor: hasError('lastName') ? '#F24B5D' : '', boxShadow: 'none' }}
              />
              <div
                className={hasError('lastName') ? 'inline-errormsg' : 'hidden'}
              >
                Please provide Last Name
              </div>
            </Form.Group>
          </Row>
            <Row>
              <Form.Group as={Col} md="5">
                <LabelComponentRequired name="Email " />
                <Form.Control type="text" name="email" value={registrationData.email} onChange={handleDataChange} placeholder="Email" style={{ borderColor: hasError('email') ? '#F24B5D' : '', boxShadow: 'none' }} />
                <div
                  className={hasError('email') ? 'inline-errormsg' : 'hidden'}
                >
                  Email is invalid or missing
                </div>
              </Form.Group>
              <Form.Group as={Col} md="5" controlId="validationCustom03">
                <LabelComponentRequired name="Mobile Number " />
                <Form.Control type="tel" placeholder="Mobile Number" name='mobileNo' onChange={handleDataChange} value={registrationData.mobileNo} required style={{ borderColor: hasError('mobileNo') ? '#F24B5D' : '', boxShadow: 'none' }} />
                <div
                  className={hasError('mobileNo') ? 'inline-errormsg' : 'hidden'}
                >
                  Please provide only numeric values
                </div>
              </Form.Group>
            </Row>
            <Row className="mb-6">
              <Form.Group as={Col} controlId="validationCustom08">
                <LabelComponentRequired name="Date of Birth " />
                <Row className="mb-6">
                  <Form.Group as={Col} md="5" controlId="validationCustom00">
                    <Form.Control type="date" value={registrationData.dob} placeholder="MM/DD/YYYY" name="dob" onChange={handleDataChange} min='1950-01-01' max={new Date().toISOString().slice(0, -14)} style={{ borderColor: hasError('dob') ? '#F24B5D' : '', boxShadow: 'none' }} />
                    <div
                      className={hasError('dob') ? 'inline-errormsg' : 'hidden'}
                    >
                      Please enter valid date
                    </div>
                  </Form.Group>

                </Row>
              </Form.Group>
            </Row>
            <Row className="mb-6">
            <Form.Group as={Col} controlId="validationCustom03">
                <LabelComponentRequired name="Gender " />
                <RadioGroup row aria-label="gender" name="gender" style={{ fontFamily: 'Roboto', fontSize: '5px', color: 'gray' }} onChange={handleDataChange}>
                  <FormControlLabel value="female" control={<Radio style={{ fontFamily: 'Roboto', fontSize: '5px', marginLeft: '10px' }} />} label="Female" />
                  <FormControlLabel value="male" control={<Radio style={{ paddingLeft: '20px' }} />} label="Male" />
                  <FormControlLabel value="other" control={<Radio style={{ paddingLeft: '20px' }} />} label="Decline to Answer" />
                </RadioGroup>
                <div
                  className={hasError('gender') ? 'inline-errormsg' : 'hidden'}
                >
                  Please select gender
                </div>
              </Form.Group>
            </Row>
          </div>
          <div>
            <p>Client Photo</p>
            <div style={{ marginRight: '35px', paddingTop: '13px', width: '160px', height: '160px', border: '1px solid #DFDFDF', display: 'flex', justifyContent: 'center', marginTop: '-15px' }}>
              {
                isLoading
                  ? (
                    <Loader />
                    )
                  : (
                    <>
                      <Badge
                        overlap="circular"
                        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                        badgeContent={
                          <SmallAvatar onClick={() => inputFile.current.click()} src={ProfileEdit} />
                        }
                      >
                        <Avatar
                          src={imgFile}
                          rounded
                          sx={{ width: 132, height: 132 }}
                        />
                      </Badge>
                      <input
                        id="profile"
                        ref={inputFile}
                        type="file"
                        style={{ display: 'none' }}
                        accept="image/*"
                        onChange={handleFileChange}
                      />
                    </>
                    )
              }

            </div>
          </div>
        </div>
      <Row>
      <Form.Group as={Col} md="3" controlId="validationCustom03">
            <LabelComponent name="Race " />
            <Form.Control as="select" name="race" onChange={handleDataChange}>
              {
                raceData.map((x, y) =>
                  <option key={y}>{x}</option>)
              }
            </Form.Control>
          </Form.Group>
          <Form.Group as={Col} md="3" controlId="validationCustom03">
            <LabelComponent name="Ethnicity " />
            <Form.Control as="select" name="ethnicity" onChange={handleDataChange}>
              {
                ethnicityData.map((x, y) =>
                  <option key={y}>{x}</option>)
              }
            </Form.Control>
          </Form.Group>
      </Row>

        <Row className="mb-6">
          <Form.Group as={Col} controlId="validationCustom03">
            <LabelComponent name="Baby's Date of Birth " />
            <Row className="mb-6">
              <Form.Group as={Col} md="3" controlId="validationCustom00">
                    <Form.Control type="date" value={registrationData.babyDOB} placeholder="MM/DD/YYYY" name="babyDOB" onChange={handleDataChange} min='2000-12-12' style={{ borderColor: hasError('babyDOB') ? '#F24B5D' : '', boxShadow: 'none' }} />
                    <div
                      className={hasError('babyDOB') ? 'inline-errormsg' : 'hidden'}
                    >
                      Please enter valid date
                    </div>
                  </Form.Group>
            </Row>
          </Form.Group>
        </Row>
        <Row>
          <Form.Group as={Col} md="3" controlId="validationCustom03">
            <LabelComponent name="Practice Name " />
            <Form.Control type="text" value={currentUser && currentUser.extension_PracticeName} name="practiceId" disabled />
          </Form.Group>
        </Row>
        <Form.Group controlId="validationCustom03">
          <LabelHeaderComponent name="Emergency Contact Details " />
          <Row >
            <Form.Group as={Col} md="3" controlId="validationCustom03">
              <LabelComponentRequired name="First Name " />
              <Form.Control type="text" placeholder="First Name" name="emergencyFirstName" onChange={handleDataChange} value={registrationData.emergencyFirstName} required style={{ borderColor: hasError('emergencyFirstName') ? '#F24B5D' : '', boxShadow: 'none' }} />
              <div
                className={hasError('emergencyFirstName') ? 'inline-errormsg' : 'hidden'}
              >
                Please provide First Name
              </div>
            </Form.Group>
            <Form.Group as={Col} md="3" controlId="validationCustom04">
              <LabelComponentRequired name="Last Name " />
              <Form.Control type="text" placeholder="Last Name" name="emergencyLastName" onChange={handleDataChange} value={registrationData.emergencyLastName} required style={{ borderColor: hasError('emergencyLastName') ? '#F24B5D' : '', boxShadow: 'none' }} />
              <div
                className={hasError('emergencyLastName') ? 'inline-errormsg' : 'hidden'}
              >
                Please provide Last Name
              </div>
            </Form.Group>
          </Row>
          <Row>
            <Form.Group as={Col} md="3" controlId="validationCustom03">
              <LabelComponentRequired name="Mobile Number " />
              <Form.Control type="text" placeholder="Mobile Number" name="emergencyMobileNo" onChange={handleDataChange} value={registrationData.emergencyMobileNo} required style={{ borderColor: hasError('emergencyMobileNo') ? '#F24B5D' : '', boxShadow: 'none' }} />
              <div
                className={hasError('emergencyMobileNo') ? 'inline-errormsg' : 'hidden'}
              >
                Please provide only numeric values
              </div>
            </Form.Group>
            <Form.Group as={Col} md="3" controlId="validationCustom04">
              <LabelComponent name="Relationship with Patient " />
              <Form.Control type="text" placeholder="Relationship with Patient" name="emergencyRelationship" onChange={handleDataChange} value={registrationData.emergencyRelationship} />
            </Form.Group>
          </Row>
        </Form.Group>

        <Form.Group controlId="validationCustom03">
          <LabelHeaderComponent name="Additional Details " />
          <Row>
            <Form.Group as={Col} md="3" controlId="validationCustom03">
              <LabelComponent name="Insurance Name " />
              <Form.Control type="text" placeholder="Insurance Name" name="insurenceName" onChange={handleDataChange} value={registrationData.insurenceName} />
            </Form.Group>
            <Form.Group as={Col} md="3" controlId="validationCustom04">
              <LabelComponent name="Insurance ID " />
              <Form.Control type="text" placeholder="Insurance ID" name="insurenceId" onChange={handleDataChange} value={registrationData.insurenceId} />
            </Form.Group>
          </Row>
          <Form.Group className="mb-3">
            <Form.Check
              // required
              label="No Insurance Plan"
            // feedback="You must agree before submitting."
            // feedbackType="invalid"
            />
          </Form.Group>
          <Row>
            <Form.Group as={Col} md="3" controlId="validationCustom03">
              <LabelComponent name="Provider Referral Code " />
              <Form.Control type="text" placeholder="" name="referralCode" onChange={handleDataChange} value={registrationData.referralCode} />
            </Form.Group>
          </Row>
        </Form.Group>

        <Form.Group controlId="validationCustom03">
          <LabelHeaderComponent name="Referral Provider Details " />
          <Row >
            <Form.Group as={Col} md="3" controlId="validationCustom03">
              <LabelComponent name="Name " />
              <Form.Control type="text" placeholder="Name" name="referralName" onChange={handleDataChange} value={registrationData.referralName} />
            </Form.Group>
            <Form.Group as={Col} md="3" controlId="validationCustom04">
              <LabelComponent name="Referring Practice Name " />
              <Form.Control type="text" placeholder="Referring Practice Name" name="referralPracticeName" onChange={handleDataChange} value={registrationData.referralPracticeName} />
            </Form.Group>
          </Row>
          <Row>
            <Form.Group as={Col} md="3" controlId="validationCustom03">
              <LabelComponent name="Email " />
              <Form.Control type="text" placeholder="Email" name="referralEmail" onChange={handleDataChange} value={registrationData.referralEmail} />
            </Form.Group>
            <Form.Group as={Col} md="3" controlId="validationCustom04">
              <LabelComponent name="Telephone Number " />
              <Form.Control type="text" placeholder="Telephone Number" name="referralMobileNo" onChange={handleDataChange} value={registrationData.referralMobileNo} />
            </Form.Group>
          </Row>
          <Row>
            <Form.Group as={Col} md="3" controlId="validationCustom03">
              <LabelComponent name="Website " />
              <Form.Control type="text" placeholder="Website" name="referralWebsite" onChange={handleDataChange} value={registrationData.referralWebsite} />
            </Form.Group>
            <Form.Group as={Col} md="3" controlId="validationCustom04">
              <LabelComponent name="NPI " />
              <Form.Control type="text" placeholder="NPI" name="referralNPI" onChange={handleDataChange} value={registrationData.referralNPI} />
            </Form.Group>
          </Row>
        </Form.Group>
        <Form.Group controlId="validationCustom03">
          <LabelHeaderComponentRequired name="Upload Compliance Forms " />
          <Row >
            <Form.Group as={Col} md="4" controlId="validationCustom03">
              <LabelComponent name="HIPAA " />
              <Row className="mb-9">
                <Form.Group as={Col} md="8" controlId="validationCustom03">
                  <Form.Control type="text" name="hippaId" value={registrationData.hippaId} disabled style={{ borderColor: hasError('hippaId') ? '#F24B5D' : '', boxShadow: 'none' }} />
                  <div
                    className={hasError('hippaId') ? 'inline-errormsg' : 'hidden'}
                  >
                    HIPAA form can not be empty
                  </div>
                </Form.Group>
                <Form.Group as={Col} md="4" controlId="validationCustom03">
                  <Form.Control type="button" value='UPLOAD' style={{ backgroundColor: '#F24B5D', borderRadius: '5px', color: 'white' }} onClick={() => hippaId.current.click()} />
                  <input
                    id="hippaId"
                    ref={hippaId}
                    type="file"
                    style={{ display: 'none' }}
                    accept='.docx, .doc, .pdf'
                    // accept="image/*,.pdf,.doc"
                    onChange={handleFileChange}
                  />
                </Form.Group>
              </Row>
            </Form.Group>
            <Form.Group as={Col} md="4" controlId="validationCustom04">
              <LabelComponent name="Treatment Consent " />
              <Row className="mb-9">
                <Form.Group as={Col} md="8" controlId="validationCustom03">
                  <Form.Control type="text" value={registrationData.treatmentConsentId} disabled style={{ borderColor: hasError('treatmentConsentId') ? '#F24B5D' : '', boxShadow: 'none' }} />
                  <div
                    className={hasError('treatmentConsentId') ? 'inline-errormsg' : 'hidden'}
                  >
                    Treatment Consent form can not be empty
                  </div>
                </Form.Group>
                <Form.Group as={Col} md="4" controlId="validationCustom03">
                  <Form.Control type="button" value='UPLOAD' style={{ backgroundColor: '#F24B5D', borderRadius: '5px', color: 'white' }} onClick={() => treatmentConsentId.current.click()} />
                  <input
                    id="treatmentConsentId"
                    ref={treatmentConsentId}
                    type="file"
                    style={{ display: 'none' }}
                    accept='.docx, .doc, .pdf'
                    // accept="image/*"
                    onChange={handleFileChange}
                  />
                </Form.Group>
              </Row>
            </Form.Group>
          </Row>
        </Form.Group>
        <Form.Group>
          <Row className="mb-9">
            <Form.Group as={Col} md="9">
            </Form.Group>
            <Form.Group as={Col} controlId="validationCustom03">
              {/* <Button type="submit">REGISTER</Button> */}
              <Button style={{ backgroundColor: '#F24B5D', borderRadius: '5px', border: 'none', color: 'white' }} onClick={handleSubmit} >REGISTER</Button>
            </Form.Group>
            <Form.Group as={Col} controlId="validationCustom03">
              <Button type="reset" style={{ backgroundColor: 'white', border: 'none', color: '#F24B5D' }} >RESET</Button>
            </Form.Group>
          </Row>
        </Form.Group>
      </Form>
    </>
  )
}

Registration.propTypes = {
  handleAllClientChange: PropTypes.func.isRequired
}
