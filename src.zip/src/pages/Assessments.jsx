import React, { useEffect, useState } from 'react'

import { MsalAuthenticationTemplate, useMsal, useAccount } from '@azure/msal-react'
import { InteractionType } from '@azure/msal-browser'
import { loginRequest } from '../authConfig'
import { NoAssignActivitiesFound } from '../CommonData/WorkInProgress'
import { LoaderModalPopUp, ModalPopUp } from '../CommonData/ModalPopUp'
import { callApiForListing } from '../fetch'
import { TableComponent } from '../components/TableComponent'
import { CoordinatorClientAssessmentsColumns } from '../CommonData/Data'
import { AppointmentsCommonUrl } from '../CommonData/APIListing'
import PropTypes from 'prop-types'
import { ClientAssessments } from './ClientAssessments'
import { createCoordinatorAppointmentsUrl } from '../CommonData/CreateAPIUrl'

const AssessmentsContent = ({ clientId, widthData, viewAppointmentClicked }) => {
  const [isAPICalling, setisAPICalling] = useState(false)
  const currentRole = JSON.parse(localStorage.getItem('UserType'))
  const { accounts, instance } = useMsal()
  const account = useAccount(accounts[0] || {})
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const [showLogOutErrorModal, setShowLogOutErrorModal] = useState(false)

  const [cardData, setCardData] = useState([])

  // For Today, This Month , This week, All related

  const getAllAssessmentsListing = () => {
    const clientIdData = clientId === undefined ? account.idTokenClaims.sub : clientId

    const appointmentUrl = `${createCoordinatorAppointmentsUrl(account, AppointmentsCommonUrl)}/client/${clientIdData}/assessments`

    // const appointmentUrl = `${CoordinatorAppointments}/client/${clientId}/assessments`
    // console.log("Client appt URL::", appointmentUrl, selectd);
    setisAPICalling(true)
    callApiForListing(appointmentUrl)
      .then((response) => {
        // console.log("Appointment Listing API Resp:-", response);
        const finalResp = response && typeof (response) === 'object' ? response : []

        setisAPICalling(false)
        // setcardDataDefault(response)
        setCardData(finalResp)
      })
  }

  const getAppointmentData = (apptId) => {
    const getAppointmentDataById = createCoordinatorAppointmentsUrl(account, AppointmentsCommonUrl)
    const appointmentUrl = `${getAppointmentDataById}/${apptId}`
    // console.log("Client appt URL::", appointmentUrl, selectd);
    setisAPICalling(true)
    callApiForListing(appointmentUrl)
      .then((response) => {
        // console.log('getAppointmentDataby ID API Resp:-', response)
        const finalResp = response && typeof (response) === 'object' ? response : {}
        setisAPICalling(false)
        // setcardDataDefault(response)
        finalResp.clientName && viewAppointmentClicked(finalResp, 'assessments')
      })
  }

  // Table Column Button View Details Click handler
  const onRowClicked = (row, e) => {
    // console.log('table event Data::', row.original)
    if (e.target.nodeName === 'BUTTON' && (e.target.innerText === 'VIEW DETAILS')) {
      getAppointmentData(row.original.appointmentId)
      window.location.reload('false')
    }
  }
  /// //////

  // This useeffect is used to check if any other user is logged in in other tab or not
  useEffect(() => {
    if (account.idTokenClaims.sub !== userData.id) {
      setShowLogOutErrorModal(true)
    }
  })
  useEffect(() => {
    getAllAssessmentsListing()
  }, [])
  const logOutUser = () => {
    // localStorage.clear()
    instance.logoutRedirect({ postLogoutRedirectUri: '/' })
  }
  return (
    <div style={{ border: '1px solid #EEEEEE' }}>
      <ModalPopUp handleModalPopUp={logOutUser} show={showLogOutErrorModal} header="Error!" messageBody='Another user is logged in. You will be logout' />
      {
        currentRole === 'Client'
          ? (
            <ClientAssessments />
            )
          : (
            <>
              <LoaderModalPopUp show={isAPICalling} message='Fetching Activities and Assessments data...' />

              <div style={{ padding: '10px', color: '#2D2D34' }} >
                {
                  cardData && cardData.length
                    ? (<TableComponent columns={CoordinatorClientAssessmentsColumns} data={cardData} onRowClicked={onRowClicked} showHeader={true} tableWidth={widthData} />)
                    : (<NoAssignActivitiesFound></NoAssignActivitiesFound>)
                }
              </div>
            </>
            )
      }
    </div>
  )
}
AssessmentsContent.propTypes = {
  clientId: PropTypes.string,
  widthData: PropTypes.string,
  viewAppointmentClicked: PropTypes.func
}
/**
 * The `MsalAuthenticationTemplate` component will render its children if a user is authenticated
 * or attempt to sign a user in. Just provide it with the interaction type you would like to use
 * (redirect or popup) and optionally a [request object](https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/request-response-object.md)
 * to be passed to the login API, a component to display while authentication is in progress or a component to display if an error occurs. For more, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-react/docs/getting-started.md
 */
export const Assessments = ({ clientId, widthData, viewAppointmentClicked }) => {
  const authRequest = {
    ...loginRequest
  }

  return (
    <MsalAuthenticationTemplate
      interactionType={InteractionType.Redirect}
      authenticationRequest={authRequest}
    >
      <AssessmentsContent clientId={clientId} widthData={widthData} viewAppointmentClicked={viewAppointmentClicked} />
    </MsalAuthenticationTemplate>
  )
}
Assessments.propTypes = {
  clientId: PropTypes.string,
  widthData: PropTypes.string,
  viewAppointmentClicked: PropTypes.func
}
