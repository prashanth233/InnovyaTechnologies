/* eslint-disable object-curly-spacing */
/* eslint-disable array-callback-return */
import React, { useState, useEffect } from 'react'
import video from '../Assets/video.png'
import { useMsal, useAccount } from '@azure/msal-react'

// import axios from "axios";
import { TableComponent } from '../components/TableComponent'
import { Button, Image } from 'react-bootstrap'
import { AssignActivitiesAssessmentsModal, LoaderModalPopUp } from '../CommonData/ModalPopUp'
import { NoActivitiesFound } from '../CommonData/WorkInProgress'
import '../styles/App.css'
import { AppointmentsCommonUrl } from '../CommonData/APIListing'
import { callApiForListing, callApiForUpdate } from '../fetch'
import { ActivitiesListingColumns, ClientActivitiesHWListingColumns, ClientActivitiesListingColumns } from '../CommonData/Data'
import PropTypes from 'prop-types'
import { createCoordinatorAppointmentsUrl } from '../CommonData/CreateAPIUrl'
import { isMobile } from 'react-device-detect'

const widthValue = isMobile ? '80vw' : '90vw'

export const ActivitiesAssessmentsData = ({ appointmentDetail, type, widthData, isMeetingStarted, playVideoHandler, refreshData, clientPlayVideo }) => {
  const currentRole = JSON.parse(localStorage.getItem('UserType'))
  const { accounts } = useMsal()
  const account = useAccount(accounts[0] || {})
  const columnData = currentRole === 'Client' ? clientPlayVideo ? ClientActivitiesHWListingColumns : ClientActivitiesListingColumns : ActivitiesListingColumns
  const [isAPICalling, setisAPICalling] = useState(false)

  const [activitiesData, setActivitiesData] = useState([])

  const [showAssignModal, setShowAssignModal] = useState(false)

  const getActivitiesData = () => {
    setisAPICalling(true)
    const getActivitiesUrl = `${createCoordinatorAppointmentsUrl(account, AppointmentsCommonUrl)}/${appointmentDetail.appointmentId}/${type}`

    callApiForListing(getActivitiesUrl)
      .then((response) => {
        const finalResp = response && response.length ? response : []

        if (finalResp.length) {
          finalResp.map(obj => {
            obj.meetingStatus = `NotStarted:${obj.status}`

            if (isMeetingStarted) {
              // obj.meetingStatus = "InProgress";
              obj.meetingStatus = `InProgress:${obj.status}`
            }
          })
        }

        setisAPICalling(false)
        setActivitiesData(finalResp)
        // setCardData(finalResp)
      })
  }
  const onAssignClick = () => {
    if (type === 'activities') {
      setShowAssignModal(true)
    }
  }

  // Remove AActivities
  const removeActivity = (forData) => {
    setisAPICalling(true)
    const apiUrl = `${createCoordinatorAppointmentsUrl(account, AppointmentsCommonUrl)}/${forData.appointmentId}/activities`
    // console.log('Activities listing Calculated Url::', tempUrl)

    // console.log('Old Url::', apiUrl)

    let dataToSend = {}

    dataToSend = {
      addAppointmentActivities: [

      ],
      removeAppointmentActivities: [
        {
          id: forData.id,
          clientId: forData.clientId,
          activityId: forData.id,
          status: 'Remove',
          appointmentId: forData.appointmentId,
          activityType: forData.type,
          videoWatchDuration: forData.videoWatchDuration,
          tenantId: forData.tenantId
        }

      ]
    }
    callApiForUpdate(apiUrl, dataToSend)
      .then((response) => {
        setisAPICalling(false)
        if (response && response[0]) {
          const finalData = activitiesData.filter(data => data.id !== response[0].activityId)
          setActivitiesData(finalData)
        }
      })
  }

  /// /////Table Click handler=============
  const onRowClicked = (row, e) => {
    const buttonClick = e.target.innerText
    // console.log('Activity assess table event Data::', e.target.innerText, e.target.nodeName)
    if (e.target.nodeName === 'BUTTON') {
      if (buttonClick === 'REMOVE') {
        removeActivity(row.original)
      }
      if (buttonClick === 'PLAY' || buttonClick === 'RESUME' || buttonClick === 'PLAY AGAIN' || buttonClick === 'In Progress') {
        playVideoHandler(row.original)
      }
    }

    // assignRemoveActivities(row.original,e.target.innerText)
    // console.log("table row Data::", row, row.index);
  }
  /// //////
  const handleModalPopUp = () => {
    setShowAssignModal(false)
    getActivitiesData()
  }
  useEffect(() => {
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = ''
    }
  })
  useEffect(() => {
    if (refreshData) {
      // console.log('Activities data effect check')
      const timeout = setTimeout(() => {
        getActivitiesData()
      }, 3000)
      return () => clearTimeout(timeout)
    }
  }, [refreshData])
  useEffect(() => {
    getActivitiesData()
    // console.log('Activities tab effect')
  }, [type, isMeetingStarted, appointmentDetail])
  return (
    <>
      <LoaderModalPopUp show={isAPICalling} message='Fetching Activities and Assessments data...' />
      <AssignActivitiesAssessmentsModal show={showAssignModal} data={appointmentDetail} handleModalPopUp={handleModalPopUp} listingData={activitiesData} type={type} ></AssignActivitiesAssessmentsModal>
      <div style={{ backgroundColor: 'white', border: '2px solid #EEEEEE', minHeight: '50vh', height: '100%', borderRadius: '0 0 8px 8px', borderTop: 'none' }}>
        <div style={{ width: widthValue }}>

          {
            type === 'activities'
              ? (<div style={{ display: 'flex', justifyContent: 'space-between', paddingLeft: 10, paddingTop: 10 }}>
                <>
                  <div>
                    <Image style={{ marginTop: '-6px', width: '24px', height: '24px' }} src={video} />
                    <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto, Regular', fontSize: '16px' }}>Media</label>
                  </div>
                  {currentRole !== 'Client' &&
                  <Button variant="danger" id="details" style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', backgroundColor: 'white', color: '#F24B5D', border: 'none', height: 35 }} onClick={onAssignClick}>ASSIGN</Button>
                  }
                  </>
              </div>)
              : (<div style={{ display: 'flex', justifyContent: 'right', paddingLeft: 10, paddingTop: 10 }}>
                {currentRole !== 'Client' && <Button variant="danger" id="details" style={{ fontFamily: 'Roboto, Regular', fontSize: '19px', backgroundColor: 'white', color: '#F24B5D', border: 'none', height: 35 }} onClick={onAssignClick}>ASSIGN</Button> }
              </div>)
          }

          <div style={{ padding: 10}}>
            {
              activitiesData && activitiesData.length
                ? (<TableComponent columns={columnData} data={activitiesData} onRowClicked={onRowClicked} showHeader={true} tableWidth={widthValue} />)
                : (<NoActivitiesFound type={type} />)
            }
          </div>

        </div>
      </div>
    </>
  )
}

ActivitiesAssessmentsData.propTypes = {
  type: PropTypes.string,
  widthData: PropTypes.string,
  isMeetingStarted: PropTypes.bool,
  clientPlayVideo: PropTypes.bool,
  refreshData: PropTypes.bool,
  appointmentDetail: PropTypes.object,
  playVideoHandler: PropTypes.func
}
