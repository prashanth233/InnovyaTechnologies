/* eslint-disable array-callback-return */
import React, { useState, useRef, useEffect } from 'react'
import '../styles/App.css'
import { Form, Col, Row, Button } from 'react-bootstrap'
import { useMsal, useAccount } from '@azure/msal-react'
import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import ProfileEdit from '../Assets/ProfileEdit.png'
import { Avatar, Badge, Divider } from '@mui/material'
import { styled } from '@mui/material/styles'
import { languagePref } from '../CommonData/Data'
import { LabelComponent, LabelComponentRequired } from './LabelComponent'
import Loader from './Loader'
import PropTypes from 'prop-types'
import { useLocation } from 'react-router'
import { useHistory } from 'react-router-dom'
import { callApiForProfile, callApiForRegistration } from '../fetch'
import { userDataAPI } from '../CommonData/APIListing'

import { LoaderModalPopUp, ModalPopUp } from '../CommonData/ModalPopUp'
import { createProfileBaseUrl } from '../CommonData/CreateAPIUrl'

export const UpdateUserProfile = () => {
  const location = useLocation()
  const history = useHistory()
  const currentUser = JSON.parse(localStorage.getItem('currentUser'))

  const { accounts, instance } = useMsal()
  const account = useAccount(accounts[0] || {})
  const userDataLocal = JSON.parse(localStorage.getItem('UserData'))
  const [showLogOutErrorModal, setShowLogOutErrorModal] = useState(false)

  const userId = currentUser.sub
  const currentRole = JSON.parse(localStorage.getItem('UserType'))
  const [photoChanged, setPhotoChanged] = useState(false)
  const profileFile = useRef(null)
  const [isAPICalling, setIsAPICalling] = useState(false)
  const [isLoading, setLoading] = useState(false)
  const [imgFile, setImgFile] = useState(ProfilePlaceholder)
  const [errors, setErrors] = useState([])

  const [userData, serUserData] = useState({})

  const [registrationData, setRegistrationData] = useState(location.state.userData)
  let userLangPref = ''
  languagePref.forEach(element => {
    if (element.code === registrationData.languagePreferences) {
      userLangPref = element.language
    }
  })
  const [userLang, setUserLang] = useState(userLangPref)
  const [headerMessage, setHeaderMessage] = useState('')

  const [showModal, setShowModal] = useState(false)
  const [showErrorModal, setShowErrorModal] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')

  const handleSubmit = (event) => {
    const requiredDataCheck = Object.assign({}, registrationData)
    const deleteKeysData = ['age', 'middleName', 'dob', 'babyDOB', 'gender', 'id', 'insurenceId', 'insurenceName', 'insurencePlan', 'mrnNo', 'referralName', 'country', 'consultationRate', 'photo', 'referralPracticeName', 'practitionerPracticeName']
    deleteKeysData.forEach(element => {
      delete requiredDataCheck[element]
    })

    const errorsData = []
    // console.log('requiredDataCheck Data:', requiredDataCheck)
    Object.entries(requiredDataCheck).map(([key, value]) => {
      value !== null && value.length === 0 && errorsData.push(key)
      if (['mobileNo', 'zip'].indexOf(key) !== -1 && !Number(value)) {
        errorsData.push(key)
      }
      setErrors(errorsData)
    })

    // console.log('Errors Data:', errorsData.length, errorsData)
    if (errorsData.length === 0) {
      //   event.stopPropagation()
      //   //   setIsAPICalling(true)
      saveFormData()
    }
  }
  const handleReset = (event) => {
    setRegistrationData({})
    setRegistrationData(userData)
    setPhotoChanged(false)
    // event.preventDefault();
    event.stopPropagation()
  }
  const SmallAvatar = styled(Avatar)(({ theme }) => ({
    left: -10,
    top: -5,
    width: 30,
    height: 30,
    border: '1px solid #F24B5D' // ${theme.palette.background.paper}
  }))

  const hasError = (key) => {
    return errors.indexOf(key) !== -1
  }

  const handleDataChange = (e) => {
    const { name, value } = e.target
    const errors = []
    if (!Number(value) && ['mobileNo', 'zipCode'].indexOf(name) !== -1) {
      errors.push(name)
    }
    if (value === '' && ['address', 'city', 'state'].indexOf(name) !== -1) {
      errors.push(name)
    }
    if (name === 'languagePreferences') {
      setUserLang(value)
    }

    // email
    // '/\S+@\S+\.\S+/'
    // const expression = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/ /// \S+@\S+/;
    const expression = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/ /// \S+@\S+/;

    const validEmail = expression.test(String(value).toLowerCase())

    if (!validEmail && name === 'email') {
      errors.push(name)
    }
    setErrors(errors)
    setRegistrationData(oldState => ({ ...oldState, [name]: value }))
  }

  const handleFileChange = (event) => {
    setLoading(true)
    const file = event.target.files[0]
    const reader = new FileReader()
    // console.log('Img data::', reader.result, file, reader)

    reader.onload = () => {
      // console.log('Img data::', reader.result)
      setImgFile(reader.result)
      setLoading(false)
      setPhotoChanged(true)
    }
    reader.readAsDataURL(file)
  }

  const saveFormData = () => {
    setIsAPICalling(true)
    setHeaderMessage('Updating user details...')

    let langPrefCode // = registrationData.languagePreference === '' ? 'en-US' : registrationData.languagePreference
    languagePref.forEach(element => {
      if (element.language === userLang) {
        langPrefCode = element.code
      }
    })
    let saveData = {
      id: registrationData.id,
      firstName: registrationData.firstName,
      middleName: registrationData.middleName,
      lastName: registrationData.lastName,
      email: registrationData.email,
      mobileNo: registrationData.mobileNo,
      address: registrationData.address,
      city: registrationData.city,
      state: registrationData.state,
      zip: registrationData.zipCode,
      photoId: photoChanged ? imgFile : '',
      userName: registrationData.userName,
      languagePreference: langPrefCode,
      referralPracticeName: registrationData.referralPracticeName
    }

    if (currentRole === 'Practitioner') {
      delete saveData.languagePreference
      delete saveData.referralPracticeName
      delete saveData.id

      saveData = {
        ...saveData,
        consultationRate: registrationData.consultationRate,
        practiceName: registrationData.practiceName,
        practitionerId: registrationData.id
      }
    }
    if (currentRole === 'Coordinator') {
      delete saveData.languagePreference
      delete saveData.referralPracticeName

      saveData = {
        ...saveData,
        employeeId: currentUser && currentUser.extension_EmployeeId,
        email: currentUser && currentUser.emails[0]

      }
    }

    // console.log('saveData Resp:-', saveData)
    const profileUrl = `${createProfileBaseUrl(account, userDataAPI)}/${currentRole.toLowerCase()}/${registrationData.id}`

    // const reqUrl = `${profileBaseUrl}/${currentRole.toLowerCase()}/${registrationData.id}`

    callApiForRegistration(profileUrl, saveData)
      .then((response) => {
        // console.log('Update profile API Resp:-', response)
        setIsAPICalling(false)
        if (response && response === `${currentRole} Updated Successfully`) {
          setShowModal(true)
          setHeaderMessage('User Update')

          if (photoChanged) {
            const userdata = {
              ...userDataLocal,
              photo: imgFile
            }
            localStorage.setItem('UserData', JSON.stringify(userdata))
          }
        } else {
          setShowErrorModal(true)
        }
        setErrorMessage(response)
      })
      .catch(error => console.log('API Catch eror main class', error))
  }

  const getUserDetails = () => {
    setIsAPICalling(true)
    setHeaderMessage('Fetching user details...')
    const profileUrl = createProfileBaseUrl(account, userDataAPI)

    callApiForProfile(profileUrl, userId, currentRole.toLowerCase())
      .then((response) => {
        // console.log('Get user profile API Resp:-', response)
        const finalResp = response || {}
        setImgFile(finalResp.photo === '' ? ProfilePlaceholder : finalResp.photo)
        setIsAPICalling(false)
        setRegistrationData(finalResp)
        serUserData(finalResp)
        languagePref.forEach(element => {
          if (element.code === finalResp.languagePreferences) {
            setUserLang(element.language)
          }
        })
      })
  }

  // const handleChangePassword = () => {
  //   console.log('handleChangePassword call')
  // }
  useEffect(() => {
    getUserDetails()
  }, [])

  // This useeffect is used to check if any other user is logged in in other tab or not
  useEffect(() => {
    if (account.idTokenClaims.sub !== userDataLocal.id) {
      setShowLogOutErrorModal(true)
    }
  })
  const logOutUser = () => {
    // localStorage.clear()
    instance.logoutRedirect({ postLogoutRedirectUri: '/' })
  }

  const handleModalPopUp = () => {
    setShowModal(!showModal)
    history.goBack()
  }
  const handleErrorModalPopUp = () => {
    setShowErrorModal(false)
  }
  // console.log('userLang::', userLang)

  return (
    <>
      <ModalPopUp handleModalPopUp={handleModalPopUp} show={showModal} header={headerMessage} messageBody={errorMessage} />
      <ModalPopUp handleModalPopUp={handleErrorModalPopUp} show={showErrorModal} header="Error!" messageBody={errorMessage} />
      <ModalPopUp handleModalPopUp={logOutUser} show={showLogOutErrorModal} header="Error!" messageBody='Another user is logged in. You will be logout' />

      <LoaderModalPopUp show={isAPICalling} message={headerMessage} />
      <div style={{ padding: '20px', backgroundColor: '#DFDFDF' }}>
        <div style={{ backgroundColor: 'white', padding: 20, borderRadius: 15 }}>
          <Form noValidate onReset={handleReset}>
            <div style={{ fontFamily: 'Roboto, Light', fontSize: 20, color: '#139ED7' }}> Edit Profile </div>
            <Divider variant="middle" style={{ padding: '10px' }} />

            <div style={{ paddingLeft: 20, paddingTop: 10, display: 'flex', justifyContent: 'start' }}>
              <div>
                <div style={{ marginRight: '35px', width: '148px', height: '148px' }}>
                  {
                    isLoading
                      ? (
                        <Loader />
                        )
                      : (
                        <>
                          <Badge
                            overlap="circular"
                            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                            badgeContent={
                              <SmallAvatar onClick={() => profileFile.current.click()} src={ProfileEdit} />
                            }
                          >
                            <Avatar
                              src={imgFile}
                              // src={registrationData["photo"] === "" ? ProfilePlaceholder : registrationData["photo"]}
                              rounded
                              sx={{ width: 148, height: 148 }}
                            />
                          </Badge>
                          <input
                            id="profile"
                            ref={profileFile}
                            type="file"
                            style={{ display: 'none' }}
                            accept="image/*"
                            onChange={handleFileChange}
                          />
                        </>
                        )
                  }

                </div>
                <Divider variant="middle" style={{ padding: '15px', marginLeft: '-5px', width: '130px' }} />
                {/* <Button style={{ marginLeft: '-15px', backgroundColor: 'white', border: 'none', color: '#F24B5D' }} onClick={handleChangePassword} >CHANGE PASSWORD</Button> */}
              </div>
              <div >
                <Row style={{ width: '70vw' }}>
                  <Form.Group as={Col} controlId="validationCustom01">
                    <LabelComponentRequired name="First Name " />
                    <Form.Control
                      disabled
                      type="text"
                      placeholder="First Name"
                      name='firstName'
                      value={registrationData.firstName}
                      onChange={handleDataChange}
                    />
                  </Form.Group>
                  <Form.Group as={Col} controlId="validationCustom02">
                    <LabelComponent name="Middle Name " />
                    <Form.Control
                      type="text"
                      placeholder="Middle Name"
                      name='middleName'
                      value={registrationData.middleName}
                      onChange={handleDataChange}
                    />
                  </Form.Group>
                  <Form.Group as={Col} controlId="validationCustom02">
                    <LabelComponentRequired name="Last Name " />
                    <Form.Control
                      disabled
                      type="text"
                      placeholder="Last Name"
                      name='latstName'
                      value={registrationData.lastName}
                      onChange={handleDataChange}
                    />
                  </Form.Group>
                </Row>
                <Row style={{ width: '70vw' }}>
                  <Form.Group as={Col} controlId="validationCustom02">
                    <LabelComponent name="Email " />
                    <Form.Control type="text" name="email" value={registrationData.email !== null ? registrationData.email : currentUser.emails && currentUser.emails[0]} onChange={handleDataChange} placeholder="Email" disabled />
                    <div
                      className={hasError('email') ? 'inline-errormsg' : 'hidden'}
                    >
                      Email is invalid or missing
                    </div>
                  </Form.Group>
                  <Form.Group as={Col} controlId="validationCustom02">
                    <LabelComponentRequired name="Mobile Number " />
                    <Form.Control type="text" name="mobileNo" value={registrationData.mobileNo} onChange={handleDataChange} placeholder="Mobile Number" required style={{ borderColor: hasError('mobileNo') ? '#F24B5D' : '', boxShadow: 'none' }} />
                    <div
                      className={hasError('mobileNo') ? 'inline-errormsg' : 'hidden'}
                    >
                      Please enter valid mobile number
                    </div>
                  </Form.Group>
                  <Form.Group as={Col} controlId="validationCustom02">
                    <LabelComponent name="Username " />
                    <Form.Control disabled type="text" name="userName" value={registrationData.userName} onChange={handleDataChange} placeholder="User Name" />
                  </Form.Group>
                </Row>
                <Row >
                  <Form.Group as={Col} controlId="validationCustom04">
                    <LabelComponentRequired name="Address " />
                    <Form.Control type="text" placeholder="Address" name="address" onChange={handleDataChange} value={registrationData.address} required />
                    <div
                      className={hasError('address') ? 'inline-errormsg' : 'hidden'}
                    >
                      Please enter valid address
                    </div>
                  </Form.Group>
                  <Form.Group as={Col} controlId="validationCustom03">
                    <LabelComponentRequired name="City " />
                    <Form.Control type="text" placeholder="City" name="city" onChange={handleDataChange} value={registrationData.city} required />
                    <div
                      className={hasError('city') ? 'inline-errormsg' : 'hidden'}
                    >
                      Please provide valid City
                    </div>
                  </Form.Group>
                </Row>
                <Row >
                  <Form.Group as={Col} controlId="validationCustom05">
                    <LabelComponentRequired name="Zip Code " />
                    <Form.Control type="text" placeholder="Zip Code" name="zipCode" onChange={handleDataChange} value={registrationData.zipCode} required />
                    <div
                      className={hasError('zipCode') ? 'inline-errormsg' : 'hidden'}
                    >
                      Please enter only numeric values
                    </div>
                  </Form.Group>
                  <Form.Group as={Col} controlId="validationCustom04">
                    <LabelComponentRequired name="State " />
                    <Form.Control type="text" placeholder="State" name="state" onChange={handleDataChange} value={registrationData.state} required />
                    <div
                      className={hasError('state') ? 'inline-errormsg' : 'hidden'}
                    >
                      Please provide valid State
                    </div>
                  </Form.Group>
                </Row>
                {
                  currentRole === 'Client' && (
                    <Row>
                      <Form.Group as={Col} md="4" controlId="validationCustom03">
                        <LabelComponent name="Referring Practice Name " />
                        <Form.Control type="text" value={registrationData.referralPracticeName} name="referralPracticeName" disabled />
                      </Form.Group>
                      <Form.Group as={Col} md="4" >
                        <LabelComponent name="Language Preference " />
                        <Form.Control as="select" value={userLang} name="languagePreferences" onChange={handleDataChange}>
                          {
                            languagePref.map((x, y) =>
                              <option key={y}>{x.language}</option>)
                          }
                        </Form.Control>
                      </Form.Group>
                    </Row>
                  )
                }
                {
                  currentRole === 'Practitioner' && (
                    <Row>
                      <Form.Group as={Col} md="4" controlId="validationCustom03">
                        <LabelComponent name="Practitioner's Practice Name " />
                        <Form.Control type="text" value={registrationData.practitionerPracticeName} name="practitionerPracticeName" disabled />
                      </Form.Group>
                      <Form.Group as={Col} md="4" >
                        <LabelComponent name="Consultation Hourly Rate (Dollars) " />
                        <Form.Control type="text" value={registrationData.consultationRate === '' ? '' : `$${registrationData.consultationRate}/hr`} name="consultationRate" disabled />
                      </Form.Group>
                    </Row>
                  )
                }
                {
                  currentRole === 'Coordinator' && (
                    <Row>
                      <Form.Group as={Col} md="4" controlId="validationCustom03">
                        <LabelComponent name="Coordinator's Practice Name " />
                        <Form.Control type="text" value={registrationData.practiceName} name="practiceName" disabled />
                      </Form.Group>
                      <Form.Group as={Col} md="4" >
                        <LabelComponent name="Employee ID " />
                        <Form.Control type="text" value={currentUser && currentUser.extension_EmployeeId} name="employeeId" disabled />
                      </Form.Group>
                    </Row>
                  )
                }
              </div>
            </div>
            <Divider variant="middle" style={{ padding: '10px' }} />
            <Form.Group style={{ padding: '30px' }}>
              <Row style={{ float: 'right' }}>
                {/* <Form.Group as={Col} md="10">
                    </Form.Group> */}
                <Form.Group md="auto" controlId="validationCustom03">
                  <Button style={{ backgroundColor: '#F24B5D', borderRadius: '5px', border: 'none', color: 'white' }} onClick={handleSubmit} >Save</Button>
                </Form.Group>
                <Form.Group md="auto" controlId="validationCustom03">
                  <button type="reset" style={{ backgroundColor: 'white', border: '1px red solid', color: '#F24B5D', borderRadius: '5px', height: '35px', marginLeft: '20px' }} onClick={() => history.goBack()} >Cancel</button>
                </Form.Group>
              </Row>
            </Form.Group>
            <br />
          </Form>
        </div>
      </div>
    </>
  )
}

UpdateUserProfile.propTypes = {
  userData: PropTypes.object
}
