/* eslint-disable array-callback-return */
import React from 'react'

import { NoActivitiesFound } from '../CommonData/WorkInProgress'
import '../styles/App.css'
import PropTypes from 'prop-types'
import { ClientAssessmentCards } from '../Cards/ClientAssessmentCards'

export const ClientAssessmentListing = ({ assessmentsData }) => {
  return (
    <>

          <div style={{ border: '1px solid #EEEEEE', minHeight: '45vh', height: '100%', borderRadius: '0 0 3px 3px', borderTop: 'none' }}>
            {
              assessmentsData && assessmentsData.length
                ? (<ClientAssessmentCards assessmentsData={assessmentsData}></ClientAssessmentCards>
                  )
                : (<NoActivitiesFound type={'type'} />)
            }
          </div>

    </>
  )
}

ClientAssessmentListing.propTypes = {
  assessmentsData: PropTypes.array

}
