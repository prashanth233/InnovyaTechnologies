import React, { useEffect, useState } from 'react'

import { MsalAuthenticationTemplate, useMsal, useAccount } from '@azure/msal-react'
import { InteractionType, InteractionRequiredAuthError } from '@azure/msal-browser'

import { loginRequest, protectedResources } from '../authConfig'

import { useHistory } from 'react-router-dom'
import { callApiForCoordinatorRegistration, callApiForListing } from '../fetch'
import { LoaderModalPopUp, ModalPopUp } from '../CommonData/ModalPopUp'
import moment from 'moment'

import { CoordinatorBaseURL, userDataAPI } from '../CommonData/APIListing'

const HelloContent = () => {
  const history = useHistory()

  const { accounts, inProgress, instance } = useMsal()

  const [isAPICalling, setIsAPICalling] = useState(false)

  const [showErrorModal, setShowErrorModal] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')

  const account = useAccount(accounts[0] || {})
  const currentRole = JSON.parse(localStorage.getItem('UserType'))
  localStorage.setItem('currentUser', JSON.stringify(account.idTokenClaims))
  // console.log('User account data::', account)

  const coordinatorData = (account) => {
    const dateStr = moment(new Date()).format('yyyy-MM-DDTHH:mm:ss.SSS')
    const data = {
      id: account.idTokenClaims.sub,
      firstName: account.idTokenClaims.extension_FirstName,
      middleName: '',
      lastName: account.idTokenClaims.extension_LastName,
      email: account.username,
      mobileNo: '',
      userName: '',
      practiceName: account.idTokenClaims.extension_PracticeName,
      address: account.idTokenClaims.streetAddress,
      city: account.idTokenClaims.city,
      state: account.idTokenClaims.state,
      country: account.idTokenClaims.country,
      zip: account.idTokenClaims.postalCode,
      employeeId: account.idTokenClaims.extension_EmployeeId,
      tenantId: account.idTokenClaims.extension_Organization,
      createdBy: `${account.idTokenClaims.extension_FirstName} ${account.idTokenClaims.extension_LastName}`,
      createdDate: dateStr,
      updatedBy: `${account.idTokenClaims.extension_FirstName} ${account.idTokenClaims.extension_LastName}`,
      updatedDate: dateStr,
      photoId: ''
    }

    return data
  }

  const callCoordinatorAPI = (account) => {
    // console.log('callCoordinatorAPI::')
    const coordinatorBody = coordinatorData(account)
    const tenantId = account.idTokenClaims.extension_Organization
    const practiceName = account.idTokenClaims.extension_PracticeName
    const coordinatorRegi = `${CoordinatorBaseURL}${tenantId}/${practiceName}/coordinator`
    callApiForCoordinatorRegistration(coordinatorRegi, coordinatorBody)
      .then((response) => {
        // console.log('Coordinator Regi::', response)
        localStorage.setItem('UserData', JSON.stringify(response))
        userRedirectionAsPerRole()
      })
  }

  const userUpdateData = (account) => {
    const data = {
      firstName: account.idTokenClaims.extension_FName,
      middleName: account.idTokenClaims.extension_MiddleName,
      lastName: account.idTokenClaims.extension_LastName,
      tenantId: account.idTokenClaims.extension_Organization,
      email: account.username,
      id: account.idTokenClaims.sub
    }
    return data
  }

  const callUserUpdateAPI = (account) => {
    const coordinatorBody = userUpdateData(account)
    const tenantId = account.idTokenClaims.extension_Organization
    const userType = currentRole === 'Client' ? 'updateuser' : 'updatepractitioner'
    const coordinatorRegi = `${userDataAPI}${tenantId}/${userType}`

    callApiForCoordinatorRegistration(coordinatorRegi, coordinatorBody)
      .then((response) => {
        // console.log('Client/ Pract Pract Regi::', response)
        localStorage.setItem('UserData', JSON.stringify(response))
        userRedirectionAsPerRole()
      })
  }

  const userRedirectionAsPerRole = () => {
    setIsAPICalling(false)

    switch (currentRole) {
      case 'Client':
        history.push('/appointments')
        window.location.reload('false')
        break
      case 'Practitioner':
        history.push('/overview')
        window.location.reload('false')
        break
      case 'Coordinator':
        history.push('/clients')
        break

      default:
        history.push('/clients')
        break
    }
  }

  const getUserDetails = () => {
    const tenantId = account.idTokenClaims.extension_Organization
    const UserId = account && account.idTokenClaims.sub

    const coordinatorRegi = `${userDataAPI}${tenantId}/user?id=${UserId}&userType=${currentRole}`

    callApiForListing(coordinatorRegi)
      .then((response) => {
        // console.log('getUserDetails resp::', response)
        const finalResp = response && typeof (response) === 'object' ? response : {}
        if (finalResp.firstName) {
          localStorage.setItem('UserData', JSON.stringify(response))

          userRedirectionAsPerRole()
        } else {
          setShowErrorModal(true)
          setErrorMessage(response)
        }
      })
  }

  useEffect(() => {
    setIsAPICalling(true)
    if (account && inProgress === 'none') {
      instance.acquireTokenSilent({
        scopes: protectedResources.apiHello.scopes,
        account: account
      }).then((response) => {
        const newUser = response.idTokenClaims.newUser
        // console.log('access token password::', response, account)
        localStorage.setItem('idToken', JSON.stringify(response.accessToken))
        const newUserData = JSON.parse(localStorage.getItem('newUserData'))

        // console.log('newUserData check::', newUserData, newUser)

        if (newUser && !newUserData) {
          localStorage.setItem('newUserData', newUser)
          if (currentRole === 'Coordinator') {
            callCoordinatorAPI(account)
          } else {
            callUserUpdateAPI(account)
          }
          // Call above API for the Coordinator Data to be submittted
        } else {
          // userRedirectionAsPerRole()
          getUserDetails()
        }
      }).catch((error) => {
        // in case if silent token acquisition fails, fallback to an interactive method
        if (error instanceof InteractionRequiredAuthError) {
          if (account && inProgress === 'none') {
            instance.acquireTokenPopup({
              scopes: protectedResources.apiHello.scopes
            }).then((response) => {
              localStorage.setItem('currentUser', JSON.stringify(response.idTokenClaims))
              localStorage.setItem('idToken', JSON.stringify(response.accessToken))
              // console.log('User Role catch dashboard::', response)
              userRedirectionAsPerRole()
            }).catch(error => console.log(error))
          }
        }
      })
    } else {
      setIsAPICalling(false)
    }
  }, [account, inProgress])

  const logOutUser = () => {
    // localStorage.clear()
    instance.logoutRedirect({ postLogoutRedirectUri: '/' })
  }
  // '#FFF5F6'
  return (
        <>
            <LoaderModalPopUp show={isAPICalling} message='Loading...' />
            <ModalPopUp handleModalPopUp={logOutUser} show={showErrorModal} header="Error!" messageBody={errorMessage} />

        </>
  )
}

/**
 * The `MsalAuthenticationTemplate` component will render its children if a user is authenticated
 * or attempt to sign a user in. Just provide it with the interaction type you would like to use
 * (redirect or popup) and optionally a [request object](https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/request-response-object.md)
 * to be passed to the login API, a component to display while authentication is in progress or a component to display if an error occurs. For more, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-react/docs/getting-started.md
 */
export const Dashboard = () => {
  const authRequest = {
    ...loginRequest
  }

  return (
        <MsalAuthenticationTemplate
            interactionType={InteractionType.Redirect}
            authenticationRequest={authRequest}
        >
            <HelloContent />
        </MsalAuthenticationTemplate>
  )
}
