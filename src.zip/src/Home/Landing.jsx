/* eslint-disable no-unused-vars */
/* eslint-disable no-useless-escape */
import React from 'react'
import './Landing.css'
import { useMsal } from '@azure/msal-react'
import { loginRequest, b2cPolicies } from '../authConfig'
import pracImg from '../Assets/practitioner.png'
import patImg from '../Assets/patient.png'
import coordImg from '../Assets/coordinator.png'
import logoImg from '../Assets/Logo.png'
import vector from '../Assets/Vector 1.png'
import VRLady from '../Assets/VR Lady1.png'
import HomeCard from '../Cards/HomeCard'
import config from '../config'

import {
  isDesktop,
  isIOS,
  isMobile,
  isMobileOnly,
  isMobileSafari,
  isTablet,
  mobileModel,
  osName
} from 'react-device-detect'

function Landing () {
  const { instance } = useMsal()
  const cardData = [
    { name: 'Client', img: patImg },
    { name: 'Practitioner', img: pracImg },
    { name: 'Coordinator', img: coordImg }
  ]

  const onLoginCall = (event) => {
    const userRole =
      event.target.id === '' ? event.target.alt : event.target.id
    localStorage.setItem('UserType', JSON.stringify(userRole))

    if (userRole === 'Coordinator') {
      instance.loginRedirect(loginRequest)
    } else if (userRole === 'Client') {
      instance.loginRedirect(b2cPolicies.authorities.clientFlow)
    } else if (userRole === 'Practitioner') {
      instance.loginRedirect(b2cPolicies.authorities.signUpSignInPractitioner)
    }
  }

  return (
    <div style = {{ height: '96vh' }} className="Landing_Section">
      <div className="Main_HeaderSection">
        <div className="HeaderSection">
          <img src={vector} alt="" className="Header" />
          <img className="logo" src={logoImg}></img>
        </div>
        <div className="Section">
          <div className="Section1">
            <img src={VRLady} className="VRLady" />
          </div>
          <div className="Section2">
            <HomeCard
              className="cardHome"
              data={cardData}
              onButtonClick={onLoginCall}
            />
            <div className="FooterSection">
              <div className="courage_section">COURAGE</div>
              <div className="Termss_Condition">
                <div>
                  By clicking on above you accept our
                  <a
                    href="https://vitalstartdev.blob.core.windows.net/vitalstartdev/TermsConditions.html"
                    target="_blank"
                    rel="noreferrer"
                  >
                    {' '}
                    Terms & Conditions
                  </a>{' '}
                  and{' '}
                  <a
                    href="https://vitalstartdev.blob.core.windows.net/vitalstartdev/PrivacyPolicy.html"
                    target="_blank"
                    rel="noreferrer"
                  >
                    {' '}
                    Privacy Policy
                  </a>
                </div>
                <div className="Terms_Condition">
                  Don’t have an account?
                  <a
                    href="https://vitalstarthealth.com/register/"
                    target="_blank"
                    rel="noreferrer"
                  >
                    {' '}
                    Register{' '}
                  </a>
                </div>
                <input
                  id="hidenData"
                  type="hidden"
                  value={`isDesktop :${isDesktop} - isMobile: ${isMobile} - Is iPhone: ${isIOS} - Is MobileSafary:${isMobileSafari} - osName :${osName} - isTablet :${isTablet} - isMobileOnly :${isMobileOnly} - Device Details: ${window.navigator.userAgent} - Mobile Model:${mobileModel}`}
                />
                {config.APP_ENV_NAME === 'CheckHiddenData' && (
                  <>
                    <center> Mobile Model11:{mobileModel}</center>
                    <center>
                      Device Details: {window.navigator.userAgent}{' '}
                    </center>
                    <center>{`isMobile Check: ${isMobile}`}</center>
                    <center>{`Is iPhone: ${isIOS}`}</center>
                    <center>{`Is MobileSafary:${isMobileSafari}`}</center>
                    <center> {`osName :${osName}`}</center>
                    <center> {`isTablet :${isTablet}`}</center>
                    <center> {`isDesktop :${isDesktop}`}</center>
                    <center> {`isMobileOnly :${isMobileOnly}`}</center>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
export default Landing
