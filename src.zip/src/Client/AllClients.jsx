import React from 'react'
import '../Home/Landing.css'
// import { useMsal } from '@azure/msal-react'
import PropTypes from 'prop-types'

import ClientDetails from '../Cards/ClientDetails'

function AllClients (props) {
  // const { instance } = useMsal();

  return (
        <>
            <ClientDetails className='cardHome' data={props.cardData} pageNo={props.pageNo} pageCount={props.pageCount} handlePageChange={props.handlePageChange} handleClientProfile={props.handleClientProfile} />
        </>
  )
}

export default AllClients

AllClients.propTypes = {
  pageNo: PropTypes.number,
  pageCount: PropTypes.number,
  cardData: PropTypes.array,
  handlePageChange: PropTypes.func.isRequired,
  handleClientProfile: PropTypes.func.isRequired
}
