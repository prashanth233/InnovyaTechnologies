/* eslint-disable multiline-ternary */
import Card from '@mui/material/Card'
// import CardContent from '@mui/material/CardContent'
import { CardActionArea, Avatar, Grid, Stack, Badge } from '@mui/material'
import Typography from '@mui/material/Typography'
import React from 'react'
import { Image } from 'react-bootstrap'
import PaginationControlled from '../components/PaginationControlled'
import phoneImg from '../Assets/phoneIcon.png'
import { NoRecordFound } from '../CommonData/WorkInProgress'
import GreenRound from '../Assets/GreenRound.png'
import { styled } from '@mui/material/styles'
import { getFormatedDateFromString } from '../CommonData/CommonFunction'
import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import PropTypes from 'prop-types'

export default function ScheduleAppointmentCard (props) {
  const SmallAvatar = styled(Avatar)(({ theme }) => ({
    left: -20,
    top: -40,
    width: 25,
    height: 25,
    border: '1px solid green' // ${theme.palette.background.paper}
  }))

  return (
        <>
            {
                props.isPractitioner && (
                    <div style={{ marginTop: '45px', color: '#6A6A6A', fontFamily: 'Roboto, light', fontSize: '18px' }}>
              Select Practitioner *
            </div>
                )
            }

            <Grid
                container
                spacing={3}
                direction="row"
            // marginLeft="10px"
            >
                {props.cardData && props.cardData.length === 0 &&
                    <NoRecordFound />
                }
                {props.cardData && props.cardData.map(elem => (
                    <Grid item key={props.cardData.indexOf(elem)}>
                        {
                            (props.selectedUser === elem.id)
                              ? (
                                <Badge
                                    overlap="circular"
                                    anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
                                    badgeContent={
                                        <SmallAvatar src={GreenRound} />
                                    }
                                >
                                    <Card id={props.cardData.indexOf(elem)} variant="outlined" sx={{ width: 216, height: 280, backgroundColor: '#F0FFFB', border: '1px solid #EEEEEE' }} >
                                    {/* <CardActionArea id={props.cardData.indexOf(elem)}> */}
                                    <CardActionArea id={props.cardData.indexOf(elem)} name={props.cardData.indexOf(elem)} onClick={props.handleCardSelect}>
                                        <div>
                                            <div id={props.cardData.indexOf(elem)} style={{ display: 'flex', justifyContent: 'center', padding: '15px' }}>
                                                <Avatar
                                                    src={elem.photoId === '' ? ProfilePlaceholder : elem.photoId}
                                                    alt={props.cardData.indexOf(elem)}
                                                    onClick={props.handleCardSelect}
                                                    sx={{ width: 180, height: 180, justifyContent: 'center', alignItems: 'center' }}
                                                />
                                            </div>

                                            <div id={props.cardData.indexOf(elem)} style={{ fontFamily: 'Roboto', fontSize: '16px', textAlign: 'center', color: '#139ED7', paddingTop: '10px' }}>
                                                <Typography id={props.cardData.indexOf(elem)} gutterBottom>
                                                    {elem.userName}
                                                </Typography>
                                                {props.isClient ? (
                                                    <Typography >
                                                        <p id={props.cardData.indexOf(elem)} style={{ fontSize: '12px', color: '#9E9E9E' }}>DOB  <span id={props.cardData.indexOf(elem)} style={{ fontSize: '15px', color: '#2D2D34', marginLeft: '10px' }}>{getFormatedDateFromString(elem.dob)}</span> </p>
                                                    </Typography>
                                                )
                                                  : (
                                                        <Typography id={props.cardData.indexOf(elem)}>
                                                            {/* <Row id={props.cardData.indexOf(elem)} className="justify-content-center">
                                                                <Col md='auto'> */}
                                                            <Image id={props.cardData.indexOf(elem)} style={{ width: '18px', height: '18px' }} src={phoneImg} />
                                                            <label id={props.cardData.indexOf(elem)} variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto', fontSize: '16px', color: '#6A6A6A' }}>{elem.mobileNo}</label>
                                                            {/* </Col>
                                                            </Row> */}
                                                        </Typography>
                                                    )
                                                }
                                            </div>
                                        </div>
                                    </CardActionArea>
                                    {/* </CardActionArea> */}

                                </Card>
                                </Badge>
                                ) : (
                                <Card id={props.cardData.indexOf(elem)} variant="outlined" sx={{ width: 216, height: 280, border: '1px solid #EEEEEE' }} >
                                    {/* <CardActionArea id={props.cardData.indexOf(elem)}> */}
                                    <CardActionArea id={props.cardData.indexOf(elem)} name={props.cardData.indexOf(elem)} onClick={props.handleCardSelect}>
                                        <div>
                                            <div id={props.cardData.indexOf(elem)} style={{ display: 'flex', justifyContent: 'center', padding: '15px' }}>
                                                <Avatar
                                                    src={elem.photoId === '' ? ProfilePlaceholder : elem.photoId}
                                                    alt={props.cardData.indexOf(elem)}
                                                    onClick={props.handleCardSelect}
                                                    sx={{ width: 180, height: 180, justifyContent: 'center', alignItems: 'center' }}
                                                />
                                            </div>

                                            <div id={props.cardData.indexOf(elem)} style={{ fontFamily: 'Roboto', fontSize: '16px', textAlign: 'center', color: '#139ED7', paddingTop: '10px' }}>
                                                <Typography id={props.cardData.indexOf(elem)} gutterBottom>
                                                    {elem.userName}
                                                </Typography>
                                                {props.isClient ? (
                                                    <Typography >
                                                        <p id={props.cardData.indexOf(elem)} style={{ fontSize: '12px', color: '#9E9E9E' }}>DOB  <span id={props.cardData.indexOf(elem)} style={{ fontSize: '15px', color: '#2D2D34', marginLeft: '10px' }}>{getFormatedDateFromString(elem.dob)}</span> </p>
                                                    </Typography>
                                                )
                                                  : (
                                                        <Typography id={props.cardData.indexOf(elem)}>
                                                            {/* <Row id={props.cardData.indexOf(elem)} className="justify-content-center">
                                                                <Col md='auto'> */}
                                                            <Image id={props.cardData.indexOf(elem)} style={{ width: '18px', height: '18px' }} src={phoneImg} />
                                                            <label id={props.cardData.indexOf(elem)} variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto', fontSize: '16px', color: '#6A6A6A' }}>{elem.mobileNo}</label>
                                                            {/* </Col>
                                                            </Row> */}
                                                        </Typography>
                                                    )
                                                }
                                            </div>
                                        </div>
                                    </CardActionArea>
                                    {/* </CardActionArea> */}

                                </Card>
                                )}

                    </Grid>
                ))}
            </Grid>
            <Stack spacing={2}>
                <PaginationControlled pageNo={props.pageNo} pageCount={props.pageCount} handlePageChange={props.handlePageChange} />
            </Stack>
        </>
  )
}

ScheduleAppointmentCard.propTypes = {
  selectedUser: PropTypes.string,
  cardData: PropTypes.array,
  isClient: PropTypes.bool,
  isPractitioner: PropTypes.bool,
  pageNo: PropTypes.number,
  pageCount: PropTypes.number,
  handlePageChange: PropTypes.func.isRequired,
  handleCardSelect: PropTypes.func.isRequired
}
