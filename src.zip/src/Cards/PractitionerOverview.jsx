import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import React from 'react'
// import CardActions from '@mui/material/CardActions'
// import Typography from '@mui/material/Typography'

// import FilterListIcon from '@mui/icons-material/FilterList'
// import { Divider, Grid } from '@mui/material'
import { Grid } from '@mui/material'

import { Image } from 'react-bootstrap'
import { NoRecordFound } from '../CommonData/WorkInProgress'
import '../styles/App.css'

import PropTypes from 'prop-types'

export default function PractitionerOverview (props) {
  return (
    <div>
      <Grid
        container
        spacing={3}
        direction="row"
        paddingLeft="35px"
        // sx={{ pt: 0 }}
      >
        {props.cardData && props.cardData.length === 0 && <NoRecordFound />}
        {props.cardData &&
          props.cardData.map((elem) => (
            <Grid item key={props.cardData.indexOf(elem)}>
              <Card
                variant="outlined"
                sx={{
                  pt: 0,
                  width: 280,
                  height: 140,
                  border: '1px solid #EEEEEE',
                  backgroundColor: elem.bgColor
                }}
              >
                <CardContent>
                  <Image
                    style={{ marginTop: '-3px', width: '24px', height: '24px' }}
                    src={elem.img}
                  />
                  <label
                    variant="info"
                    style={{
                      marginLeft: '5px',
                      fontFamily: 'Roboto, Light',
                      fontSize: '16px',
                      color: '#2D2D34'
                    }}
                  >
                    {elem.title}
                  </label>
                  <div
                    style={{ borderBottom: '2px solid #EEEEEE', height: 45 }}
                  >
                    <p
                      style={{
                        fontFamily: 'Roboto, Light',
                        fontSize: '30px',
                        color: '#F24B5D',
                        marginLeft: '22px'
                      }}
                    >
                      {elem.value}{' '}
                      <span
                        style={{
                          fontFamily: 'Roboto, Regular',
                          fontSize: '12px',
                          color: '#44546A'
                        }}
                      >
                        {elem.subTitle}
                      </span>{' '}
                    </p>
                  </div>
                  {/* <Divider /> */}
                  <div style={{ textAlign: 'right' }}>
                    <button
                      id={props.cardData.indexOf(elem)}
                      style={{
                        backgroundColor: elem.bgColor,
                        color: '#F24B5D',
                        border: 'none',
                        fontFamily: 'Roboto, Regular',
                        fontSize: '14px',
                        marginLeft: '15px',
                        height: 35
                      }}
                      onClick={props.viewAllHandler}
                    >
                      VIEW ALL
                    </button>
                  </div>
                </CardContent>
              </Card>
            </Grid>
          ))}
      </Grid>
    </div>
  )
}

PractitionerOverview.propTypes = {
  cardData: PropTypes.array,
  viewAllHandler: PropTypes.func
}
