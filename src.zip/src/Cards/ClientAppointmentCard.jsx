import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import React from 'react'
import Typography from '@mui/material/Typography'
import { Avatar, Grid } from '@mui/material'
import { Col, Row, Image } from 'react-bootstrap'
import phoneImg from '../Assets/phoneIcon.png'
import { getFormatedDateFromString } from '../CommonData/CommonFunction'
import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import PropTypes from 'prop-types'

export const ClientAppointmentCard = ({ appointmentData }) => {
//   console.log('appointmentData Elem data::', appointmentData)

  return (
        <>
            <Grid
                container
                // spacing={8}
                direction="row"
                marginLeft="2.2vw"
                // justifyContent="center"
                // alignItems="center"
            >
                {appointmentData && appointmentData.map(elem => (
                    <Grid item key={appointmentData.indexOf(elem)} >
                        <div style={{ color: '#6A6A6A', fontFamily: 'Roboto', fontSize: '18px' }}>{appointmentData.indexOf(elem) === 0 ? 'Client' : 'Practitioner'}</div>
                        <Card id={appointmentData.indexOf(elem)} variant="outlined" sx={{ width: 216, height: 280, border: '1px solid #EEEEEE' }} >

                            <div style={{ display: 'flex', justifyContent: 'center', marginTop: '15px' }}>
                                <Avatar
                                    src={elem.photoId === '' ? ProfilePlaceholder : elem.photoId}
                                    sx={{ width: 180, height: 180, justifyContent: 'center', alignItems: 'center' }}
                                />
                            </div>
                            <CardContent spacing={1}>
                                <div style={{ fontFamily: 'Roboto', fontSize: '16px', textAlign: 'center', color: '#139ED7' }}>
                                    <Typography gutterBottom>
                                        {elem.userName}
                                    </Typography>
                                    {appointmentData.indexOf(elem) === 0
                                      ? (
                                        <Typography >
                                            <p style={{ fontSize: '12px', color: '#9E9E9E' }}>DOB  <span style={{ fontSize: '15px', color: '#2D2D34', marginLeft: '10px' }}>{getFormatedDateFromString(elem.dob)}</span> </p>
                                        </Typography>
                                        )
                                      : (
                                            <Typography>
                                                <Row className="justify-content-center">
                                                    <Col md='auto'>
                                                        <Image style={{ width: '18px', height: '18px' }} src={phoneImg} />
                                                        <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto', fontSize: '16px', color: '#6A6A6A' }}>{elem.mobileNo}</label>
                                                    </Col>
                                                </Row>
                                            </Typography>
                                        )
                                    }
                                </div>
                            </CardContent>
                        </Card>
                    </Grid>
                ))}
            </Grid>
        </>
  )
}

ClientAppointmentCard.propTypes = {
  appointmentData: PropTypes.object
}
