import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import React from 'react'
// import CardActions from '@mui/material/CardActions'
import Typography from '@mui/material/Typography'
// import { useHistory } from "react-router-dom";
// import FilterListIcon from '@mui/icons-material/FilterList'
import { Avatar, Grid, Stack } from '@mui/material'
import { Col, Row, Image } from 'react-bootstrap'
import PaginationControlled from '../components/PaginationControlled'
import phoneImg from '../Assets/phoneIcon.png'
import { NoRecordFound } from '../CommonData/WorkInProgress'
import '../styles/App.css'
import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import PropTypes from 'prop-types'

export default function PractitionerDetails (props) {
  return (
        <div>
            <Grid
                container
                spacing={2}
                direction="row"
                marginLeft="10px"
                sx={{ pt: 0 }}
                // marginLeft="40px"
                // marginRight="40px"
                // justifyContent="center"
                // alignItems="center"
            >
                {props.cardData && props.cardData.length === 0 &&
                    <NoRecordFound />
                }
                {props.cardData && props.cardData.map(elem => (
                    <Grid item key={props.cardData.indexOf(elem)}>
                        <Card variant="outlined" sx={{ pt: 0, width: 216, border: '1px solid #EEEEEE' }}>

                            <div style={{ display: 'flex', justifyContent: 'center', marginTop: '15px' }}>
                                <Avatar
                                    src={elem.photoId === '' ? ProfilePlaceholder : elem.photoId}
                                    sx={{ width: 180, height: 180, justifyContent: 'center', alignItems: 'center' }}
                                />
                            </div>
                            <CardContent spacing={1}>
                                <div style={{ fontFamily: 'Roboto', fontSize: '16px', textAlign: 'center', color: '#139ED7' }}>
                                    <Typography gutterBottom>
                                        {elem.userName}
                                    </Typography>
                                    <Typography>
                                        <Row className="justify-content-center">
                                            <Col md='auto'>
                                                <Image style={{ width: '18px', height: '18px' }} src={phoneImg} />
                                                <label variant="info" style={{ marginLeft: '5px', fontFamily: 'Roboto', fontSize: '16px', color: '#6A6A6A' }}>{elem.mobileNo}</label>
                                            </Col>
                                        </Row>
                                        {/* <img style={{  width: '10px', height: '10px'}} src={calImg} /> <InputLabel>{elem.phone}</InputLabel> */}
                                    </Typography>
                                </div>
                            </CardContent>
                        </Card>
                    </Grid>
                ))}
            </Grid>
            <Stack spacing={2}>
                {props.cardData && props.cardData.length
                  ? (
                    <PaginationControlled pageNo={props.pageNo} pageCount={props.pageCount} handlePageChange={props.handlePageChange} />
                    )
                  : null }
            </Stack>
        </div>
  )
}

PractitionerDetails.propTypes = {
  cardData: PropTypes.array,
  pageNo: PropTypes.number,
  pageCount: PropTypes.number,
  handlePageChange: PropTypes.func.isRequired
}
