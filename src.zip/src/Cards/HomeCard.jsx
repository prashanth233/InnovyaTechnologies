import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import Typography from '@mui/material/Typography'
import { CardActionArea, Avatar, Grid } from '@mui/material'
import React from 'react'
import PropTypes from 'prop-types'

export default function HomeCard (props) {
  return (
    <Grid
      container
      spacing={10}
      direction="row"
      justifyContent="center"
      alignItems="center"
    >
      {props.data.map(elem => (
        <Grid item key={props.data.indexOf(elem)}>
          <Card style={{ border: 'none', width: '170px', height: '270px', boxShadow: '0px 4px 8px 0px #00000026', position: 'relative' }} id={props.data.indexOf(elem)} onClick={props.onButtonClick} sx={{ borderRadius: '60px' }} >
            <CardActionArea id={elem.name}>
              <Avatar
                src={elem.img}
                sx={{ width: 230, height: 230, marginTop: 2 }}
                alt={elem.name}
              />
              <CardContent id={elem.name} sx={{ justifyContent: 'center', alignItems: 'center' }}>
                <Typography id={elem.name} variant="h5" component="div" align='center'>
                  <button
                    id={elem.name}
                    size="small"
                    style={{ backgroundColor: 'white', position: 'relative', bottom: '20px', lineheight: '30px', fontWeight: '500', border: 'none', color: '#233451', fontSize: '20px', fontFamily: 'Roboto, Regular' }}
                    onClick={props.onButtonClick}
                  >
                    {elem.name}
                  </button>
                </Typography>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>
      ))}
    </Grid>
  )
}

HomeCard.propTypes = {
  data: PropTypes.array,
  onButtonClick: PropTypes.func.isRequired
}
