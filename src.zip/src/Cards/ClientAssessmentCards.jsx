import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import React from 'react'
import { Avatar, Grid } from '@mui/material'
import '../styles/App.css'
// import { Image } from 'react-bootstrap'
// import calImg from '../Assets/Calendar.png'
// import phoneImg from '../Assets/phoneIcon.png'
// import { getFormatedDateFromString } from '../CommonData/CommonFunction'
// import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import { styled } from '@mui/material/styles'
import Tooltip, { tooltipClasses } from '@mui/material/Tooltip'
import PropTypes from 'prop-types'
import { NoRecordFound } from '../CommonData/WorkInProgress'
import { getDateWithFormat } from '../CommonData/CommonFunction'
import { cardHeight, fourteenPx, fourteenPx1 } from '../CommonData/Data'

export const ClientAssessmentCards = ({ assessmentsData }) => {
  const completeFormAction = (e) => {
    const id = e.target.id
    // console.log('selected id::', id)
    // test comment
    navigator.clipboard.writeText(`${assessmentsData[id].assessmentNo}`)
    window.open(`${assessmentsData[id].link}`, '_blank')
  }
  const BootstrapTooltip = styled(({ className, ...props }) => (
    <Tooltip {...props} arrow classes={{ popper: className }} />
  ))(({ theme }) => ({
    [`& .${tooltipClasses.arrow}`]: {
      color: theme.palette.common.black
    },
    [`& .${tooltipClasses.tooltip}`]: {
      backgroundColor: theme.palette.common.black
    }
  }))

  return (
        <div style={{ backgroundColor: 'white', minHeight: '70%' }}>
            <Grid
                container
                spacing={3}
                direction="row"
                paddingLeft="15px"
                marginTop='0px'
            // sx={{ pt: 0 }}
            >
                {assessmentsData && assessmentsData.length === 0 &&
                    <NoRecordFound />
                }
                {assessmentsData && assessmentsData.map(elem => (
                    <Grid item key={assessmentsData.indexOf(elem)}>
                        <Card variant="outlined" sx={{ pt: 0, width: 255, height: cardHeight, border: 'none', borderTop: '3px  solid', borderColor: elem.status === 'ASSIGN' ? '#F3892C' : '#4C927E', backgroundColor: '#FFF8E5', paddingBottom: '10px' }}>
                            <CardContent>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <div className='wrapTextForCard'>
                                        {/* <Image style={{ marginTop: '-3px', width: '24px', height: '24px' }} src={calImg} /> */}
                                        <BootstrapTooltip title={elem.name} enterTouchDelay={0}>
                                        <label variant="info" style={{ width: '10rem', fontFamily: 'Roboto, Light', fontSize: fourteenPx1, color: '#2D2D34' }}>{elem.name}</label>
                                        </BootstrapTooltip>
                                    </div>
                                    <div>
                                        <div style={{ marginLeft: '5px', fontFamily: 'Roboto, Regular', fontSize: '9px', color: '#2D2D34', textAlign: 'right' }}>Due by</div>
                                        <div style={{ marginLeft: '5px', fontFamily: 'Roboto, Regular', fontSize: '11px', color: '#2D2D34' }}>{getDateWithFormat(new Date(elem.dueDate), 'DD-MMM-YY')}</div>
                                    </div>
                                </div>
                                <div className='wrapTextForCard'>
                                    <BootstrapTooltip title={elem.description} enterTouchDelay={0}>
                                    <label variant="info" style={{ width: '12.5rem', fontFamily: 'Roboto, Light', fontSize: fourteenPx1, color: '#2D2D34' }}>{elem.description}</label>
                                    </BootstrapTooltip>

                                </div>
                                <div style={{ borderBottom: '1px solid #EEEEEE' }}>
                                    <p style={{ fontFamily: 'Roboto, Light', fontSize: fourteenPx1, color: '#2D2D34' }}>{`Assessment No. ${elem.assessmentNo}`} </p>
                                </div>
                                {/* <Divider /> */}
                                <div style={{ textAlign: 'right' }}>
                                    {
                                        elem.status === 'ASSIGN'
                                          ? (
                                                <div>
                                                    <button id={assessmentsData.indexOf(elem)} style={{ backgroundColor: '#FFF8E5', color: '#F24B5D', border: 'none', fontFamily: 'Roboto, Regular', fontSize: fourteenPx, margin: '10px 0px -60px 15px' }} onClick={completeFormAction}>
                                                        COMPLETE THE FORM
                                                    </button>
                                                </div>
                                            )
                                          : (
                                                <div style={{ display: 'flex', float: 'right', color: '#4C927E', paddingTop: '8px' }}>
                                                    <Avatar sx={{ marginRight: 1, width: '24px', height: '24px', border: '5px double white', bgcolor: '#4C927E', fontSize: 10 }}>{'✔'}</Avatar> <span>  </span>
                                                    {'Done'}
                                                </div>
                                            )
                                    }

                                </div>
                            </CardContent>
                        </Card>
                    </Grid>
                ))}
            </Grid>
            <br />
        </div>
  )
}

ClientAssessmentCards.propTypes = {
  assessmentsData: PropTypes.array
}
