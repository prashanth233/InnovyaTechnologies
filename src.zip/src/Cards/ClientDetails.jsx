import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import React from 'react'
// import CardActions from '@mui/material/CardActions'
import Typography from '@mui/material/Typography'
import video from '../Assets/video.png'
import greenRoundImg from '../Assets/GreenRound.png'
import calImg from '../Assets/Calendar.png'

import { useHistory } from 'react-router-dom'
import { getFormatedDateFromString } from '../CommonData/CommonFunction'

import { Avatar, Grid, Stack } from '@mui/material'
import { Col, Row, Image } from 'react-bootstrap'
import PaginationControlled from '../components/PaginationControlled'
import { NoRecordFound } from '../CommonData/WorkInProgress'
import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import PropTypes from 'prop-types'

export default function ClientDetails (props) {
  const history = useHistory()

  return (
    <>
      <Grid
        container
        spacing={6}
        direction="row"
        // marginLeft="10px"
        // marginRight="40px"
        // justifyContent="center"
        // alignItems="center"
      >
        {props.data && props.data.length === 0 && <NoRecordFound />}
        {props.data &&
          props.data.map((elem) => (
            <Grid item key={props.data.indexOf(elem)}>
              <Card
                variant="outlined"
                sx={{
                  mt: -5,
                  width: 250,
                  minHeight: 390,
                  border: '1px solid #EEEEEE'
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'center',
                    paddingTop: '15px'
                  }}
                >
                  <Avatar
                    // src={elem.img}
                    src={
                      elem.photoId === '' ? ProfilePlaceholder : elem.photoId
                    }
                    sx={{
                      width: 130,
                      height: 130,
                      justifyContent: 'center',
                      alignItems: 'center',
                      objectFit: 'scale-down'
                    }}
                  />
                </div>
                <CardContent>
                  <div
                    style={{
                      fontFamily: 'Roboto',
                      fontSize: '16px',
                      textAlign: 'center',
                      color: '#139ED7'
                    }}
                  >
                    {elem.userName}
                    <Typography>
                      <p style={{ fontSize: '11px', color: '#9E9E9E' }}>
                        Age{' '}
                        <span
                          style={{
                            fontSize: '14px',
                            color: '#2D2D34',
                            marginLeft: '10px'
                          }}
                        >{`${elem.age}y`}</span>{' '}
                      </p>
                    </Typography>
                    <Typography>
                      <p style={{ fontSize: '11px', color: '#9E9E9E' }}>
                        DOB{' '}
                        <span
                          style={{
                            fontSize: '14px',
                            color: '#2D2D34',
                            marginLeft: '10px'
                          }}
                        >
                          {getFormatedDateFromString(elem.dob)}
                        </span>{' '}
                      </p>
                    </Typography>
                    <Typography>
                      <p style={{ fontSize: '11px', color: '#9E9E9E' }}>
                        MRN{' '}
                        <span
                          style={{
                            fontSize: '14px',
                            color: '#2D2D34',
                            marginLeft: '10px'
                          }}
                        >
                          {elem.mrnNo}
                        </span>{' '}
                      </p>
                    </Typography>
                  </div>
                  {/* <Row>
                                    <Col style={{backgroundColor:'yellow', width:50}}> */}
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-around',
                      height: '20px'
                    }}
                  >
                    {/* <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}> */}
                    <div>
                      <Image
                        style={{
                          marginTop: '-9px',
                          width: '18px',
                          height: '18px'
                        }}
                        src={calImg}
                      />
                      <label
                        variant="info"
                        style={{
                          marginLeft: '5px',
                          fontFamily: 'Roboto',
                          fontSize: '20px',
                          color: '#F24B5D'
                        }}
                      >
                        {elem.appointment}
                      </label>
                    </div>
                    {/* </Col>
                                    <Col > */}
                    <div>
                      <Image
                        style={{
                          marginTop: '-6px',
                          width: '24px',
                          height: '24px'
                        }}
                        src={video}
                      />
                      <label
                        variant="info"
                        style={{
                          marginLeft: '5px',
                          fontFamily: 'Roboto',
                          fontSize: '20px',
                          color: '#F24B5D'
                        }}
                      >
                        {elem.videos}
                      </label>
                    </div>
                    {/* </Col>
                                    <Col> */}
                    <div>
                      <Image
                        style={{
                          marginTop: '-6px',
                          width: '18px',
                          height: '18px'
                        }}
                        src={greenRoundImg}
                        rounded
                      />
                      <label
                        variant="info"
                        style={{
                          marginLeft: '5px',
                          fontFamily: 'Roboto',
                          fontSize: '20px',
                          color: '#F24B5D'
                        }}
                      >
                        {elem.assessments}
                      </label>
                    </div>
                  </div>
                  {/* </Col>
                                </Row> */}
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      height: 20
                    }}
                  >
                    <div>
                      <label
                        variant="info"
                        style={{
                          fontFamily: 'Roboto',
                          fontSize: '12px',
                          color: '#9E9E9E'
                        }}
                      >
                        Appointments
                      </label>
                    </div>

                    <div>
                      <label
                        variant="info"
                        style={{
                          fontFamily: 'Roboto',
                          fontSize: '12px',
                          color: '#9E9E9E'
                        }}
                      >
                        Videos
                      </label>
                    </div>

                    <div>
                      <label
                        variant="info"
                        style={{
                          fontFamily: 'Roboto',
                          fontSize: '12px',
                          color: '#9E9E9E'
                        }}
                      >
                        Assessments
                      </label>
                    </div>
                  </div>
                </CardContent>
                <Row
                  style={{ display: 'flex', justifyContent: 'space-evenly' }}
                >
                  <Col
                    style={{
                      backgroundColor: '#F24B5D',
                      color: 'white',
                      minHeight: '40px'
                    }}
                  >
                    <button
                      style={{
                        backgroundColor: '#F24B5D',
                        color: 'white',
                        border: 'none',
                        fontFamily: 'Roboto',
                        fontSize: '14px',
                        marginLeft: '15px',
                        height: '40px'
                      }}
                      onClick={() => {
                        history.push('/appointments')
                        window.location.reload('false')
                      }}
                    >
                      APPOINTMENT
                    </button>
                  </Col>
                  <Col
                    style={{
                      backgroundColor: 'white',
                      display: 'flex',
                      justifyContent: 'center',
                      borderTop: '0.5px solid #9E9E9E',
                      height: '40px'
                    }}
                  >
                    <button
                      style={{
                        backgroundColor: 'white',
                        color: '#F24B5D',
                        border: 'none',
                        fontFamily: 'Roboto',
                        fontSize: '14px',
                        marginRight: '15px'
                      }}
                      id={props.data.indexOf(elem)}
                      onClick={props.handleClientProfile}
                    >
                      PROFILE
                    </button>
                  </Col>
                </Row>
              </Card>
            </Grid>
          ))}
      </Grid>
      <Stack spacing={2}>
        {props.data && props.data.length
          ? (
          <PaginationControlled
            pageNo={props.pageNo}
            pageCount={props.pageCount}
            handlePageChange={props.handlePageChange}
          />
            )
          : null}
      </Stack>
    </>
  )
}

ClientDetails.propTypes = {
  data: PropTypes.array,
  pageNo: PropTypes.number,
  pageCount: PropTypes.number,
  handlePageChange: PropTypes.func.isRequired,
  handleClientProfile: PropTypes.func.isRequired
}
