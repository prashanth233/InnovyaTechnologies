import moment from 'moment'

const currentUser = JSON.parse(localStorage.getItem('currentUser'))
// const userData = JSON.parse(localStorage.getItem('UserData'))

const generateRandomNumber = () => {
  const minm = 100000
  const maxm = 999999
  const finalNum = Math.floor(Math
    .random() * (maxm - minm + 1)) + minm
  let finalNumStr = '' + finalNum
  finalNumStr = finalNumStr.match(/.{1,2}/g).join('-')
  // var new_value = parts.join("-");
  // console.log("Final MRN:-",finalNumStr);
  return finalNumStr
}

export const clientInitialData = {
  firstName: '',
  middleName: '',
  lastName: '',
  email: '',
  dob: '',
  mobileNo: '',
  gender: '',
  photoId: '',
  race: '',
  ethnicity: '',
  babyDOB: '',
  mrnNo: 'VS' + generateRandomNumber(),
  practiceId: '',
  createdBy: '',
  insurenceName: '',
  insurenceId: '',
  insurencePlan: '',
  referralCode: '',
  hippaId: '',
  treatmentConsentId: '',
  emergencyFirstName: '',
  emergencyLastName: '',
  emergencyMobileNo: '',
  emergencyRelationship: '',
  referralName: '',
  referralPracticeName: '',
  referralEmail: '',
  referralMobileNo: '',
  referralWebsite: '',
  referralNPI: '',
  password: 'VS' + generateRandomNumber()
}

export const practitionerInitialData = {
  firstName: '',
  middleName: '',
  lastName: '',
  email: '',
  mobileNo: '',
  practiceId: currentUser && currentUser.extension_PracticeName,
  gender: '',
  practitionerPracticeName: '',
  photoId: '',
  insurenceName: '',
  noInsurencePlan: false,
  consultationRate: '',
  tenantId: '',
  createdBy: `${currentUser && currentUser.extension_FName} ${currentUser && currentUser.extension_LastName}`,
  specialties: '',
  services: '',
  password: 'testPass',
  npi: ''
}

export const TENANTNAME = currentUser && currentUser.extension_Organization
export const PRACTICENAME = currentUser && currentUser.extension_PracticeName

export const appointMentInitialData = {
  clientId: '',
  practitionerId: '',
  meetingLink: '',
  meetingDateTime: '',
  coordinatorId: `${currentUser && currentUser.sub}`,
  tenantId: TENANTNAME,
  status: 'Scheduled',
  createdBy: `${currentUser && currentUser.extension_FirstName} ${currentUser && currentUser.extension_LastName}`,
  createdDate: moment(new Date()).format('yyyy-MM-DDTHH:mm:ss.SSS'),
  updatedDate: moment(new Date()).format('yyyy-MM-DDTHH:mm:ss.SSS'),
  updatedBy: `${currentUser && currentUser.extension_FirstName} ${currentUser && currentUser.extension_LastName}`
}
