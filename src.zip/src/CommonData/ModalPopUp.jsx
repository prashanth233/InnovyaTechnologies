import React, { useEffect } from 'react'
import { Modal, Button } from 'react-bootstrap'
import Loader from '../pages/Loader'
import { AssignmentsData } from '../pages/AssignmentsData'
import calImg from '../Assets/Calendar.png'
import moment from 'moment'
import '../styles/App.css'

import Dialog from '@mui/material/Dialog'
import DialogActions from '@mui/material/DialogActions'
import DialogContent from '@mui/material/DialogContent'
import DialogContentText from '@mui/material/DialogContentText'
import DialogTitle from '@mui/material/DialogTitle'
import { Divider } from '@mui/material'
import PropTypes from 'prop-types'
import { AZVideoPlayer } from '../pages/AZVideoPlayer'

// For Azure media player
import { isDesktop, isMobileOnly, isTablet } from 'react-device-detect'
import { ClientAssessmentsChart } from '../pages/ClientAssessmentsChart'

export const ModalPopUp = ({ handleModalPopUp, show, header, messageBody }) => {
  return (
    <>
      <Modal
        show={show}
        onHide={handleModalPopUp}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>{header}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {messageBody}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" style={{ fontFamily: 'Roboto, Regular', color: 'white', border: 'none', backgroundColor: '#F24B5D' }} onClick={handleModalPopUp} >OK</Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}
ModalPopUp.propTypes = {
  header: PropTypes.string,
  messageBody: PropTypes.string,
  show: PropTypes.bool,
  handleModalPopUp: PropTypes.func.isRequired
}

export const JoinModalPopUp = ({ handleModalPopUp, show, message }) => {
  return (
    <>
      <Modal
        show={show}
        onHide={handleModalPopUp}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Meeting Status</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {message}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" style={{ fontFamily: 'Roboto, Regular', color: 'white', border: 'none', backgroundColor: '#F24B5D' }} onClick={handleModalPopUp} >OK</Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}
JoinModalPopUp.propTypes = {
  message: PropTypes.string,
  show: PropTypes.bool,
  handleModalPopUp: PropTypes.func.isRequired
}

export const AskModalPopUp = ({ handleAskModalPopUp, show }) => {
  return (
    <>
      <Modal
        show={show}
        onHide={handleAskModalPopUp}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Cancel Appointment</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Do you really want to cancel the selected appointment ?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" id="yes" style={{ fontFamily: 'Roboto, Regular', color: 'white', border: 'none', backgroundColor: '#F24B5D' }} onClick={handleAskModalPopUp} >YES</Button>
          <Button variant="primary" id="no" style={{ fontFamily: 'Roboto, Regular', color: 'white', border: 'none', backgroundColor: '#F24B5D' }} onClick={handleAskModalPopUp} >NO</Button>

        </Modal.Footer>
      </Modal>
    </>
  )
}
AskModalPopUp.propTypes = {
  message: PropTypes.string,
  show: PropTypes.bool,
  handleAskModalPopUp: PropTypes.func.isRequired
}

export const LoaderModalPopUp = ({ show, message }) => {
  return (
    <>
      <Modal
        show={show}
        //   onHide={handleModalPopUp}
        backdrop="static"
        keyboard={false}
      >
        <Loader />
        <div style={{ paddingTop: '5px', textAlign: 'center', color: '#F24B5D' }}>
          {message}
        </div>
        <br />
      </Modal>
    </>
  )
}
LoaderModalPopUp.propTypes = {
  message: PropTypes.string,
  show: PropTypes.bool
}

export const AssignActivitiesAssessmentsModal = ({ show, handleModalPopUp, data, listingData, type }) => {
  const dateConst = moment(data.meetingStartDateTime).format('MMM DD, yyyy')
  const timeConst = moment(data.meetingStartDateTime).format('hh:mm A')
  const endTimeConst = moment(data.meetingEndDateTime).format('hh:mm A')

  const label1 = type === 'activities' ? 'Assign Activities - Media' : 'Assign Assessments'
  const label2 = type === 'activities' ? ` | For Appointment with  ${data.clientName} on ` : ` | For ${data.clientName}`

  useEffect(() => {
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = ''
    }
  })

  return (
    <div style={{ borderRadius: '30px' }}>
      <Dialog
        // fullWidth={type === 'activities'}
        fullWidth={true}
        maxWidth={type === 'activities' ? 'xl' : 'sm'}
        open={show}
        // onClose={handleModalPopUp}
        PaperProps={{
          style: { borderRadius: 20 }
        }}
      >
        <DialogTitle>
          <div style={{ display: 'flex' }} >
            <p style={{ fontSize: '20px', fontFamily: 'Roboto, Light', color: '#139ED7', fontWeight: 400 }}>{label1}<span style={{ fontSize: '14px', fontFamily: 'Roboto, Regular', color: '#2D2D34' }}>{label2}</span> </p>

            {
              type === 'activities' && (
                <div style={{ paddingLeft: '20px', marginTop: '5px', color: '#2D2D34', fontFamily: 'Roboto, Regular', fontSize: '14px' }}>

                  <img src={calImg} width={18}></img>
                  <span> </span>

                  {`${dateConst} | ${timeConst}-${endTimeConst}`}
                </div>
              )
            }
          </div>
        </DialogTitle>
        <Divider style={{ marginTop: '-15px' }} />
        <DialogContent>
          <DialogContentText style={{ color: '#2D2D34' }}>
            <AssignmentsData data={data} listingData={listingData} type={type} />
          </DialogContentText>

        </DialogContent>
        <DialogActions>
          <Button style={{ fontFamily: 'Roboto, Regular', color: 'white', border: 'none', backgroundColor: '#F24B5D', marginRight: 40 }} onClick={handleModalPopUp}>DONE</Button>
        </DialogActions>
      </Dialog>
    </div>
  )
}
AssignActivitiesAssessmentsModal.propTypes = {
  type: PropTypes.string,
  show: PropTypes.bool,
  listingData: PropTypes.array,
  data: PropTypes.object,
  handleModalPopUp: PropTypes.func.isRequired
}

export const AzMediaPlayerModal = ({ isVREnabled, show, videoUrlData, handleModalPopUp, showClose, handleAzurePlayerClick, rtm, title, sameSession, playerDuration }) => {
  // const handleClose = (event, reason) => {
  //   console.log('reason data::', reason)
  //   if (reason && reason === 'backdropClick') { return }
  //   handleModalPopUp()
  // }
  const isMobilePhoneCheck = !isDesktop || isMobileOnly || isTablet
  return (
    <>
      <Dialog
        // fullWidth={type === 'activities'}
        fullWidth={true}
        fullScreen={isMobilePhoneCheck}
        maxWidth='xl'
        open={show}
        // onClose={handleClose}
        // borderRadius={20}
      >
        {
          !isMobilePhoneCheck && (
<DialogTitle>
          <div style={{ display: 'flex', justifyContent: 'space-between' }} >
            <div style={{ color: '#139ED7', fontFamily: 'Roboto, Light', fontSize: '20px' }}>
              {title}
            </div>
            {
              showClose && (
                <button style={{ float: 'right', fontFamily: 'Roboto, Regular', color: 'black', border: 'none', width: '1rem', height: '1rem', backgroundColor: 'white', marginBottom: '5px' }} onClick={handleModalPopUp}>X</button>
              )
            }

          </div>
        </DialogTitle>
          )
        }
        <Divider />
        <DialogContent style={{ backgroundColor: isMobilePhoneCheck ? 'black' : 'white' }}>
          <DialogContentText>
          {
              isMobilePhoneCheck && showClose && (
                <button style={{ float: 'right', fontFamily: 'Roboto, Regular', color: 'black', border: 'none', width: '1.5rem', height: '1.5rem', backgroundColor: 'white', marginBottom: '5px' }} onClick={handleModalPopUp}>X</button>
              )
            }
            <AZVideoPlayer videoUrlData={videoUrlData} handleModalPopUp={handleModalPopUp} handleAzurePlayerClick={handleAzurePlayerClick} rtm={rtm} sameSession={sameSession} playerDuration={playerDuration} isVREnabled={isVREnabled} />
          </DialogContentText>

        </DialogContent>
      </Dialog>
    </>
  )
}
AzMediaPlayerModal.propTypes = {
  videoUrlData: PropTypes.string,
  title: PropTypes.string,
  show: PropTypes.bool,
  sameSession: PropTypes.bool,
  showClose: PropTypes.bool,
  handleAzurePlayerClick: PropTypes.func,
  handleModalPopUp: PropTypes.func,
  rtm: PropTypes.object,
  isVREnabled: PropTypes.bool,
  playerDuration: PropTypes.number
}

export const AssessmentsChartModal = ({ clientUserId, show, handleModalPopUp }) => {
  return (
    <>
      <Dialog
        // fullWidth={type === 'activities'}
        // fullWidth={true}
        // fullScreen={true}
        maxWidth='md'
        open={show}
        // onClose={handleClose}
        // borderRadius={20}
      >
        <DialogTitle>
          <div style={{ display: 'flex', float: 'right' }} >
            {/* <div style={{ color: '#139ED7', fontFamily: 'Roboto, Light', fontSize: '20px' }}>
              {title}
            </div> */}
            {
              show && (
                <Button variant="link" style={{ fontFamily: 'Roboto, Regular', color: 'black', border: 'none', width: 15, height: 15 }} onClick={handleModalPopUp}>X</Button>
              )
            }

          </div>
        </DialogTitle>
        <Divider />
        <DialogContent>
          <DialogContentText>
          <ClientAssessmentsChart clientUserId={clientUserId} comingFrom='dialog' />
          </DialogContentText>

        </DialogContent>
      </Dialog>
    </>
  )
}
AssessmentsChartModal.propTypes = {
  clientUserId: PropTypes.string,
  show: PropTypes.bool,
  handleModalPopUp: PropTypes.func
}
