/* eslint-disable react/prop-types */
import { AssignmentsCell, ActionsCell, AssessmentsCell, PatientActionsCell, AssignActionsCell, ActivitiesActionCell, AssessmentsListingCell, ActionsCellAssessments, AppointmentSummaryCell, ActivitiesStatusCell, ActivityListingHWCell, AssignAssessmentsActionsCell } from '../components/AssignmentsCell'
import Moment from 'moment'
import calImg from '../Assets/Calendar.png'
import timer from '../Assets/Timer.png'
import pracImg from '../Assets/practitioner.png'
import patImg from '../Assets/patient.png'
import coordImg from '../Assets/coordinator.png'
import React from 'react'
import '../styles/App.css'
import { isMobile } from 'react-device-detect'

export const raceData = [
  'White',
  'Black or African American',
  'American Indian or Alaska Native',
  'Asian',
  'Native Hawaiian or Other Pacific Islander',
  'Abenaki',
  'Algonquian',
  'Apache',
  'Chiricahua',
  'Fort Sill Apache',
  'Jicarilla Apache',
  'Lipan Apache',
  'Mescalero Apache',
  'Oklahoma Apache',
  'Payson Apache',
  'San Carlos Apache',
  'White Mountain Apache',
  'Arapaho',
  'Northern Arapaho',
  'Southern Arapaho',
  'Wind River Arapaho',
  'Arikara',
  'Assiniboine',
  'Assiniboine Sioux',
  'Fort Peck Assiniboine Sioux',
  'Bannock',
  'Blackfeet',
  'Brotherton',
  'Burt Lake Band',
  'Caddo',
  'Oklahoma Cado',
  'Cahuilla',
  'Agua Caliente Cahuilla',
  'Augustine',
  'Cabazon',
  'Los Coyotes',
  'Morongo',
  'Santa Rosa Cahuilla',
  'Torres-Martinez',
  'California Tribes',
  'Cahto',
  'Chimariko',
  'Coast Miwok',
  'Digger',
  'Kawaiisu',
  'Kern River',
  'Mattole',
  'Red Wood',
  'Santa Rosa',
  'Takelma',
  'Wappo',
  'Yana',
  'Yuki',
  'Canadian and Latin American Indian',
  'Canadian Indian',
  'French American Indian',
  'Mexican American Indian',
  'South American Indian',
  'Spanish American Indian',
  'Catawba',
  'Alatna',
  'Alexander',
  'Allakaket',
  'Alanvik',
  'Anvik',
  'Arctic',
  'Beaver',
  'Birch Creek',
  'Cantwell',
  'Chalkyitsik',
  'Chickaloon',
  'Chistochina',
  'Chitina',
  'Circle',
  'Cook Inlet',
  'Copper Center',
  'Copper River',
  'Dot Lake',
  'Doyon',
  'Eagle',
  'Eklutna',
  'Evansville',
  'Fort Yukon',
  'Gakona',
  'Galena',
  'Grayling',
  'Gulkana',
  'Healy Lake',
  'Holy Cross',
  'Hughes',
  'Huslia',
  'Iliamna',
  'Kaltag',
  'Kluti Kaah',
  'Knik',
  'Koyukuk',
  'Lake Minchumina',
  'Lime',
  'Mcgrath',
  'Manley Hot Springs',
  'Mentasta Lake',
  'Minto',
  'Nenana',
  'Nikolai',
  'Ninilchik',
  'Nondalton',
  'Northway',
  'Nulato',
  'Pedro Bay',
  'Rampart',
  'Ruby',
  'Salamatof',
  'Seldovia',
  'Slana',
  'Shageluk',
  'Stevens',
  'Stony River',
  'Takotna',
  'Tanacross',
  'Tanaina',
  'Tanana',
  'Tanana Chiefs',
  'Tazlina',
  'Telida',
  'Tetlin',
  'Tok',
  'Tyonek',
  'Venetie',
  'Wiseman',
  'Cayuse',
  'Chehalis',
  'Chemakuan',
  'Hoh',
  'Quileute',
  'Chemehuevi',
  'Cherokee',
  'Cherokee Alabama',
  'Cherokees of Northeast Alabama',
  'Cherokees of Southeast Alabama',
  'Eastern Cherokee',
  'Echota Cherokee',
  'Etowah Cherokee',
  'Northern Cherokee',
  'Tuscola',
  'United Keetowah Band of Cherokee',
  'Western Cherokee',
  'Cherokee Shawnee',
  'Cheyenne',
  'Northern Cheyenne',
  'Southern Cheyenne',
  'Cheyenne-Arapaho',
  'Chickahominy',
  'Eastern Chickahominy',
  'Western Chickahominy',
  'Chickasaw',
  'Chinook',
  'Clatsop',
  'Columbia River Chinook',
  'Kathlamet',
  'Upper Chinook',
  'Wakiakum Chinook',
  'Willapa Chinook',
  'Wishram',
  'Chippewa',
  'Bad River',
  'Bay Mills Chippewa',
  'Bois Forte',
  'Burt Lake Chippewa',
  'Fond du Lac',
  'Grand Portage',
  'Grand Traverse Band of Ottawa-Chippewa',
  'Keweenaw',
  'Lac Courte Oreilles',
  'Lac du Flambeau',
  'Lac Vieux Desert Chippewa',
  'Lake Superior',
  'Leech Lake',
  'Little Shell Chippewa',
  'Mille Lacs',
  'Minnesota Chippewa',
  'Ontonagon',
  'Red Cliff Chippewa',
  'Red Lake Chippewa',
  'Saginaw Chippewa',
  'St. Croix Chippewa',
  'Sault Ste. Marie Chippewa',
  'Sokoagon Chippewa',
  'Turtle Mountain',
  'White Earth',
  'Chippewa Cree',
  'Rocky Boy\'s Chippewa Cree',
  'Chitimacha',
  'Choctaw',
  'Clifton Choctaw',
  'Jena Choctaw',
  'Mississippi Choctaw',
  'Mowa Band of Choctaw',
  'Oklahoma Choctaw',
  'Chumash',
  'Santa Ynez',
  'Clear Lake',
  'Coeur D\'Alene',
  'Coharie',
  'Colorado River',
  'Colville',
  'Comanche',
  'Oklahoma Comanche',
  'Coos, Lower Umpqua, Siuslaw',
  'Coos',
  'Coquilles',
  'Costanoan',
  'Coushatta',
  'Alabama Coushatta',
  'Cowlitz',
  'Cree',
  'Creek',
  'Alabama Creek',
  'Alabama Quassarte',
  'Eastern Creek',
  'Eastern Muscogee',
  'Kialegee',
  'Lower Muscogee',
  'Machis Lower Creek Indian',
  'Poarch Band',
  'Principal Creek Indian Nation',
  'Star Clan of Muscogee Creeks',
  'Thlopthlocco',
  'Tuckabachee',
  'Croatan',
  'Crow',
  'Cupeno',
  'Agua Caliente',
  'Delaware',
  'Eastern Delaware',
  'Lenni-Lenape',
  'Munsee',
  'Oklahoma Delaware',
  'Rampough Mountain',
  'Sand Hill',
  'Diegueno',
  'Campo',
  'Capitan Grande',
  'Cuyapaipe',
  'La Posta',
  'Manzanita',
  'Mesa Grande',
  'San Pasqual',
  'Santa Ysabel',
  'Sycuan',
  'Eastern Tribes',
  'Attacapa',
  'Biloxi',
  'Georgetown',
  'Moor',
  'Nansemond',
  'Natchez',
  'Nausu Waiwash',
  'Nipmuc',
  'Paugussett',
  'Pocomoke Acohonock',
  'Southeastern Indians',
  'Susquehanock',
  'Tunica Biloxi',
  'Waccamaw-Siousan',
  'Wicomico',
  'Esselen',
  'Fort Belknap',
  'Fort Berthold',
  'Fort Mcdowell',
  'Fort Hall',
  'Gabrieleno',
  'Grand Ronde',
  'Gros Ventres',
  'Atsina',
  'Haliwa',
  'Hidatsa',
  'Hoopa',
  'Trinity',
  'Whilkut',
  'Hoopa Extension',
  'Houma',
  'Inaja-Cosmit',
  'Iowa',
  'Iowa of Kansas-Nebraska',
  'Iowa of Oklahoma',
  'Iroquois',
  'Cayuga',
  'Mohawk',
  'Oneida',
  'Onondaga',
  'Seneca',
  'Seneca Nation',
  'Seneca-Cayuga',
  'Tonawanda Seneca',
  'Tuscarora',
  'Wyandotte',
  'Juaneno',
  'Kalispel',
  'Karuk',
  'Kaw',
  'Kickapoo',
  'Oklahoma Kickapoo',
  'Texas Kickapoo',
  'Kiowa',
  'Oklahoma Kiowa',
  'Klallam',
  'Jamestown',
  'Lower Elwha',
  'Port Gamble Klallam',
  'Klamath',
  'Konkow',
  'Kootenai',
  'Lassik',
  'Long Island',
  'Matinecock',
  'Montauk',
  'Poospatuck',
  'Setauket',
  'Luiseno',
  'La Jolla',
  'Pala',
  'Pauma',
  'Pechanga',
  'Soboba',
  'Twenty-Nine Palms',
  'Temecula',
  'Lumbee',
  'Lummi',
  'Maidu',
  'Mountain Maidu',
  'Nishinam',
  'Makah',
  'Maliseet',
  'Mandan',
  'Mattaponi',
  'Menominee',
  'Miami',
  'Illinois Miami',
  'Indiana Miami',
  'Oklahoma Miami',
  'Miccosukee',
  'Micmac',
  'Aroostook',
  'Mission Indians',
  'Miwok',
  'Modoc',
  'Mohegan',
  'Mono',
  'Nanticoke',
  'Narragansett',
  'Navajo',
  'Alamo Navajo',
  'Canoncito Navajo',
  'Ramah Navajo',
  'Nez Perce',
  'Nomalaki',
  'Northwest Tribes',
  'Alsea',
  'Celilo',
  'Columbia',
  'Kalapuya',
  'Molala',
  'Talakamish',
  'Tenino',
  'Tillamook',
  'Wenatchee',
  'Yahooskin',
  'Omaha',
  'Oregon Athabaskan',
  'Osage',
  'Otoe-Missouria',
  'Ottawa',
  'Burt Lake Ottawa',
  'Michigan Ottawa',
  'Oklahoma Ottawa',
  'Paiute',
  'Bishop',
  'Bridgeport',
  'Burns Paiute',
  'Cedarville',
  'Fort Bidwell',
  'Fort Independence',
  'Kaibab',
  'Las Vegas',
  'Lone Pine',
  'Lovelock',
  'Malheur Paiute',
  'Moapa',
  'Northern Paiute',
  'Owens Valley',
  'Pyramid Lake',
  'San Juan Southern Paiute',
  'Southern Paiute',
  'Summit Lake',
  'Utu Utu Gwaitu Paiute',
  'Walker River',
  'Yerington Paiute',
  'Pamunkey',
  'Passamaquoddy',
  'Indian Township',
  'Pleasant Point Passamaquoddy',
  'Pawnee',
  'Oklahoma Pawnee',
  'Penobscot',
  'Peoria',
  'Oklahoma Peoria',
  'Pequot',
  'Marshantucket Pequot',
  'Pima',
  'Gila River Pima-Maricopa',
  'Salt River Pima-Maricopa',
  'Piscataway',
  'Pit River',
  'Pomo',
  'Central Pomo',
  'Dry Creek',
  'Eastern Pomo',
  'Kashia',
  'Northern Pomo',
  'Scotts Valley',
  'Stonyford',
  'Sulphur Bank',
  'Ponca',
  'Nebraska Ponca',
  'Oklahoma Ponca',
  'Potawatomi',
  'Citizen Band Potawatomi',
  'Forest County',
  'Hannahville',
  'Huron Potawatomi',
  'Pokagon Potawatomi',
  'Prairie Band',
  'Wisconsin Potawatomi',
  'Powhatan',
  'Pueblo',
  'Acoma',
  'Arizona Tewa',
  'Cochiti',
  'Hopi',
  'Isleta',
  'Jemez',
  'Keres',
  'Laguna',
  'Nambe',
  'Picuris',
  'Piro',
  'Pojoaque',
  'San Felipe',
  'San Ildefonso',
  'San Juan Pueblo',
  'San Juan De',
  'San Juan',
  'Sandia',
  'Santa Ana',
  'Santa Clara',
  'Santo Domingo',
  'Taos',
  'Tesuque',
  'Tewa',
  'Tigua',
  'Zia',
  'Zuni',
  'Puget Sound Salish',
  'Duwamish',
  'Kikiallus',
  'Lower Skagit',
  'Muckleshoot',
  'Nisqually',
  'Nooksack',
  'Port Madison',
  'Puyallup',
  'Samish',
  'Sauk-Suiattle',
  'Skokomish',
  'Skykomish',
  'Snohomish',
  'Snoqualmie',
  'Squaxin Island',
  'Steilacoom',
  'Stillaguamish',
  'Suquamish',
  'Swinomish',
  'Tulalip',
  'Upper Skagit',
  'Quapaw',
  'Quinault',
  'Rappahannock',
  'Reno-Sparks',
  'Round Valley',
  'Sac and Fox',
  'Iowa Sac and Fox',
  'Missouri Sac and Fox',
  'Oklahoma Sac and Fox',
  'Salinan',
  'Salish',
  'Salish and Kootenai',
  'Schaghticoke',
  'Scott Valley',
  'Seminole',
  'Big Cypress',
  'Brighton',
  'Florida Seminole',
  'Hollywood Seminole',
  'Oklahoma Seminole',
  'Serrano',
  'San Manual',
  'Shasta',
  'Shawnee',
  'Absentee Shawnee',
  'Eastern Shawnee',
  'Shinnecock',
  'Shoalwater Bay',
  'Shoshone',
  'Battle Mountain',
  'Duckwater',
  'Elko',
  'Ely',
  'Goshute',
  'Panamint',
  'Ruby Valley',
  'Skull Valley',
  'South Fork Shoshone',
  'Te-Moak Western Shoshone',
  'Timbi-Sha Shoshone',
  'Washakie',
  'Wind River Shoshone',
  'Yomba',
  'Shoshone Paiute',
  'Duck Valley',
  'Fallon',
  'Fort McDermitt',
  'Siletz',
  'Sioux',
  'Blackfoot Sioux',
  'Brule Sioux',
  'Cheyenne River Sioux',
  'Crow Creek Sioux',
  'Dakota Sioux',
  'Flandreau Santee',
  'Fort Peck',
  'Lake Traverse Sioux',
  'Lower Brule Sioux',
  'Lower Sioux',
  'Mdewakanton Sioux',
  'Miniconjou',
  'Oglala Sioux',
  'Pine Ridge Sioux',
  'Pipestone Sioux',
  'Prairie Island Sioux',
  'Prior Lake Sioux',
  'Rosebud Sioux',
  'Sans Arc Sioux',
  'Santee Sioux',
  'Sisseton-Wahpeton',
  'Sisseton Sioux',
  'Spirit Lake Sioux',
  'Standing Rock Sioux',
  'Teton Sioux',
  'Two Kettle Sioux',
  'Upper Sioux',
  'Wahpekute Sioux',
  'Wahpeton Sioux',
  'Wazhaza Sioux',
  'Yankton Sioux',
  'Yanktonai Sioux',
  'Siuslaw',
  'Spokane',
  'Stewart',
  'Stockbridge',
  'Susanville',
  'Tohono O\'Odham',
  'Ak-Chin',
  'Gila Bend',
  'San Xavier',
  'Sells',
  'Tolowa',
  'Tonkawa',
  'Tygh',
  'Umatilla',
  'Umpqua',
  'Cow Creek Umpqua',
  'Ute',
  'Allen Canyon',
  'Uintah Ute',
  'Ute Mountain Ute',
  'Wailaki',
  'Walla-Walla',
  'Wampanoag',
  'Gay Head Wampanoag',
  'Mashpee Wampanoag',
  'Warm Springs',
  'Wascopum',
  'Washoe',
  'Alpine',
  'Carson',
  'Dresslerville',
  'Wichita',
  'Wind River',
  'Winnebago',
  'Ho-chunk',
  'Nebraska Winnebago',
  'Winnemucca',
  'Wintun',
  'Wiyot',
  'Table Bluff',
  'Yakama',
  'Yakama Cowlitz',
  'Yaqui',
  'Barrio Libre',
  'Pascua Yaqui',
  'Yavapai Apache',
  'Yokuts',
  'Chukchansi',
  'Tachi',
  'Tule River',
  'Yuchi',
  'Yuman',
  'Cocopah',
  'Havasupai',
  'Hualapai',
  'Maricopa',
  'Mohave',
  'Quechan',
  'Yavapai',
  'Yurok',
  'Coast Yurok',
  'Alaska Indian',
  'Alaskan Athabascan',
  'Ahtna',
  'Southeast Alaska',
  'Tlingit-Haida',
  'Angoon',
  'Central Council of Tlingit and Haida Tribes',
  'Chilkat',
  'Chilkoot',
  'Craig',
  'Douglas',
  'Haida',
  'Hoonah',
  'Hydaburg',
  'Kake',
  'Kasaan',
  'Kenaitze',
  'Ketchikan',
  'Klawock',
  'Pelican',
  'Petersburg',
  'Saxman',
  'Sitka',
  'Tenakee Springs',
  'Tlingit',
  'Wrangell',
  'Yakutat',
  'Tsimshian',
  'Metlakatla',
  'Eskimo',
  'Greenland Eskimo',
  'Inupiat Eskimo',
  'Ambler',
  'Anaktuvuk',
  'Anaktuvuk Pass',
  'Arctic Slope Inupiat',
  'Arctic Slope Corporation',
  'Atqasuk',
  'Barrow',
  'Bering Straits Inupiat',
  'Brevig Mission',
  'Buckland',
  'Chinik',
  'Council',
  'Deering',
  'Elim',
  'Golovin',
  'Inalik Diomede',
  'Inupiaq',
  'Kaktovik',
  'Kawerak',
  'Kiana',
  'Kivalina',
  'Kobuk',
  'Kotzebue',
  'Koyuk',
  'Kwiguk',
  'Mauneluk Inupiat',
  'Nana Inupiat',
  'Noatak',
  'Nome',
  'Noorvik',
  'Nuiqsut',
  'Point Hope',
  'Point Lay',
  'Selawik',
  'Shaktoolik',
  'Shishmaref',
  'Shungnak',
  'Solomon',
  'Teller',
  'Unalakleet',
  'Wainwright',
  'Wales',
  'White Mountain',
  'White Mountain Inupiat',
  'Mary\'s Igloo',
  'Siberian Eskimo',
  'Gambell',
  'Savoonga',
  'Siberian Yupik',
  'Yupik Eskimo',
  'Akiachak',
  'Akiak',
  'Alakanuk',
  'Aleknagik',
  'Andreafsky',
  'Aniak',
  'Atmautluak',
  'Bethel',
  'Bill Moore\'s Slough',
  'Bristol Bay Yupik',
  'Calista Yupik',
  'Chefornak',
  'Chevak',
  'Chuathbaluk',
  'Clark\'s Point',
  'Crooked Creek',
  'Dillingham',
  'Eek',
  'Ekuk',
  'Ekwok',
  'Emmonak',
  'Goodnews Bay',
  'Hooper Bay',
  'Iqurmuit (Russian Mission)',
  'Kalskag',
  'Kasigluk',
  'Kipnuk',
  'Koliganek',
  'Kongiganak',
  'Kotlik',
  'Kwethluk',
  'Kwigillingok',
  'Levelock',
  'Lower Kalskag',
  'Manokotak',
  'Marshall',
  'Mekoryuk',
  'Mountain Village',
  'Naknek',
  'Napaumute',
  'Napakiak',
  'Napaskiak',
  'Newhalen',
  'New Stuyahok',
  'Newtok',
  'Nightmute',
  'Nunapitchukv',
  'Oscarville',
  'Pilot Station',
  'Pitkas Point',
  'Platinum',
  'Portage Creek',
  'Quinhagak',
  'Red Devil',
  'St. Michael',
  'Scammon Bay',
  'Sheldon\'s Point',
  'Sleetmute',
  'Stebbins',
  'Togiak',
  'Toksook',
  'Tulukskak',
  'Tuntutuliak',
  'Tununak',
  'Twin Hills',
  'Georgetown',
  'St. Mary\'s',
  'Umkumiate',
  'Aleut',
  'Alutiiq Aleut',
  'Tatitlek',
  'Ugashik',
  'Bristol Bay Aleut',
  'Chignik',
  'Chignik Lake',
  'Egegik',
  'Igiugig',
  'Ivanof Bay',
  'King Salmon',
  'Kokhanok',
  'Perryville',
  'Pilot Point',
  'Port Heiden',
  'Chugach Aleut',
  'Chenega',
  'Chugach Corporation',
  'English Bay',
  'Port Graham',
  'Eyak',
  'Koniag Aleut',
  'Akhiok',
  'Agdaagux',
  'Karluk',
  'Kodiak',
  'Larsen Bay',
  'Old Harbor',
  'Ouzinkie',
  'Port Lions',
  'Sugpiaq',
  'Suqpigaq',
  'Unangan Aleut',
  'Akutan',
  'Aleut Corporation',
  'Aleutian',
  'Aleutian Islander',
  'Atka',
  'Belkofski',
  'Chignik Lagoon',
  'King Cove',
  'False Pass',
  'Nelson Lagoon',
  'Nikolski',
  'Pauloff Harbor',
  'Qagan Toyagungin',
  'Qawalangin',
  'St. George',
  'St. Paul',
  'Sand Point',
  'South Naknek',
  'Unalaska',
  'Unga',
  'Asian Indian',
  'Bangladeshi',
  'Bhutanese',
  'Burmese',
  'Cambodian',
  'Chinese',
  'Taiwanese',
  'Filipino',
  'Hmong',
  'Indonesian',
  'Japanese',
  'Korean',
  'Laotian',
  'Malaysian',
  'Okinawan',
  'Pakistani',
  'Sri Lankan',
  'Thai',
  'Vietnamese',
  'Iwo Jiman',
  'Maldivian',
  'Nepalese',
  'Singaporean',
  'Madagascar',
  'African',
  'Botswanan',
  'Ethiopian',
  'Liberian',
  'Namibian',
  'Nigerian',
  'Zairean',
  'Bahamian',
  'Barbadian',
  'Dominican',
  'Dominica Islander',
  'Haitian',
  'Jamaican',
  'Tobagoan',
  'Trinidadian',
  'West Indian',
  'Polynesian',
  'Samoan',
  'Tahitian',
  'Tongan',
  'Tokelauan',
  'Micronesian',
  'Guamanian or Chamorro',
  'Guamanian',
  'Chamorro',
  'Mariana Islander',
  'Marshallese',
  'Palauan',
  'Carolinian',
  'Kosraean',
  'Pohnpeian',
  'Saipanese',
  'Kiribati',
  'Chuukese',
  'Yapese',
  'Melanesian',
  'Fijian',
  'Papua New Guinean',
  'Solomon Islander',
  'New Hebrides',
  'European',
  'Armenian',
  'English',
  'French',
  'German',
  'Irish',
  'Italian',
  'Polish',
  'Scottish',
  'Middle Eastern or North African',
  'Assyrian',
  'Egyptian',
  'Iranian',
  'Iraqi',
  'Lebanese',
  'Palestinian',
  'Syrian',
  'Afghanistani',
  'Israeili',
  'Arab',
  'Other Race'

]

export const ethnicityData = [
  'Hispanic or Latino',
  'Spaniard',
  'Andalusian',
  'Asturian',
  'Castillian',
  'Catalonian',
  'Belearic Islander',
  'Gallego',
  'Valencian',
  'Canarian',
  'Spanish Basque',
  'Mexican',
  'Mexican American',
  'Mexicano',
  'Chicano',
  'La Raza',
  'Mexican American Indian',
  'Central American',
  'Costa Rican',
  'Guatemalan',
  'Honduran',
  'Nicaraguan',
  'Panamanian',
  'Salvadoran',
  'Central American Indian',
  'Canal Zone',
  'South American',
  'Argentinean',
  'Bolivian',
  'Chilean',
  'Colombian',
  'Ecuadorian',
  'Paraguayan',
  'Peruvian',
  'Uruguayan',
  'Venezuelan',
  'South American Indian',
  'Criollo',
  'Latin American',
  'Puerto Rican',
  'Cuban',
  'Dominican',
  'Not Hispanic or Latino'

]
/* These are appointment times in 15 mins increment; the first time needs to be 00:01 instead of 00:00 */
export const timeSlots = [
  'Select',
  '00:01',
  '00:15',
  '00:30',
  '00:45',
  '01:00',
  '01:15',
  '01:30',
  '01:45',
  '02:00',
  '02:15',
  '02:30',
  '02:45',
  '03:00',
  '03:15',
  '03:30',
  '03:45',
  '04:00',
  '04:15',
  '04:30',
  '04:45',
  '05:00',
  '05:15',
  '05:30',
  '05:45',
  '06:00',
  '06:15',
  '06:30',
  '06:45',
  '07:00',
  '07:15',
  '07:30',
  '07:45',
  '08:00',
  '08:15',
  '08:30',
  '08:45',
  '09:00',
  '09:15',
  '09:30',
  '09:45',
  '10:00',
  '10:15',
  '10:30',
  '10:45',
  '11:00',
  '11:15',
  '11:30',
  '11:45',
  '12:00',
  '12:15',
  '12:30',
  '12:45',
  '13:00',
  '13:15',
  '13:30',
  '13:45',
  '14:00',
  '14:15',
  '14:30',
  '14:45',
  '15:00',
  '15:15',
  '15:30',
  '15:45',
  '16:00',
  '16:15',
  '16:30',
  '16:45',
  '17:00',
  '17:15',
  '17:30',
  '17:45',
  '18:00',
  '18:15',
  '18:30',
  '18:45',
  '19:00',
  '19:15',
  '19:30',
  '19:45',
  '20:00',
  '20:15',
  '20:30',
  '20:45',
  '21:00',
  '21:15',
  '21:30',
  '21:45',
  '22:00',
  '22:15',
  '22:30',
  '22:45',
  '23:00',
  '23:15',
  '23:30',
  '23:45'
]

export const languagePref = [
  { language: 'English', code: 'en-US' },
  { language: 'Spanish', code: 'es-ES' },
  { language: 'Chinese (Cantonese, Mandarin, other varieties)', code: 'zh-CN' },
  { language: 'French and French Creole', code: 'fr-FR' },
  { language: 'Vietnamese', code: 'vi-VN' },
  { language: 'Korean', code: 'ko-KR' },
  { language: 'Arabic', code: 'ar-AE' },
  { language: 'German', code: 'de-DE' },
  { language: 'Russian', code: 'ru-RU' }
]

export const clientCardData = [{ userName: 'Rachael Mason', photoId: patImg, age: '32', dob: '21/01/89', appointments: '14', videos: '15', assessments: '12' }, { userName: 'Alcia Cornwell', photoId: pracImg, age: '28', dob: '13/06/93', appointments: '12', videos: '25', assessments: '12' }, { userName: 'Jane Doe', photoId: coordImg, age: '35', dob: '25/04/85', appointments: '12', videos: '15', assessments: '14' }, { userName: 'Rachael Mason', photoId: patImg, age: '32', dob: '21/01/89', appointments: '14', videos: '15', assessments: '12' }, { userName: 'Alcia Cornwell', photoId: pracImg, age: '28', dob: '13/06/93', appointments: '12', videos: '25', assessments: '12' }, { userName: 'Jane Doe', photoId: coordImg, age: '35', dob: '25/04/85', appointments: '12', videos: '15', assessments: '14' }, { userName: 'Rachael Mason', photoId: patImg, age: '32', dob: '21/01/89', appointments: '14', videos: '15', assessments: '12' }, { userName: 'Alcia Cornwell', photoId: pracImg, age: '28', dob: '13/06/93', appointments: '12', videos: '25', assessments: '12' }, { userName: 'Rachael Mason', photoId: patImg, age: '32', dob: '21/01/89', appointments: '14', videos: '15', assessments: '12' }]

export const morningTimeSlots = ['08:00', '09:00', '10:00', '10:30', '11:00', '11:30']
export const afternoonTimeSlots = ['14:00', '15:00', '16:00', '17:30', '18:00']
export const eveningTimeSlots = ['18:30', '19:30']
export const viewGraphFrequency = ['Weekly', 'Monthly', 'Yearly']

// Appointment table columns
export const practitionerColumns = [
  {
    Header: 'Appointments',
    accessor: 'clientName',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: fourteenPx }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Date & Time',
    accessor: 'meetingDateTime',
    width: '100',
    Cell: ({ cell: { value } }) => {
      const startDate = value.split(';')[0]
      const endDate = value.split(';')[1]
      const dateConst = Moment(startDate).format('MMM DD, yyyy')
      const timeConst = Moment(startDate).format('hh:mm A')
      const endTimeConst = Moment(endDate).format('hh:mm A')

      return (
        <>
          <div style={{ color: 'gray', fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
            <img src={calImg} width={15}></img>
            <span> </span>

            {`${dateConst} | ${timeConst}-${endTimeConst}`}
          </div>
        </>
      )
    }
  },
  {
    Header: 'Status',
    accessor: 'status',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ color: value === 'Completed' ? '#4C927E' : value === 'Scheduled' ? 'black' : '#6A6A6A', fontFamily: 'Roboto, Regular', fontSize: fourteenPx }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Assessments',
    accessor: 'meetingAssessmentStatus',
    Cell: ({ cell: { value } }) =>
      <AssessmentsCell values={value} />

  },
  {
    Header: 'Assignments',
    accessor: 'assignments',
    Cell: ({ cell: { value } }) => <AssignmentsCell values="" />

  }
]
export const coordinatorColumns = [
  {
    Header: 'Client Name',
    accessor: 'clientName',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Practitioner Name',
    accessor: 'practitionerName',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Date & Time',
    accessor: 'meetingDateTime',
    width: '100',
    Cell: ({ cell: { value } }) => {
      const startDate = value.split(';')[0]
      const endDate = value.split(';')[1]
      const dateConst = Moment(startDate).format('MMM DD, yyyy')
      const timeConst = Moment(startDate).format('hh:mm A')
      const endTimeConst = Moment(endDate).format('hh:mm A')

      return (
        <>
          <div style={{ color: 'gray', fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
            <img src={calImg} width={15}></img>
            <span> </span>

            {`${dateConst} | ${timeConst}-${endTimeConst}`}
          </div>
        </>
      )
    }
  },
  {
    Header: 'Mobile Number',
    accessor: 'mobileNo',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Email',
    accessor: 'email',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Status',
    accessor: 'status',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: fourteenPx, color: value === 'Completed' ? '#4C927E' : value === 'Scheduled' ? 'black' : '#6A6A6A' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Assessments',
    accessor: 'meetingAssessmentStatus',
    Cell: ({ cell: { value } }) =>
      <AssessmentsCell values={value} />

  },
  {
    Header: 'Actions',
    accessor: 'meetingStatus',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => <ActionsCell values={value} />

  }
]
export const patientsColumns = [
  {
    Header: 'Appointments',
    accessor: 'practitionerName',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: fourteenPx }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Date & Time',
    accessor: 'meetingDateTime',
    width: '100',
    Cell: ({ cell: { value } }) => {
      const startDate = value.split(';')[0]
      const endDate = value.split(';')[1]
      const dateConst = Moment(startDate).format('MMM DD, yyyy')
      const timeConst = Moment(startDate).format('hh:mm A')
      const endTimeConst = Moment(endDate).format('hh:mm A')

      return (
        <>
          <div style={{ color: 'gray', fontFamily: 'Roboto, Regular', fontSize: fourteenPx }}>
            <img src={calImg} width={15}></img>
            <span> </span>

            {`${dateConst} | ${timeConst}-${endTimeConst}`}
          </div>
        </>
      )
    }
  },
  {
    Header: 'Assessments',
    accessor: 'meetingAssessmentStatus',
    Cell: ({ cell: { value } }) =>
      <AssessmentsCell values={value} />
  },
  {
    Header: 'Status',
    accessor: 'status',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ color: value === 'Completed' ? '#7EC0B7' : value === 'Scheduled' ? 'black' : '#6A6A6A', fontFamily: 'Roboto, Regular', fontWeight: '500', fontSize: fourteenPx }}>
          {value}
        </div>
      )
    }
  },

  {
    Header: 'Actions',
    accessor: 'meetingDateTimeStatus',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => <PatientActionsCell values={value} />

  }
]
export const patientProfileColumns = [

  {
    Header: 'Date & Time',
    accessor: 'meetingDateTime',
    width: '100',
    Cell: ({ cell: { value } }) => {
      const startDate = value.split(';')[0]
      const endDate = value.split(';')[1]
      const dateConst = Moment(startDate).format('MMM DD, yyyy')
      const timeConst = Moment(startDate).format('hh:mm A')
      const endTimeConst = Moment(endDate).format('hh:mm A')

      return (
        <>
          <div style={{ color: 'gray', fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
            <img src={calImg} width={15}></img>
            <span> </span>

            {`${dateConst} | ${timeConst}-${endTimeConst}`}
          </div>
        </>
      )
    }
  },
  {
    Header: 'Status',
    accessor: 'status',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: value === 'Completed' ? '#7EC0B7' : value === 'Scheduled' ? 'black' : '#6A6A6A' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Assessments',
    accessor: 'meetingAssessmentStatus',
    Cell: ({ cell: { value } }) =>
      <AssessmentsCell values={value} />
  },
  {
    Header: 'Assignments',
    accessor: 'assignments',
    Cell: ({ cell: { value } }) =>
      <AssignmentsCell values={value} />
  }
]

export const assignAssessmentsColumns = [
  {
    Header: 'Name',
    accessor: 'name',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Type',
    accessor: 'type',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {`${value[0].toUpperCase()}${value.slice(1)}`}
        </div>
      )
    }
  },
  {
    Header: 'Actions',
    accessor: 'assignStatus',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => <AssignAssessmentsActionsCell values={value} />
  }
]
export const AssessmentsListingColumns = [
  {
    Header: 'Assessments',
    accessor: 'assessmentName',
    Cell: ({ cell: { value } }) => {
      return (
        <div id='assessmentsData' style={{ fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
          {`${value[0].toUpperCase()}${value.slice(1)}`}
        </div>
      )
    }
  },
  {
    Header: 'Type',
    accessor: 'type',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
          {`${value[0].toUpperCase()}${value.slice(1)}`}
        </div>
      )
    }
  },
  {
    Header: 'Status',
    accessor: 'status',
    Cell: ({ cell: { value } }) => {
      return (
        <AssessmentsListingCell values={value} />
      )
    }
  }
]
export const ClientAssessmentsListingColumns = [
  {
    Header: 'Name',
    accessor: 'activityName',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: fourteenPx }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Duration',
    accessor: 'videoWatchDuration',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: fourteenPx }}>
          <img src={timer} width={14}></img>
          <span> </span>

          {value}
        </div>
      )
    }
  }
]
export const assignActivitiesColumns = [
  {
    Header: 'Name',
    accessor: 'activityName',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Description',
    accessor: 'description',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Category',
    accessor: 'category',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Duration',
    accessor: 'duration',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          <img src={timer} width={14}></img>
          <span> </span>

          {`${value} mins`}
        </div>
      )
    }
  },
  {
    Header: 'Type',
    accessor: 'type',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {`${value[0].toUpperCase()}${value.slice(1)}`}
        </div>
      )
    }
  },
  {
    Header: 'Guided',
    accessor: 'isGuided',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value ? 'Yes' : 'No'}
        </div>
      )
    }
  },
  {
    Header: 'VR Enabled',
    accessor: 'isVREnabled',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value ? 'Yes' : 'No'}
        </div>
      )
    }
  },
  {
    Header: 'Language',
    accessor: 'language',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Actions',
    accessor: 'assignStatus',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => <AssignActionsCell values={value} />
  }
]
export const ActivitiesListingColumns = [
  {
    Header: 'Name',
    accessor: 'activityName',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Category',
    accessor: 'category',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Duration',
    accessor: 'videoWatchDuration',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
          <img src={timer} width={14}></img>
          <span> </span>

          {value}
        </div>
      )
    }
  },
  {
    Header: 'Type',
    accessor: 'activityType',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {`${value[0].toUpperCase()}${value.slice(1)}`}
        </div>
      )
    }
  },
  {
    Header: 'Guided',
    accessor: 'isGuided',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value ? 'Yes' : 'No'}
        </div>
      )
    }
  },
  {
    Header: 'VR Enabled',
    accessor: 'isVREnabled',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value ? 'Yes' : 'No'}
        </div>
      )
    }
  },
  {
    Header: 'Language',
    accessor: 'language',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Status',
    accessor: 'status',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => <ActivitiesStatusCell values={value} />
  },
  {
    Header: 'Actions',
    accessor: 'meetingStatus',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => <ActivitiesActionCell values={value} />
  }
]
export const ClientActivitiesListingColumns = [
  {
    Header: 'Name',
    accessor: 'activityName',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: fourteenPx }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Status',
    accessor: 'status',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => <ActivitiesStatusCell values={value} />
  },
  {
    Header: 'Duration',
    accessor: 'videoWatchDuration',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: fourteenPx }}>
          <img src={timer} width={14}></img>
          <span> </span>

          {value}
        </div>
      )
    }
  },
  {
    Header: 'VR Enabled',
    accessor: 'isVREnabled',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value ? 'Yes' : 'No'}
        </div>
      )
    }
  }
]
export const ClientActivitiesHWListingColumns = [
  {
    Header: 'Name',
    accessor: 'activityName',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: fourteenPx }}>
          {value}
        </div>
      )
    }
  },
  {
    Header: 'Status',
    accessor: 'status',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => <ActivitiesStatusCell values={value} />
  },
  {
    Header: 'Duration',
    accessor: 'videoWatchDuration',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: fourteenPx }}>
          <img src={timer} width={14}></img>
          <span> </span>

          {value}
        </div>
      )
    }
  },
  {
    Header: 'VR Enabled',
    accessor: 'isVREnabled',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px', color: 'black' }}>
          {value ? 'Yes' : 'No'}
        </div>
      )
    }
  },
  {
    Header: 'Action',
    accessor: 'meetingStatus',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => {
      return (
        <ActivityListingHWCell values={value} />
      )
    }
  }
]
export const CoordinatorClientAssessmentsColumns = [
  {
    Header: 'Due Date',
    accessor: 'dueDate',
    Cell: ({ cell: { value } }) => {
      const dateConst = Moment(value).format('MMM DD, yyyy')

      return (
        <div style={{ color: 'gray', fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
            <img src={calImg} width={15}></img>
            <span> </span>

            <span style={{ paddingLeft: '5px' }}>{dateConst}</span>
          </div>
      )
    }
  },
  {
    Header: 'Assessments',
    accessor: 'status',
    Cell: ({ cell: { value } }) => {
      return (
        <AssessmentsListingCell values={value} />
      )
    }
  },
  {
    Header: 'Actions',
    accessor: 'assignStatus',
    disableSortBy: true,
    Cell: ({ cell: { value } }) => <ActionsCellAssessments values={value} />
  }
]
export const AppointmentSummaryColumns = [
  {
    Header: 'Name',
    accessor: 'summaryName',
    Cell: ({ cell: { value } }) => {
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
          {`${value[0].toUpperCase()}${value.slice(1)}`}
        </div>
      )
    }
  },
  {
    Header: 'Assessments',
    accessor: 'type',
    // Cell: ({ cell: { value } }) => <Genres values={value} />
    Cell: ({ cell: { value } }) => {
      const bgColor = value === 'video' || value === 'audio' ? '#FCBB81' : '#5EA1BC'
      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '11px', color: 'white' }}>
          <span style={{ padding: '6px', borderRadius: 4, backgroundColor: bgColor }}>{`${value && value[0].toUpperCase()}${value && value.slice(1)}`}</span>
        </div>
      )
    }
  },
  {
    Header: 'Due Date',
    accessor: 'dueDate',
    Cell: ({ cell: { value } }) => {
      const dateConst = Moment(value).format('MMM DD, yyyy')

      return (
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: '14px' }}>
          {value && value.length > 0 ? `Due by ${dateConst}` : ''}
        </div>
      )
    }
  },
  {
    Header: 'Status',
    accessor: 'updatedStatus',
    Cell: ({ cell: { value } }) => <AppointmentSummaryCell values={value} />
  }
]

// Arrays for Appointment search
export const coordinatorAppointmentFilter = [{ name: 'Client Name', key: 'clientName' }, { name: 'Practitioner Name', key: 'practitionerName' }, { name: 'Appointment Status', key: 'status' }]
export const practitionerAppointmentFilter = [{ name: 'Client Name', key: 'clientName' }, { name: 'Appointment Status', key: 'status' }]

export const coordinatorClientSearch = [{ name: 'Client Name', key: 'userName' }]
export const coordinatorPractitionerSearch = [{ name: 'Practitioner Name', key: 'userName' }, { name: 'Specialities', key: 'specialties' }, { name: 'Services', key: 'services' }]
export const activitiesSearch = [{ name: 'Name', key: 'activityName' }, { name: 'Description', key: 'description' }]
export const assessmentsSearch = [{ name: 'Name', key: 'name' }, { name: 'Type', key: 'type' }]

export const fourteenPx = isMobile ? '17px' : '14px'
export const fourteenPx1 = isMobile ? '17px' : '12px'

export const tenPx = isMobile ? '14px' : '12px'
export const twelvePx = isMobile ? '15px' : '12px'
export const twelvePxTable = isMobile ? '15px' : '14px'
export const cardHeight = isMobile ? 190 : 160

export const colorCode = [
  '#DE3163',
  '#FF7F50',
  '#FFBF00',
  '#DFFF00',
  '#9FE2BF',
  '#40E0D0',
  '#6495ED',
  '#CCCCFF',

  '#FFDAB9',
  '#BDB76B',
  '#FFA07A',
  '#F0E68C',
  '#F08080',
  '#90EE90',
  '#9ACD32',

  '#AFEEEE',
  '#5F9EA0',
  '#87CEEB',
  '#7B68EE',
  '#F5DEB3',
  '#BC8F8F',
  '#CD853F',
  '#00ffff',
  '#00bfff',
  '#bfff00',
  '#bf00ff',
  '#ffb3b3',
  '#80ff00',
  '#ccffcc',
  '#000066',
  '#006633',
  '#33CC66',
  '#663366',
  '#3366CC',
  '#66CC33',
  '#990000',
  '#99CC00',
  '#CC6600',
  '#CCCC00',
  '#FF9900',
  '#00CC33',
  '#333333',
  '#336633',
  '#339933',
  '#669933',
  '999933',
  '#CC9933',
  '#CCCC33',
  '#FF9933',
  '#FF66CC' // 50
]
