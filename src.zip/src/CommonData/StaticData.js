export const StaticData = {
  themeRedColor: '#F24B5D',
  registrationHeaderMessage: '',
  registrationMessageBody: '',
  allPatients: 'All Patients',
  registerClient: 'REGISTER CLIENT',
  scheduleAppointment: 'SCHEDULE APPOINTMENT',
  selectPatient: 'Select Patient',
  selectProvider: 'Select Provider, Time & Date, Add Meeting Link',
  confirm: 'Confirm',
  confirmAppointment: 'CONFIRM APPOINTMENT',
  scheduleAppointmentLbl: 'Schedule Appointment',
  allAppointments: 'ALL APPOINTMENTS',
  appointments: 'Appointments',
  selectProviderLbl: 'Select Provider',
  selectDateTime: 'Select Date & Time',
  addMeetingLink: 'Add Meeting Link',
  add: 'ADD',
  next: 'NEXT',
  today: 'Today',
  thisWeek: 'This Week',
  thisMonth: 'This Month',
  all: 'All',
  byDate: 'By Date',
  viewDetails: 'VIEW DETAILS',
  activities: 'Activities',
  assessments: 'Assessments',
  assign: 'ASSIGN',
  register: 'REGISTER',
  reset: 'RESET',
  upload: 'UPLOAD',
  allClients: 'All Clients',
  changePassword: 'CHANGE PASSWORD',
  save: 'SAVE',
  registerNewPractitioner: 'Register New Practitioner',
  allPractitioners: 'ALL PRACTITIONERS',
  allPractitionersLbl: 'All Practitioners',
  editProfile: 'EDIT PROFILE',
  assignNew: 'ASSIGN NEW'

}
export const CoordinatorRole = [
  {
    link: '/clients',
    text: 'Clients'
  },
  {
    link: '/practitioners',
    text: 'Practitioners'
  },
  {
    link: '/appointments',
    text: 'Appointments'
  }
]
export const ClientRole = [
  {
    link: '/appointments',
    text: 'Appointments'
  },
  {
    link: '/assessments',
    text: 'Assessments'
  },
  {
    link: '/sessionactivities',
    text: 'Session Activities'
  }
]
export const PractitionerRole = [

  {
    link: '/overview',
    text: 'Overview'
  },
  {
    link: '/appointments',
    text: 'Appointments'
  },
  {
    link: '/clients',
    text: 'Clients'
  }
]
