import WIP from '../Assets/WIP.png'
import React from 'react'
import PropTypes from 'prop-types'

// import NoRecordFoundImg from '../Assets/NoRecordFound.png'

export const WorkInProgress = () => {
  return (
    <>
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <img src={WIP} />
      </div>
    </>
  )
}
export const NoRecordFound = () => {
  return (
    <>
      {/* <img src={NoRecordFoundImg} /> */}
      <div
        style={{
          width: '100%',
          justifyContent: 'center',
          display: 'flex',
          height: '200px',
          alignItems: 'center',
          fontSize: '20px'
        }}
      >
       No appointments found.
      </div>
    </>
  )
}

export const NoAppointmentFound = () => {
  return (
    <>
      {/* <img src={NoRecordFoundImg} /> */}
      <div
        style={{
          fontSize: '20px',
          fontWeight: '400',
          width: '100%',
          justifyContent: 'center',
          display: 'flex',
          height: '200px',
          alignItems: 'center',
          color: '#F86A79'

        }}
      >
        No appointments found.
      </div>
    </>
  )
}

export const NoAssignActivitiesFound = () => {
  return (
    <>
      {/* <img src={NoRecordFoundImg} /> */}
      <div
        style={{
          justifyContent: 'center',
          paddingTop: '70px',
          marginLeft: '50px',
          fontFamily: 'Roboto',
          fontSize: '20px',
          color: '#F86A79'
        }}
      >
        No appointments found.
      </div>
    </>
  )
}

export const NoActivitiesFound = ({ type }) => {
  return (
    <>
      {/* <img src={NoRecordFoundImg} /> */}
      <div
        style={{
          padding: '10px',
          marginLeft: '10px',
          fontFamily: 'Roboto, Regular',
          fontSize: '16px',
          backgroundColor: '#F8F8F8',
          color: '#F86A79'
        }}
      >
        {type === 'activities' ? 'No assigned videos' : 'No assessments found'}
      </div>
    </>
  )
}
NoActivitiesFound.propTypes = {
  type: PropTypes.string
}
