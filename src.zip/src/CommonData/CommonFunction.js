import moment from 'moment'
import config from '../config'

export const getDateFromStringTemp = (dateStr) => {
  // var d = moment(new Date(dateStr)).format("yyyy-MM-DDTHH:mm:ss.SSSZZ")
  // const d = new Date(dateStr)

  // const n = d.toUTCString()
  // const m = moment.utc(n).format('yyyy-MM-DDTHH:mm:ss.SSS')

  // const m1 = moment(n).format('yyyy-MM-DDTHH:mm:ss.SSSZZ')

  // const mf = moment.utc(new Date(dateStr)).format('yyyy-MM-DDTHH:mm:ss.SSS')

  return new Date(dateStr)
}

export const showJoinOption = (forDateTime, forEndDateTime) => {
  // console.log('Fordatetime::', forDateTime)

  const currentDate = moment(new Date()).format('MM/DD/yyyy')

  const meetingDate = moment(forDateTime).format('MM/DD/yyyy')

  const currentTime = moment(new Date(new Date().setHours(new Date().getHours()))).format('HH:mm')
  const meetingEndTimeHr = moment(new Date(new Date(forEndDateTime).setHours(new Date(forEndDateTime).getHours()))).format('HH:mm')

  const meetingTime = moment(forDateTime).format('HH:mm')

  const greaterThanMeetingTime = meetingTime <= currentTime
  const lessThanMeetingEndTime = currentTime <= meetingEndTimeHr
  const sameMeetingDate = new Date(meetingDate).getTime() === new Date(currentDate).getTime()

  // console.log("currentTime::", currentTime);
  // console.log("meetingTime::", meetingTime);
  // console.log("meetingEndTimeHr::", meetingEndTimeHr);

  // console.log('sameMeetingDate::', sameMeetingDate)
  // console.log('current time greaterThanmeetingTime::', greaterThanMeetingTime)
  // console.log('Current time lessThanMeetingEndTime::', lessThanMeetingEndTime)
  if (config.APP_ENV_NAME === 'local21') {
    return true
  }

  return (sameMeetingDate && greaterThanMeetingTime && lessThanMeetingEndTime)
  // return true
}

export const getDateFromString = (dateStr) => {
  // console.log("Date from str::", dateStr, new Date(dateStr));

  return new Date(dateStr)
}

export const getFormatedDateFromString = (dateStr) => {
  const dateStrFormat = new Date(dateStr).toLocaleString('en-US').split(',')[0]
  return dateStrFormat
}

// Appt Listing date formater starts
// From date will be (0, 0, 0, 0)
// To date will be (23, 59, 59, 999)
// Above date changes due to Appt listing in different time zone
// const start = new Date()
// start.setHours(0, 0, 0, 0)
// const end = new Date()
// end.setHours(23, 59, 59, 999)
export const getTodaysDate = () => {
  return moment.utc(new Date(new Date().setHours(23, 59, 59, 999))).format('yyyy-MM-DDTHH:mm:ss.SSS')
}
export const getTodaysFromDate = () => {
  return moment.utc(new Date(new Date().setHours(0, 0, 0, 0))).format('yyyy-MM-DDTHH:mm:ss.SSS')
}
export const getNextWeeksDate = (isPastAppointment) => {
  const dateNow = new Date()
  dateNow.setHours(23, 59, 59, 999)
  const weeksFutureDate = isPastAppointment ? new Date(dateNow.setDate(dateNow.getDate() - 7)) : new Date(dateNow.setDate(dateNow.getDate() + 7))
  return moment.utc(weeksFutureDate).format('yyyy-MM-DDTHH:mm:ss.SSS')
}
export const getNextWeeksFromDate = (isPastAppointment) => {
  const dateNow = new Date()
  dateNow.setHours(0, 0, 0, 0)
  const weeksFutureDate = isPastAppointment ? new Date(dateNow.setDate(dateNow.getDate() - 7)) : new Date(dateNow.setDate(dateNow.getDate() + 7))
  return moment.utc(weeksFutureDate).format('yyyy-MM-DDTHH:mm:ss.SSS')
}
export const getNextMonthsDate = (isPastAppointment) => {
  const dateNow = new Date()
  dateNow.setHours(23, 59, 59, 999)
  const monthFutureDate = isPastAppointment ? new Date(dateNow.setDate(dateNow.getDate() - 30)) : new Date(dateNow.setDate(dateNow.getDate() + 30))
  return moment.utc(monthFutureDate).format('yyyy-MM-DDTHH:mm:ss.SSS')
}
export const getNextMonthsFromDate = (isPastAppointment) => {
  const dateNow = new Date()
  dateNow.setHours(0, 0, 0, 0)
  const monthFutureDate = isPastAppointment ? new Date(dateNow.setDate(dateNow.getDate() - 30)) : new Date(dateNow.setDate(dateNow.getDate() + 30))
  return moment.utc(monthFutureDate).format('yyyy-MM-DDTHH:mm:ss.SSS')
}
export const getCustomSelectedDate = (dateStr) => {
  const dateNow = new Date(dateStr)
  dateNow.setHours(23, 59, 59, 999)
  return moment.utc(dateNow).format('yyyy-MM-DDTHH:mm:ss.SSS')
}
export const getCustomSelectedFromDate = (dateStr) => {
  const dateNow = new Date(dateStr)
  dateNow.setHours(0, 0, 0, 0)
  return moment.utc(dateNow).format('yyyy-MM-DDTHH:mm:ss.SSS')
}
// Appt listing date formater ends

export const getPastDate = (pastDays) => {
  // console.log('getPastDate starts')

  const dateNow = new Date()
  const pastDate = new Date(dateNow.setDate(dateNow.getDate() - pastDays))
  return moment(pastDate).format('DD MMM YY')
}
export const getFutureDateCharts = (futureDate) => {
  const dateNow = new Date()
  const monthFutureDate = new Date(dateNow.setDate(dateNow.getDate() + futureDate))
  return moment(monthFutureDate).format('DD/MM/YY')
}
export const getDateWithFormat = (dateStr, formatStr) => {
  return moment(dateStr).format(formatStr)
}
export const getFutureDateWithFormat = (futureDate, formatStr) => {
  const dateNow = new Date()
  const calculatedFutureDate = new Date(dateNow.setDate(dateNow.getDate() + futureDate))
  // const m = moment.utc(n).format('yyyy-MM-DDTHH:mm:ss.SSS')
  return moment.utc(calculatedFutureDate).format(formatStr)
}
export const getPastDateWithFormat = (pastDays, formatStr) => {
  const dateNow = new Date()
  const calculatedPastDate = new Date(dateNow.setDate(dateNow.getDate() - pastDays))
  // const m = moment.utc(n).format('yyyy-MM-DDTHH:mm:ss.SSS')
  return moment(calculatedPastDate).format(formatStr)
}
