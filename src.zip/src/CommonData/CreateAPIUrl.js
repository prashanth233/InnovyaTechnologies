export const createCoordinatorAppointmentsUrl = (account, urlData) => {
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const currentRole = JSON.parse(localStorage.getItem('UserType'))

  const tenantId = account.idTokenClaims.extension_Organization
  const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName
  const completeUrl = `${urlData}${tenantId}/${practiceName}/appointments`
  return completeUrl
}
export const createAppointmentUrl = (account, urlData) => {
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const currentRole = JSON.parse(localStorage.getItem('UserType'))

  const tenantId = account.idTokenClaims.extension_Organization
  const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName
  const completeUrl = `${urlData}${tenantId}/${practiceName}/appointment`
  return completeUrl
}
export const createClientAssessmentsListingUrl = (account, urlData) => {
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const currentRole = JSON.parse(localStorage.getItem('UserType'))

  const tenantId = account.idTokenClaims.extension_Organization
  const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName
  const completeUrl = `${urlData}${tenantId}/${practiceName}/clients/`
  return completeUrl
}
export const videoStatusUpdateUrl = (account, urlData) => {
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const currentRole = JSON.parse(localStorage.getItem('UserType'))
  // console.log('Account Data::', account)
  const tenantId = account.idTokenClaims.extension_Organization
  const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName
  const completeUrl = `${urlData}${tenantId}/${practiceName}/appointment/activities/`
  return completeUrl
}

// export const SavePractitionerNotes = `${baseURL}Notes/${TENANTNAME}/${PRACTICENAME}/note`
export const savePractitionerNotesUrl = (account, urlData) => {
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const currentRole = JSON.parse(localStorage.getItem('UserType'))

  const tenantId = account.idTokenClaims.extension_Organization
  const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName
  const completeUrl = `${urlData}${tenantId}/${practiceName}/note`
  return completeUrl
}

export const getClientListingUrl = (account, urlData) => {
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const currentRole = JSON.parse(localStorage.getItem('UserType'))

  const tenantId = account.idTokenClaims.extension_Organization
  const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName
  const completeUrl = `${urlData}${tenantId}/${practiceName}/clients`
  return completeUrl
}
export const ClientRegistrationUrl = (account, urlData) => {
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const currentRole = JSON.parse(localStorage.getItem('UserType'))

  const tenantId = account.idTokenClaims.extension_Organization
  const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName
  const completeUrl = `${urlData}${tenantId}/${practiceName}/client`
  return completeUrl
}
export const getPractitionerListingUrl = (account, urlData) => {
  const userData = JSON.parse(localStorage.getItem('UserData'))
  const currentRole = JSON.parse(localStorage.getItem('UserType'))

  const tenantId = account.idTokenClaims.extension_Organization
  const practiceName = currentRole !== 'Coordinator' ? userData && userData.practiceName : account.idTokenClaims.extension_PracticeName
  const completeUrl = `${urlData}${tenantId}/${practiceName}/practitioners`
  return completeUrl
}

export const createProfileBaseUrl = (account, urlData) => {
  const tenantId = account.idTokenClaims.extension_Organization
  const completeUrl = `${urlData}${tenantId}/user`
  return completeUrl
}
export const createAgoraTokenUrl = (urlData) => {
  const userData = JSON.parse(localStorage.getItem('currentUser'))
  // console.log('userData::', userData)
  const tenantId = userData.extension_Organization
  const completeUrl = `${urlData}${tenantId}/agora/accessToken`
  return completeUrl
}
