import config from '../config'
// import { TENANTNAME, PRACTICENAME } from "./RegistrationInitialData";
const currentUser = JSON.parse(localStorage.getItem('currentuser'))
const TENANTNAME = currentUser && currentUser.extension_Organization
const userData = JSON.parse(localStorage.getItem('UserData'))
const currentRole = JSON.parse(localStorage.getItem('UserType'))

const PRACTICENAME = currentRole !== 'Coordinator' ? userData && userData.practiceName : currentUser && currentUser.extension_PracticeName
const baseURL = config.APP_API_URL

const CoordinatorBaseURLMain = `${baseURL}Coordinator/${TENANTNAME}/${PRACTICENAME}/`
export const CoordinatorBaseURL = `${baseURL}Coordinator/`
export const CoordinatorRegistration = `${CoordinatorBaseURLMain}coordinator`
export const ClientRegistration = `${CoordinatorBaseURLMain}client`
export const PractitionerRegistration = `${CoordinatorBaseURLMain}practitioner`
export const ClientListing = `${CoordinatorBaseURLMain}clients`
export const PractitionerListing = `${CoordinatorBaseURLMain}practitioners`

// Appointment Related API's  -
const AppointmentBaseURL = `${baseURL}Appointment/${TENANTNAME}/${PRACTICENAME}/`
export const AppointmentsCommonUrl = `${baseURL}Appointment/`

export const CreateAppointment = `${AppointmentBaseURL}appointment`
export const CoordinatorAppointments = `${AppointmentBaseURL}appointments`
export const ClientAppointments = `${baseURL}Appointment/`

// This API is used for Logging Appoinytment details on backend.
export const LoggingAppointmentsData = `${AppointmentBaseURL}appointmentdetails`

// export const CancelAppointment = `${baseURL}Appointment/${PRACTICENAME}/appointment/`

// Providers related API data
// {BaseUrl}/api/Providers/{tenantId}/{practiceName}/providers/{practitionerId}/summary
export const ProviderBaseUrl = `${baseURL}Providers/`

// Get user details
export const userDataAPI = `${baseURL}Profile/`
// Profile related::
// export const profileBaseUrl = `${baseURL}Profile/${TENANTNAME}/user`
// Library Data for Assignment Activities and Assessments
export const LibraryBaseURL = `${baseURL}Library/`

// BaseUrl/api/Videos/{tenantId}/agora/accessToken
export const getAgoraToken = `${baseURL}Videos/`

// Notes save
// export const SavePractitionerNotes = `${baseURL}Notes/${TENANTNAME}/${PRACTICENAME}/note`
export const GetPractitionerNotes = `${baseURL}Notes/`

// export const GetClientAssessmentsListing = `${baseURL}Client/${TENANTNAME}/${PRACTICENAME}/clients/`
export const ClientAssessmentsBaseUrl = `${baseURL}Client/`

// {BaseUrl}/api/Client/{tenantId}/{practiceName}/clients/{id}/wellbeingProfile?fromdate={fromdate}&todate={todate}
