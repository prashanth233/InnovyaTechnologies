// For Local Development
/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import { LogLevel } from '@azure/msal-browser'
import config from './config'

export const b2cPolicies = {
  names: {
    signUpSignIn: 'B2C_1_signupsignin1',
    forgotPassword: 'B2C_1_reset',
    editProfile: 'B2C_1_profileediting1',
    signIn: 'B2C_1_signin1',
    signInWhitelisting: 'B2C_1_test',
    clientFlow: 'B2C_1_clientflow',
    signUpSignInPractitioner: 'B2C_1_practitionersignupsignin1'

  },
  // For Dev
  authorities: {
    signUpSignIn: {
      authority: config.APP_SIGNUPSIGNIN_AUTHORITY
    },
    signIn: {
      authority: config.APP_SIGNIN_AUTHORITY
    },
    forgotPassword: {
      authority: config.APP_FORGOTPASSWORD_AUTHORITY
    },
    editProfile: {
      authority: config.APP_EDITPROFILE_AUTHORITY
    },
    clientFlow: {
      authority: config.APP_CLIENTSIGNUPSIGNIN_AUTHORITY // 'https://vitalstartdev.b2clogin.com/vitalstartdev.onmicrosoft.com/B2C_1_clientflow'
    },
    signUpSignInPractitioner: {
      authority: config.APP_PRACTSIGNUPSIGNIN_AUTHORITY // 'https://vitalstartdev.b2clogin.com/vitalstartdev.onmicrosoft.com/B2C_1_practitionersignupsignin1'
    },
    signInWhitelisting: {
      authority: 'https://vitalstartdev.b2clogin.com/vitalstartdev.onmicrosoft.com/B2C_1_test'
    }
  },
  authorityDomain: config.APP_AUTHORITY_DOMAIN
}

/**
 * Configuration object to be passed to MSAL instance on creation.
 * For a full list of MSAL.js configuration parameters, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/configuration.md
 */
export const msalConfig = {
  auth: {
    clientId: config.APP_AZURE_CLIENT_ID,
    authority: b2cPolicies.authorities.signUpSignIn.authority,
    knownAuthorities: [b2cPolicies.authorityDomain], // Mark your B2C tenant's domain as trusted.

    redirectUri: config.APP_REDIRECT_URI, // 'http://localhost:3000/dashboardpage',
    postLogoutRedirectUri: config.APP_POST_LOGOUT_REDIRECT_URI, // 'http://localhost:3000',

    navigateToLoginRequestUrl: false // If "true", will navigate back to the original request location before processing the auth code response.
  },
  cache: {
    cacheLocation: 'sessionStorage', // Configures cache location. "sessionStorage" is more secure, but "localStorage" gives you SSO between tabs.
    storeAuthStateInCookie: false // Set this to "true" if you are having issues on IE11 or Edge
  },
  system: {
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) {
          return
        }
        switch (level) {
          case LogLevel.Error:
            console.error(message)
            return
          case LogLevel.Info:
            console.info(message)
            return
          case LogLevel.Verbose:
            console.debug(message)
            return
          case LogLevel.Warning:
            console.warn(message)
        }
      }
    }
  }
}

/**
 * Add here the endpoints and scopes when obtaining an access token for protected web APIs. For more information, see:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/resources-and-scopes.md
 */
// For dev
export const protectedResources = {
  apiHello: {
    endpoint: config.APP_PROTECTED_RESOURCE_ENDPOINT, // 'https://vitalstartdev.onmicrosoft.com/68bd6fec-7182-4f38-b6ad-ab1976af020a/',
    scopes: [config.APP_PROTECTED_RESOURCE_SCOPES]
  }
}

/**
 * Scopes you add here will be prompted for user consent during sign-in.
 * By default, MSAL.js will add OIDC scopes (openid, profile, email) to any login request.
 * For more information about OIDC scopes, visit:
 * https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-permissions-and-consent#openid-connect-scopes
 */
export const loginRequest = {
  scopes: [...protectedResources.apiHello.scopes]
}
