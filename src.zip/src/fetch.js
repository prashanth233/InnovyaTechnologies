
export const callApiWithToken = async () => {

}

export const callApiForRegistration = async (apiEndpoint, withValues) => {
  const token = JSON.parse(localStorage.getItem('idToken'))
  const bearer = `Bearer ${token}`
  const headers = new Headers({
    // "Content-Type": "multipart/form-data"
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache',
    Authorization: bearer
  })
  const options = {
    method: 'POST',
    headers: headers,
    mode: 'cors',
    body: JSON.stringify(withValues)
  }

  return fetch(apiEndpoint, options)
    .then(async (response) => {
      // console.log("Fetch Res:", response);
      // if(response.status === 400){
      const text = await response.text()
      // // console.log("Text data",text.split(" ").indexOf("userPrincipalName"));
      // console.log("Text data", text.split(" "));
      return text
      // }
      // return response.json()
    })
    .catch(error => console.log('Fetch call error', error))
}
export const callApiForCoordinatorRegistration = async (apiEndpoint, withValues) => {
  const token = JSON.parse(localStorage.getItem('idToken'))
  const bearer = `Bearer ${token}`
  const headers = new Headers({
    // "Content-Type": "multipart/form-data"
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache',
    Authorization: bearer
  })
  const options = {
    method: 'POST',
    headers: headers,
    mode: 'cors',
    body: JSON.stringify(withValues)
  }

  return fetch(apiEndpoint, options)
    .then(async (response) => {
      // console.log("Fetch Res:", response);
      if (response.status !== 200) {
        const text = await response.text()
        // // console.log("Text data",text.split(" ").indexOf("userPrincipalName"));
        // console.log("Text data", text.split(" "));
        return text
      }
      return response.json()
    })
    .catch(error => console.log('Fetch call error', error))
}
export const callApiForUpdate = async (apiEndpoint, withValues) => {
  const token = JSON.parse(localStorage.getItem('idToken'))
  const bearer = `Bearer ${token}`

  const headers = new Headers({
    // "Content-Type": "multipart/form-data"
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache',
    Authorization: bearer
  })
  const options = {
    method: 'POST',
    headers: headers,
    mode: 'cors',
    body: JSON.stringify(withValues)
  }

  return fetch(apiEndpoint, options)
    .then(async (response) => {
      // console.log("Fetch Res:", response);
      if (response.status === 400) {
        const text = await response.text()
        // // console.log("Text data",text.split(" ").indexOf("userPrincipalName"));
        // console.log("Text data", text.split(" "));
        return text
      }
      return response.json()
    })
    .catch(error => console.log('Fetch call error', error))
}
export const callApiForActivityStatus = async (apiEndpoint, withValues) => {
  const token = JSON.parse(localStorage.getItem('idToken'))
  const bearer = `Bearer ${token}`

  const headers = new Headers({
    // "Content-Type": "multipart/form-data"
    'Content-Type': 'application/json',
    Authorization: bearer
  })
  const options = {
    method: 'PUT',
    headers: headers,
    mode: 'cors',
    body: JSON.stringify(withValues)
  }

  return fetch(apiEndpoint, options)
    .then(async (response) => {
      // console.log("Fetch Res:", response);
      if (response.status === 400) {
        const text = await response.text()
        // // console.log("Text data",text.split(" ").indexOf("userPrincipalName"));
        // console.log("Text data", text.split(" "));
        return text
      }
      return response.json()
    })
    .catch(error => console.log('Fetch call error', error))
}

export const callApiForListing = async (apiEndpoint) => {
  const token = JSON.parse(localStorage.getItem('idToken'))
  const bearer = `Bearer ${token}`

  const headers = new Headers({
    // "Content-Type": "multipart/form-data"
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache',
    Authorization: bearer
  })
  const options = {
    method: 'GET',
    headers: headers,
    mode: 'cors'
    // body: JSON.stringify(commonAPIData)
  }

  return fetch(apiEndpoint, options)
    .then(async (response) => {
      // console.log("Fetch Res:", response);
      if (response.status === 400) {
        const text = await response.text()
        // // console.log("Text data",text.split(" ").indexOf("userPrincipalName"));
        // console.log("Text data", JSON.stringify(text.split(" ")));
        return text

        // return text.split(" ");
      }
      return response.json()
    })
    .catch(error => console.log('Fetch call error', error))
}
export const callApiForProfile = async (apiEndpoint, userId, userType) => {
  // id=${userId}&userType=client`
  const token = JSON.parse(localStorage.getItem('idToken'))
  const bearer = `Bearer ${token}`

  // headers.append("Authorization", bearer);
  const completeUrl = `${apiEndpoint}?id=${userId}&userType=${userType}`
  const headers = new Headers({
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache',
    Authorization: bearer
  })
  const options = {
    method: 'GET',
    headers: headers,
    mode: 'cors'
  }

  return fetch(completeUrl, options)
    .then(async (response) => {
      // console.log("Fetch Res:", response);
      if (response.status === 400) {
        const text = await response.text()
        // // console.log("Text data",text.split(" ").indexOf("userPrincipalName"));
        // console.log("Text data", JSON.stringify(text.split(" ")));
        return text

        // return text.split(" ");
      }
      return response.json()
    })
    .catch(error => console.log('Fetch call error', error))
}
