const config = window.MyConfig

export default config
