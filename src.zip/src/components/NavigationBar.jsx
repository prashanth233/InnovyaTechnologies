/* eslint-disable no-dupe-keys */
/* eslint-disable multiline-ternary */
/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
/* eslint-disable react/display-name */
import React, { useRef, useState } from 'react'
import { BrowserView, MobileView, isMobile } from 'react-device-detect'
import { AuthenticatedTemplate, useAccount, useMsal } from '@azure/msal-react'
import { withRouter } from 'react-router-dom'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import {
  Nav,
  Navbar,
  Col,
  Row,
  Dropdown,
  OverlayTrigger,
  Form,
  Popover
} from 'react-bootstrap'
import {
  ClientRole,
  PractitionerRole,
  CoordinatorRole
} from '../CommonData/StaticData'
// import logoImg from "../Assets/Nav-Logo.png";
import VitalLogo from '../Assets/Vitallogo.png'
import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import loaderImg from '../Assets/spp.gif'
import '../Home/Landing.css'
import { Avatar } from '@mui/material'
import ClientNavigation from './ClientNavigation'
import { b2cPolicies } from '../authConfig'
import { createProfileBaseUrl } from '../CommonData/CreateAPIUrl'
import { userDataAPI } from '../CommonData/APIListing'
import { callApiForRegistration } from '../fetch'
import { Pages } from '@material-ui/icons'
import { ClientAppointmentsListing } from '../pages/ClientAppointmentsListing'

const NavigationBar = (props) => {
  const { location } = props
  const profilePhoto = useRef(null)
  const [isLoading, setLoading] = useState(false)
  const [imgFile, setImgFile] = useState(ProfilePlaceholder)
  const { instance, accounts } = useMsal()
  const currentRole = JSON.parse(localStorage.getItem('UserType'))
  // const isMobile = useIsMobile()
  // console.log("Is mObile check::", isMobile);
  const account = useAccount(accounts[0] || {})
  //   const history = useHistory()

  const [dimensions, setDimensions] = React.useState({
    width: window.innerWidth
  })
  React.useEffect(() => {
    function handleResize () {
      setDimensions({
        width: window.innerWidth
      })
    }
    window.addEventListener('resize', handleResize)
    return (_) => {
      window.removeEventListener('resize', handleResize)
    }
  }, [window.innerWidth])

  let navItemsArr = []
  //   let imageName = ''
  switch (currentRole) {
    case 'Client':
      navItemsArr = ClientRole
      //   setImgFile(patImg)
      // imageName = patImg
      break
    case 'Practitioner':
      navItemsArr = PractitionerRole
      //   setImgFile(pracImg)

      // imageName = pracImg
      break
    case 'Coordinator':
      navItemsArr = CoordinatorRole
      //   setImgFile(coordImg)

      // imageName = coordImg
      break
    default:
      break
  }
  // console.log("Nav Arr values::", navItemsArr);
  const CustomToggle = React.forwardRef(({ children, onClick }, ref) => (
    <div
      href=""
      ref={ref}
      onClick={(e) => {
        e.preventDefault()
        onClick(e)
      }}
    >
      {/* Render custom icon here */}
      {/* &#x25bc; */}
      {children}
      <ExpandMoreIcon style={{ paddingLeft: '0.625rem', width: '3.125rem' }} />
    </div>
  ))

  const popover = (
    <Popover id="popover-basic" style={{ maxWidth: '30vw' }}>
      {/* <Popover.Title as="h3">For Help, contact us on</Popover.Title> */}
      <Popover.Title as="h3">Please follow below instructions</Popover.Title>
      <Popover.Content>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>
              1. To start your meeting, click <strong>JOIN</strong> next to your
              appointment time.
            </Form.Label>
          </Form.Group>
        </Row>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>
              2. Ensure you have good connectivity in order to view and hear
              the media during your session.
            </Form.Label>
          </Form.Group>
        </Row>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>
              3. If you are enrolled as a Client and are using the VR experience, make sure your mobile
              device is able to move from vertical to horizontal viewing. Turn
              horizontally to view in full screen, then click on the VR icon
              prior to inserting the goggles onto your device.{' '}
            </Form.Label>
          </Form.Group>
        </Row>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>
              4. Complete any assessments assigned to you prior to your session
              for personalized care.
            </Form.Label>
          </Form.Group>
        </Row>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>
              5. If you are a Practitioner and need further help on scheduling or media,  reach out to your Care Coordinator for support.
            </Form.Label>
          </Form.Group>
        </Row>
        <div style={{ background: 'linear-gradient(#E9E9E9, #FFFFFF)', height: '6px', position: 'relative', bottom: '5px' }}> </div>
        <Row>
          <Form.Group as={Col} controlId="validationCustom01">
            <Form.Label style={{ fontFamily: 'Roboto', fontSize: '1rem' }}>
              For help or further support, email or contact us at:
            </Form.Label>
            <br />
            <Form.Label
              style={{
                fontFamily: 'Roboto',
                fontSize: '1rem',
                color: '#F24B5D',
                marginTop: '-20px'
              }}
            >
              <a href="mailto: support@vitalstarthealth.com">
                support@vitalstarthealth.com
              </a>
            </Form.Label>
            <br />
            <Form.Label
              style={{
                fontFamily: 'Roboto',
                fontSize: '1rem',
                color: '#F24B5D',
                marginTop: '-20px'
              }}
            >
              <a href="tel:12679461850">1-267-946-1850</a>
            </Form.Label>
          </Form.Group>

          {/* <Form.Group as={Col} controlId="validationCustom01">
                        <Form.Label style={{ marginLeft: '-7vw', color: '#F24B5D', fontFamily: 'Roboto', fontSize: '1.125rem' }}>Vital Start Health</Form.Label>
                    </Form.Group> */}
        </Row>
        {/* <Form.Group as={Col} controlId="validationCustom01"> */}

        {/* </Form.Group> */}
        {/* <Form.Group as={Col} controlId="validationCustom01">
                        <Form.Label style={{ marginLeft: '-1vw', color: '#F24B5D', fontFamily: 'Roboto', fontSize: '1.125rem' }}>contact@vitalstarthealth.com</Form.Label>
                    </Form.Group> */}
      </Popover.Content>
    </Popover>
  )

  // This method used to change the Profile Pic of the user
  const handleFileChange = (event) => {
    const file = event.target.files[0]
    // console.log('handleFileChange', event.target, file)
    if (file) {
      const reader = new FileReader()
      setLoading(true)

      reader.onload = () => {
        // console.log('Img data::', reader.result)
        setImgFile(reader.result)
        saveUserPhotoData(reader.result)
      }
      reader.readAsDataURL(file)
    }
  }

  //
  // const userName = account && `${account.name} Khadgi`
  let userName = ''
  const userData = JSON.parse(localStorage.getItem('UserData'))
  userName = userData && `${userData.firstName} ${userData.lastName}`

  // This method is for user's Photo Change
  const saveUserPhotoData = (imageData) => {
    setLoading(true)
    let saveData = {
      id: userData.id,
      firstName: '',
      middleName: '',
      lastName: '',
      email: '',
      mobileNo: '',
      address: '',
      city: '',
      state: '',
      zip: '',
      photoId: imageData,
      userName: '',
      languagePreference: '',
      referralPracticeName: ''
    }

    if (currentRole === 'Practitioner') {
      delete saveData.languagePreference
      delete saveData.referralPracticeName
      delete saveData.id

      saveData = {
        ...saveData,
        consultationRate: '',
        practiceName: '',
        practitionerId: userData.id
      }
    }
    if (currentRole === 'Coordinator') {
      delete saveData.languagePreference
      delete saveData.referralPracticeName

      saveData = {
        ...saveData,
        employeeId: '',
        email: ''
      }
    }

    // console.log('saveData Resp:-', saveData)
    const profileUrl = `${createProfileBaseUrl(
      account,
      userDataAPI
    )}/${currentRole.toLowerCase()}/${userData.id}`

    // const reqUrl = `${profileBaseUrl}/${currentRole.toLowerCase()}/${registrationData.id}`

    callApiForRegistration(profileUrl, saveData)
      .then((response) => {
        // console.log('Update profile API Resp:-', response)
        if (
          response &&
          response === `${currentRole} Photo Updated Successfully`
        ) {
          const userPhotodata = {
            ...userData,
            photo: imageData
          }
          localStorage.setItem('UserData', JSON.stringify(userPhotodata))
          setLoading(false)
        } else {
          setLoading(false)
        }
      })
      .catch((error) => console.log('API Catch eror main class', error))
  }

  // This method id used to call on Logo click to Log Out user and navigate to Landing page with 3 personas as per discussion
  const onLogoClickHandle = () => {
    localStorage.clear()
    instance.logoutRedirect({ postLogoutRedirectUri: '/' })
  }

  return (
    <>
      <Navbar bg="white" style={{ height: '5rem' }}>
        <AuthenticatedTemplate>
          <Col xs={currentRole === 'Client' ? 3 : 4}>
            <img
              style={{
                width: '135px',
                height: '81.21px',
                position: 'relative',
                top: '20px'
              }}
              src={VitalLogo}
              onClick={onLogoClickHandle}
            />
          </Col>
          <Col xs={4.5}>
            <div
              style={{
                paddingTop: '7px',
                paddingLeft: '0.5rem',
                paddingBottom: '0.5rem',
                border: '1px solid #EEEEEE',
                height: '61px',
                position: 'relative',
                top: '1rem',
                backgroundColor: '#F8F8F8',
                borderRadius: '5px',
                left: '25px'
                // boxShadow: "0px -1px 4px rgba(0, 0, 0, 0.05), 0px 4px 4px rgba(0, 0, 0, 0.1)"
              }}
            >
              <Nav
                activeKey={location.pathname}
                style={{ position: 'relative' }}
              >
                {navItemsArr.map((objLink, i) => {
                  const pathData = location.pathname.slice().split(':')[0]
                  const backgroundColor =
                    pathData === objLink.link ? '#FFE3E4' : 'none'
                  const linkItemColor =
                    pathData === objLink.link ? '#2D2D34' : '#A0A6B1'
                  const boxShadow =
                    pathData === objLink.link ? '0px -1px 4px rgba(0, 0, 0, 0.05), 0px 4px 4px rgba(0, 0, 0, 0.1)' : 'none'
                  return (
                    <Nav.Link
                      key={i}
                      style={{
                        marginRight: '10px',
                        color: linkItemColor,
                        padding: '0 1.25rem',
                        fontFamily: 'Roboto, Regular',
                        fontSize: '1.125rem',
                        fontWeight: '455',
                        backgroundColor: backgroundColor,
                        boxShadow: boxShadow,
                        // eslint-disable-next-line no-dupe-keys
                        padding: '22px 20px',
                        height: '0.5rem',
                        borderRadius: '6px',
                        position: 'relative',
                        display: 'flex',
                        alignItems: 'center',
                        letterspacing: '0.01em'
                        // boxShadow: '0px -1px 4px rgba(0, 0, 0, 0.05), 0px 4px 4px rgba(0, 0, 0, 0.1)'
                      }}
                      href={objLink.link}
                    >
                      {objLink.text}
                    </Nav.Link>
                  )
                })}
              </Nav>
            </div>
          </Col>
          <Col>
            <Row className="justify-content-end">
              <Col xs={3.5}>
                <OverlayTrigger
                  trigger="click"
                  placement="bottom"
                  overlay={popover}
                  rootClose
                >
                  {/* <div style={{border:"2px solid black",padding:"0.5rem",height:"40px",borderRadius:"5px",justifyContent:"center",display:"flex",alignItems:"center"}}> */}
                  <Nav.Link
                    style={{
                      color: '#314C76',
                      fontFamily: 'Roboto, Regular',
                      // fontSize: "1.063rem",
                      // paddingTop: "0.938rem",
                      // marginLeft: "1.875rem",
                      border: '1.5px solid #EEEEEE',
                      padding: '0.5rem',
                      height: '35px',
                      borderRadius: '7px',
                      justifyContent: 'center',
                      display: 'flex',
                      alignItems: 'center',
                      position: 'relative',
                      top: '20px',
                      right: '12px',
                      backgroundColor: '#F8F8F8',
                      lineHeight: '19px',
                      width: '57px',
                      fontWeight: '400'
                    }}
                    href=""
                  >
                    Help
                  </Nav.Link>
                </OverlayTrigger>
              </Col>
              <Col xs={1.5}>
                {!window.navigator.userAgent.includes('Macintosh') &&
                  dimensions.width > 1164 && (
                    <div>
                      <BrowserView>
                        <Avatar
                          src={
                            isLoading
                              ? loaderImg
                              : userData && userData.photo !== ''
                                ? userData.photo
                                : imgFile
                          }
                          sx={{
                            width: '3.125rem',
                            height: '3.125rem',
                            top: '0.625rem',
                            justifyContent: 'center',
                            alignItems: 'center',
                            objectFit: 'scale-down'
                          }}
                        />
                      </BrowserView>
                    </div>
                )}
              </Col>
              <Col xs={3.5}>
                {(window.navigator.userAgent.includes('Macintosh') &&
                  isMobile) ||
                dimensions.width < 1164 ? (
                  <ClientNavigation
                    msalInstance={instance}
                    userName={userName}
                    userAccount={account}
                  />
                    ) : (
                  <>
                    <BrowserView>
                      <div>
                        <label
                          variant="info"
                          style={{
                            fontFamily: 'Roboto',
                            fontSize: '12px',
                            position: 'relative',
                            top: '10px',
                            left: '10px',
                            lineHeight: '14px',
                            fontWeight: '400'
                          }}
                        >
                          Welcome
                        </label>

                        <Dropdown
                          style={{
                            fontFamily: 'Roboto',
                            fontSize: '14px',
                            position: 'relative',
                            fontWeight: '400',
                            left: '10px'
                          }}
                        >
                          <Dropdown.Toggle
                            as={CustomToggle}
                            id="dropdown-custom-components"
                          >
                            {userName}
                          </Dropdown.Toggle>
                          <Dropdown.Menu size="sm">
                            <Dropdown.Item
                              as="button"
                              style={{
                                color: '#838080',
                                fontWeight: '400',
                                fontSize: '14px',
                                fontWeight: '400'
                              }}
                              onClick={() =>
                                instance.loginRedirect(
                                  b2cPolicies.authorities.editProfile
                                )
                              }
                            >
                              PROFILE
                            </Dropdown.Item>
                            <Dropdown.Item
                              as="button"
                              style={{
                                color: '#838080',
                                fontWeight: '400',
                                fontSize: '14px',
                                fontWeight: '400'
                              }}
                              onClick={() => profilePhoto.current.click()}
                            >
                              CHANGE PHOTO
                            </Dropdown.Item>
                            <input
                              id="photoId"
                              ref={profilePhoto}
                              type="file"
                              style={{ display: 'none' }}
                              accept="image/*"
                              onChange={handleFileChange}
                            />
                            <Dropdown.Item
                              as="button"
                              style={{
                                color: '#838080',
                                fontWeight: '400',
                                fontSize: '14px',
                                fontWeight: '400'
                              }}
                              onClick={() => {
                                localStorage.clear()
                                instance.logoutRedirect({
                                  postLogoutRedirectUri: '/'
                                })
                              }}
                            >
                              LOGOUT
                            </Dropdown.Item>
                          </Dropdown.Menu>
                        </Dropdown>
                      </div>
                    </BrowserView>
                    <MobileView>
                      <ClientNavigation
                        msalInstance={instance}
                        userName={userName}
                        userAccount={account}
                      />
                    </MobileView>
                  </>
                    )}
              </Col>
            </Row>
          </Col>
        </AuthenticatedTemplate>
      </Navbar>

      <div style={{ width: '100%', height: '30px' }}>
      </div>
    </>
  )
}

export default withRouter(NavigationBar)
