/* eslint-disable react/jsx-key */
import React from 'react'
import { useTable, useFilters, useSortBy, usePagination } from 'react-table'
import PropTypes from 'prop-types'
import { fourteenPx, twelvePxTable } from '../CommonData/Data'
import '../styles/App.css'
// export default function Table({ columns, data }) {
// const [filterInput, setFilterInput] = useState("");
// Use the state and functions returned from useTable to build your UI
export const TableComponent = ({
  columns,
  data,
  onRowClicked,
  showHeader,
  tableWidth
}) => {
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    prepareRow,
    page, // Instead of using 'rows', we'll use page,
    // which has only the rows for the active page

    // The rest of these things are super handy, too ;)
    canPreviousPage,
    canNextPage,
    pageOptions,
    // pageCount,
    // gotoPage,
    nextPage,
    previousPage,
    // setPageSize,
    state: { pageIndex, pageSize }
    // setFilter
  } = useTable(
    {
      columns,
      data,
      initialState: { pageIndex: 0, pageSize: 5 }
    },
    useFilters,
    useSortBy,
    usePagination
  )

  // Render the UI for your table
  return (
    <>
      <div>
        <div
          style={{
            position: 'relative',
            bottom: '5px',

            fontSize: fourteenPx,
            display: 'flex',
            justifyContent: 'flex-end'

          }}
        >
          <span>
            Showing :{' '}
            <strong>
              {pageIndex * pageSize + 1}
              {' - '}{' '}
              {pageIndex + 1 === pageOptions.length
                ? data.length
                : (pageIndex + 1) * pageSize}
            </strong>{' '}
            results of <strong> {data.length}</strong>{' '}
            {/* <input
            type="number"
            defaultValue={pageIndex + 1}
            onChange={e => {
              const page = e.target.value ? Number(e.target.value) - 1 : 0
              gotoPage(page)
            }}
            style={{ width: '100px' }}
          /> */}
          </span>{' '}
        </div>
        <table {...getTableProps()} style={{ width: tableWidth }}>
          {showHeader && (
            <thead
              style={{
                fontFamily: 'Roboto, Regular',
                fontSize: twelvePxTable,
                position: 'relative',
                height: '10px'
              }}
            >
              {headerGroups.map((headerGroup) => (
                <tr
                  {...headerGroup.getHeaderGroupProps()}
                  style={{ backgroundColor: '#FFE3E4', height: '55px' }}
                >
                  {headerGroup.headers.map((column) => (
                    <th
                      {...column.getHeaderProps(column.getSortByToggleProps())}
                      className={
                        column.isSorted
                          ? column.isSortedDesc
                            ? 'sort-desc'
                            : 'sort-asc'
                          : column.disableSortBy
                            ? ''
                            : 'sort-show'
                      }
                    >
                      {column.render('Header')}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
          )}
          <tbody {...getTableBodyProps()}>
            {page.map((row, i) => {
              prepareRow(row)
              return (
                <tr
                  {...row.getRowProps({
                    onClick: (e) => onRowClicked(row, e)
                  })}
                >
                  {row.cells.map((cell) => {
                    return (
                      <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                    )
                  })}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      <div
        style={{
          textAlign: 'center',
          fontSize: fourteenPx,
          marginTop: '20px'
        }}
      >
        {/* <button onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
          {'<<'}
        </button>{' '} */}
        <button
          onClick={() => previousPage()}
          disabled={!canPreviousPage}
          style={{
            border: '1px solid #314C76',
            backgroundColor: '#FFFFFF',
            borderRadius: '5px',
            color: '#314C76',
            marginRight: '11px'
          }}
        >
          {'<'}
        </button>{' '}
        <span>
          Page{' '}
          <strong>
            {pageIndex + 1} of {pageOptions.length}
          </strong>
          <button
            onClick={() => nextPage()}
            disabled={!canNextPage}
            style={{
              border: '1px solid #314C76',
              backgroundColor: '#FFFFFF',
              borderRadius: '5px',
              color: '#314C76',
              marginLeft: '11px'
            }}
          >
            {'>'}
          </button>{' '}
        </span>
        {/* <button onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
          {'>>'}
        </button>{' '} */}
        {/* <select
          value={pageSize}
          onChange={e => {
            setPageSize(Number(e.target.value))
          }}
        >
          {[5, 10, 15, 20].map(pageSize => (
            <option key={pageSize} value={pageSize}>
              Show {pageSize}
            </option>
          ))}
        </select> */}
      </div>

    </>
  )
}

TableComponent.propTypes = {
  showHeader: PropTypes.bool,
  tableWidth: PropTypes.string,
  columns: PropTypes.array,
  data: PropTypes.array,
  onRowClicked: PropTypes.func.isRequired
}
