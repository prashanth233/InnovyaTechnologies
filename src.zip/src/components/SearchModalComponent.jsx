import React from 'react'
import IconButton from '@material-ui/core/IconButton'
import InputAdornment from '@material-ui/core/InputAdornment'
import { TextField } from '@material-ui/core'
import SearchIcon from '@material-ui/icons/Search'
import ClearIcon from '@material-ui/icons/Clear'
// import FilterListIcon from '@mui/icons-material/FilterList'
import FilterImg from '../Assets/Filter.png'
import '../styles/App.css'
import PropTypes from 'prop-types'
// import Popover from '@mui/material/Popover'
// import Typography from '@mui/material/Typography'
import { Button } from 'react-bootstrap'
import { Menu, MenuItem, Tooltip } from '@mui/material'

function SearchModalComponent (props) {
  // const optionsArr = [{ name: 'Name', key: 'keyName' }, { name: 'Data', key: 'keyName2' }, { name: 'New Data', key: 'keyName3' }]
  const [anchorEl, setAnchorEl] = React.useState(null)

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const open = Boolean(anchorEl)
  // const id = open ? 'simple-popover' : undefined

  return (
    <>
      <div style={{ padding: '10px', display: 'flex' }}>
        <TextField
          // label="With normal TextField"
          variant='outlined'
          size='small'
          value={props.searchValue}
          onChange={props.onSearchClick}
          sx={{
            htmlColor: 'white'
          }}
          placeholder='Search'
          InputProps={{
            startAdornment: (
              <InputAdornment position="start" style={{ marginLeft: '-20px', marginRight: '-10px' }}>
                <IconButton>
                  <SearchIcon id="search" htmlColor='#F24B5D' style={{ width: '20px' }} />
                </IconButton>
              </InputAdornment>
            ),
            endAdornment: (
              <InputAdornment position="end" style={{ marginRight: '-20px' }}>
                <IconButton id="clear" style={{ size: 'small' }} onClick={props.onSearchClick}>
                  <ClearIcon id="clear" style={{ width: '15px' }} onClick={props.onSearchClick} />
                </IconButton>
              </InputAdornment>
            )
          }}
        />
        <Tooltip title="">

          <TextField
            // label="With normal TextField"
            variant='outlined'
            size='small'
            value={props.filterName}
            disabled
            // onChange={props.onSearchClick}
            sx={{
              htmlColor: 'white'
            }}
            style={{ width: 120 }}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end" style={{ marginRight: '-20px' }}>
                  <IconButton id="filter" style={{ size: 'small' }} onClick={handleClick}>
                    <img id="filter" src={FilterImg} style={{ width: '24px', height: '24px' }} />
                  </IconButton>
                </InputAdornment>
              )
            }}
          />
        </Tooltip>
        <Menu
          anchorEl={anchorEl}
          id="account-menu"
          open={open}
          onClose={handleClose}
          onClick={handleClose}
          PaperProps={{
            elevation: 0,
            sx: {
              overflow: 'visible',
              filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
              mt: 1.5,
              '& .MuiAvatar-root': {
                width: 32,
                height: 32,
                ml: -0.5,
                mr: 1
              },
              '&:before': {
                content: '""',
                display: 'block',
                position: 'absolute',
                top: 0,
                right: 14,
                width: 10,
                height: 10,
                bgcolor: 'background.paper',
                transform: 'translateY(-50%) rotate(45deg)',
                zIndex: 0
              }
            }
          }}
          transformOrigin={{ horizontal: 'right', vertical: 'top' }}
          anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
        >

          {
            props.filterArr.map((data, index) =>
              <div key={index} style={{ alignContent: 'center', textAlign: 'center', width: 150 }}>
                <MenuItem>

                  <Button key={index} variant="white" id={data.key} name={data.name} style={{ backgroundColor: 'white', color: '#F24B5D', border: '0px', outline: 'none' }} onClick={props.handleFilterChange}>{data.name}</Button>
                </MenuItem>

              </div>
            )
          }
          {/* <MenuItem>
          <Button variant="danger" style={{ backgroundColor: 'white', color: '#F24B5D', border: 'none' }} onClick={() => {
            localStorage.clear()
            msalInstance.logoutRedirect({ postLogoutRedirectUri: '/' })
          }} >LOGOUT</Button>
        </MenuItem> */}
        </Menu>
        {/* <Popover
        sx={{ ml: -3 }}
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center'
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'center'
        }}
      >
        {
              props.filterArr.map((data, index) =>
              <div key={index} style={{ alignContent: 'center', textAlign: 'center', width: 150 }}>
                <Button key={index} variant="white" id={data.key} name={data.name} style={{ backgroundColor: 'white', color: '#F24B5D', border: '0px', outline: 'none' }} onClick={props.handleFilterChange}>{data.name}</Button>
              </div>
              )
            }
      </Popover> */}

    </div>
    </>
  )
}
// anchorOrigin={{
//   vertical: 'bottom',
//   horizontal: 'left'
// }}
// transformOrigin={{
//   vertical: 'top',
//   horizontal: 'left'
// }}
export default SearchModalComponent

SearchModalComponent.propTypes = {
  searchValue: PropTypes.string,
  filterName: PropTypes.string,
  handleFilterChange: PropTypes.func.isRequired,
  onSearchClick: PropTypes.func.isRequired,
  filterArr: PropTypes.array
}
