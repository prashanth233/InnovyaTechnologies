/* eslint-disable multiline-ternary */
/* eslint-disable no-unused-vars */
import React, { useState } from 'react'
import { Avatar } from '@mui/material'
import editIcon from '../Assets/edit.png'
import deleteIcon from '../Assets/delete.png'
import detailsIcon from '../Assets/details.png'
import IconButton from '@material-ui/core/IconButton'
import PropTypes from 'prop-types'
import { fourteenPx, tenPx } from '../CommonData/Data'
import { showJoinOption } from '../CommonData/CommonFunction'
// import config from '../config'
import '../styles/App.css'
// import { useHistory } from 'react-router-dom'

export const AssignmentsCell = ({ values }) => {
  // let history = useHistory('')
  const [isHover, setIsHover] = useState(false)

  const handleMouseEnter = () => {
    setIsHover(true)
  }

  const handleMouseLeave = () => {
    setIsHover(false)
  }

  const boxStyle = {
    backgroundColor: isHover ? 'red' : 'black'
  }
  return (
    <>
      <div
        style={{ color: 'gray', fontFamily: 'Roboto, Regular', fontSize: 14 }}
      >
        <button
          type="IconButton"
          id="activities"
          style={{ color: '#F24B5D', border: 'none', background: 'none' }}
        >
          View
        </button>
        {/*  Assessments link is redundant
        <span> | </span>
        <button type="IconButton" id="assessments" style={{ color: '#F24B5D', border: 'none', background: 'none' }} >Assessments</button>
*/}
      </div>
    </>
  )
}
AssignmentsCell.propTypes = {
  values: PropTypes.string
}

export const ActionsCell = ({ values }) => {
  return (
    <>
      <div style={{ display: 'flex', fontSize: 5 }}>
        <IconButton
          id="edit"
          style={{ size: 'small' }}
          disabled={values !== 'Scheduled'}
        >
          <img
            id="edit"
            src={editIcon}
            style={{ width: '20px', height: '20px' }}
            className={values !== 'Scheduled' ? 'imageDisable' : 'imageEnable'}
          />
        </IconButton>
        <IconButton
          id="cancel"
          style={{ size: 'small' }}
          disabled={values !== 'Scheduled'}
        >
          <img
            id="cancel"
            src={deleteIcon}
            style={{ width: '20px', height: '20px' }}
            className={values !== 'Scheduled' ? 'imageDisable' : 'imageEnable'}
          />
        </IconButton>
        <IconButton
          id="details"
          style={{ size: 'small' }}
          disabled={values === 'Cancelled'}
        >
          <img
            id="details"
            src={detailsIcon}
            style={{ width: '20px', height: '20px' }}
          />
        </IconButton>
      </div>
    </>
  )
}
ActionsCell.propTypes = {
  values: PropTypes.string
}

export const PatientActionsCell = ({ values }) => {
  const startDate = values.split(';')[0]
  const endDate = values.split(';')[1]
  const status = values.split(';')[2]
  const showJoin = showJoinOption(startDate, endDate)

  const showJoinButton = showJoin && status === 'Scheduled'
  const disableJoinButton = status === 'Cancelled'

  // console.log('meetingdatetimestatus Status::', values, showJoin, showJoinButton)
  return (
    <>
      <div style={{ color: 'gray' }}>
        {showJoinButton ? (
          <>
            <button
              id="join"
              style={{
                fontFamily: 'Roboto, Regular',
                fontSize: fourteenPx,
                color: 'white',
                background: '#F24B5D',
                border: 'none',
                borderRadius: '5px',
                height: 35,
                width: 70
              }}
            >
              JOIN
            </button>
          </>
        ) : (
          <>
            <button
             id="view"
              style={{
                // fontFamily: "Roboto, Regular",
                // fontSize: fourteenPx,
                // color: "#314C76",
                //  background: disableJoinButton ? "gray" : "#FFFFFF",
                // border: "1.5px solid #314C76",
                // borderRadius: "7px",
                // height: 32,
                // width: 62,
              }}
              disabled={disableJoinButton}

            >
             View
            </button>
          </>
        )}
      </div>
    </>
  )
}
PatientActionsCell.propTypes = {
  values: PropTypes.string
}

export const AssignActionsCell = ({ values }) => {
  return (
    <>
      <span style={{ color: 'gray' }}>
        <button
          id={values}
          style={{
            fontFamily: 'Roboto, Regular',
            fontSize: '14px',
            color: values === 'ASSIGN' ? 'white' : '#F24B5D',
            background: values === 'ASSIGN' ? '#F24B5D' : 'none',
            border: 'none',
            borderRadius: '5px',
            height: 35,
            float: 'right',
            marginRight: 10
          }}
        >
          {values}
        </button>
      </span>
    </>
  )
}
AssignActionsCell.propTypes = {
  values: PropTypes.string
}
export const AssignAssessmentsActionsCell = ({ values }) => {
  return (
    <>
      <span style={{ color: 'gray' }}>
        <button
          id={values}
          style={{
            fontFamily: 'Roboto, Regular',
            fontSize: '14px',
            color: values === 'ASSIGN' ? 'white' : '#F24B5D',
            background: values === 'ASSIGN' ? '#F24B5D' : 'none',
            border: 'none',
            borderRadius: '5px',
            height: 35,
            marginRight: 10
          }}
        >
          {values}
        </button>
      </span>
    </>
  )
}
AssignAssessmentsActionsCell.propTypes = {
  values: PropTypes.string
}

export const AssessmentsCell = ({ values }) => {
  const statusData = values && values.split(';')[0]
  const countData = values && values.split(';')[1]
  return (
    <>
      {statusData.toLowerCase() === 'assign'
        ? (
        <button
          type="link"
          style={{ color: '#F24B5D', border: 'none', background: 'none' }}
        >
          REMOVE
        </button>
          )
        : (
        <div
          style={{
            display: 'flex',
            color: statusData === 'Done' ? '#7EC0B7' : '#F86A79',
            fontFamily: 'Roboto, Regular',
            fontSize: fourteenPx
          }}
        >
          <Avatar
            sx={{
              marginRight: 1,
              width: '20px',
              height: '20px',
              border: '5px white',
              bgcolor: statusData === 'Done' ? '#7EC0B7' : '#F86A79',
              fontSize: tenPx
            }}
          >
            {statusData === 'Done' ? '✔' : countData}
          </Avatar>{' '}
          <span> </span>
          {statusData}
        </div>
          )}
    </>
  )
}
AssessmentsCell.propTypes = {
  values: PropTypes.string
}

export const AppointmentSummaryCell = ({ values }) => {
  const status = values && values.split(';')[0]
  const typeData = values && values.split(';')[1]
  return (
    <>
      {typeData.toLowerCase() === 'video' ||
      typeData.toLowerCase() === 'audio'
        ? (
        <button
          type="link"
          style={{ color: '#F24B5D', border: 'none', background: 'none' }}
        >
          REMOVE
        </button>
          )
        : (
        <div
          style={{
            display: 'flex',
            color: status === 'ASSIGN' ? '#F24B5D' : '#4C927E',
            fontFamily: 'Roboto, Regular',
            fontSize: 14
          }}
        >
          <Avatar
            sx={{
              marginRight: 1,
              width: '24px',
              height: '24px',
              border: '5px double white',
              bgcolor: status === 'ASSIGN' ? '#6A6A6A' : '#4C927E',
              fontSize: 10
            }}
          >
            {status === 'ASSIGN' ? '' : '✔'}
          </Avatar>{' '}
          <span> </span>
          {status === 'ASSIGN' ? 'Pending' : 'Done'}
        </div>
          )}
    </>
  )
}
AppointmentSummaryCell.propTypes = {
  values: PropTypes.string
}

export const AssessmentsListingCell = ({ values }) => {
  return (
    <>
      <div
        style={{
          display: 'flex',
          color: values === 'ASSIGN' ? '#F24B5D' : '#4C927E',
          fontFamily: 'Roboto, Regular',
          fontSize: 14
        }}
      >
        <Avatar
          sx={{
            marginRight: 1,
            width: '24px',
            height: '24px',
            border: '5px double white',
            bgcolor: values === 'ASSIGN' ? '#6A6A6A' : '#4C927E',
            fontSize: 10
          }}
        >
          {values === 'ASSIGN' ? '' : '✔'}
        </Avatar>{' '}
        <span> </span>
        {values === 'ASSIGN' ? 'Pending' : 'Done'}
      </div>
    </>
  )
}
AssessmentsListingCell.propTypes = {
  values: PropTypes.string
}

export const ActivitiesActionCell = ({ values }) => {
  const dataValues = values.split(':')[0]
  const activityStatus = values.split(':')[1]

  return (
    <>
      {dataValues === 'NotStarted'
        ? (
        <div
          style={{ color: 'gray', fontFamily: 'Roboto, Regular', fontSize: 14 }}
        >
          <button
            type="link"
            style={{ color: '#F24B5D', border: 'none', background: 'none' }}
          >
            REMOVE
          </button>
        </div>
          )
        : (
        <div>
          {activityStatus.toUpperCase() === 'ASSIGN' && (
            <div
              style={{
                color: 'gray',
                fontFamily: 'Roboto, Regular',
                fontSize: 14
              }}
            >
              <button
                type="link"
                style={{ color: '#F24B5D', border: 'none', background: 'none' }}
              >
                REMOVE
              </button>
              <span> | </span>
              <button
                type="link"
                style={{
                  color: 'white',
                  border: 'none',
                  backgroundColor: '#F24B5D',
                  borderRadius: 5,
                  height: 35,
                  width: 65
                }}
              >
                PLAY
              </button>
            </div>
          )}
          {activityStatus === 'partially seen' && (
            <div
              style={{
                color: 'gray',
                fontFamily: 'Roboto, Regular',
                fontSize: 14
              }}
            >
              <button
                type="link"
                style={{
                  color: '#F24B5D',
                  border: 'none',
                  background: 'none',
                  borderRadius: 5,
                  height: 35
                }}
              >
                RESUME
              </button>
            </div>
          )}
          {activityStatus === 'seen' && (
            <div
              style={{
                color: 'gray',
                fontFamily: 'Roboto, Regular',
                fontSize: 14
              }}
            >
              <button
                type="link"
                style={{
                  color: '#F24B5D',
                  border: 'none',
                  background: 'none',
                  borderRadius: 5,
                  height: 35
                }}
              >
                PLAY AGAIN
              </button>
            </div>
          )}
          {activityStatus === 'started' && (
            <div
              style={{
                color: 'gray',
                fontFamily: 'Roboto, Regular',
                fontSize: 14
              }}
            >
              <button
                type="link"
                style={{
                  color: '#F24B5D',
                  border: 'none',
                  background: 'none',
                  borderRadius: 5,
                  height: 35
                }}
              >
                In Progress
              </button>
            </div>
          )}
        </div>
          )}
    </>
  )
}
ActivitiesActionCell.propTypes = {
  values: PropTypes.string
}

export const ActivitiesStatusCell = ({ values }) => {
  return (
    <>
      <div>
        <div style={{ fontFamily: 'Roboto, Regular', fontSize: fourteenPx }}>
          {values === 'ASSIGN'
            ? 'Not seen'
            : `${values[0].toUpperCase()}${values.slice(1)}`}
        </div>
      </div>
    </>
  )
}
ActivitiesStatusCell.propTypes = {
  values: PropTypes.string
}

// This will be Activity Listing action cell for HW( To get Play button if activity status is other than Not Seen)
export const ActivityListingHWCell = ({ values }) => {
  // console.log('Activity status::', values)
  // const dataValues = values.split(':')[0]
  // const activityStatus = values.split(':')[1]
  return (
    <>
      {
        <div
          style={{ color: 'gray', fontFamily: 'Roboto, Regular', fontSize: 14 }}
        >
          <button
            type="link"
            style={{
              color: '#F24B5D',
              border: 'none',
              background: 'none',
              borderRadius: 5,
              height: 35
            }}
          >
            PLAY
          </button>
        </div>
      }
    </>
  )
}
ActivityListingHWCell.propTypes = {
  values: PropTypes.string
}

// const viewDeails = () => {
//   console.log('Hello')
//   history.push('/appointments')
// }

export const ActionsCellAssessments = () => {
  return (
    <>
      <div style={{ color: 'gray' }}>
        <button
          id='activities'
          type="link"
          style={{
            fontFamily: 'Roboto, Regular',
            color: '#F24B5D',
            border: 'none',
            background: 'none'
          }}
        >
          VIEW DETAILS
        </button>
      </div>
    </>
  )
}
