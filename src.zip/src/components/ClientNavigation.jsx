import * as React from 'react'
import Box from '@mui/material/Box'
import Avatar from '@mui/material/Avatar'
import Menu from '@mui/material/Menu'
import MenuItem from '@mui/material/MenuItem'
import Divider from '@mui/material/Divider'
import IconButton from '@mui/material/IconButton'
import Tooltip from '@mui/material/Tooltip'
import PropTypes from 'prop-types'
import { Button } from 'react-bootstrap'
import { b2cPolicies } from '../authConfig'
import { useState } from 'react'
import ProfilePlaceholder from '../Assets/profilePlaceholder.png'
import loaderImg from '../Assets/spp.gif'
import { callApiForRegistration } from '../fetch'
import { createProfileBaseUrl } from '../CommonData/CreateAPIUrl'
import { userDataAPI } from '../CommonData/APIListing'

export default function ClientNavigation ({ userAccount, msalInstance, userName }) {
  const [anchorEl, setAnchorEl] = React.useState(null)
  const profilePic = React.useRef(null)
  const [isLoading, setLoading] = useState(false)
  const [imgFile, setImgFile] = useState(ProfilePlaceholder)
  const currentRole = JSON.parse(localStorage.getItem('UserType'))
  const userData = JSON.parse(localStorage.getItem('UserData'))

  const open = Boolean(anchorEl)
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget)
  }
  const handleClose = () => {
    setAnchorEl(null)
  }
  // This method used to change the Profile Pic of the user
  const handleFileChange = (event) => {
    const file = event.target.files[0]
    if (file) {
      setLoading(true)
      const reader = new FileReader()
      reader.onload = () => {
        // console.log('Img data::', reader.result)
        setImgFile(reader.result)
        saveUserPhotoData(reader.result)
      }
      reader.readAsDataURL(file)
    }
  }
  const userFirstName = currentRole === 'Coordinator' ? userAccount.idTokenClaims.extension_FirstName : userAccount.idTokenClaims.extension_FName
  const initial = userAccount && `${userFirstName.charAt(0).toUpperCase()}${userAccount && userAccount.idTokenClaims.extension_LastName.charAt(0).toUpperCase()}`

  // This method is for user's Photo Change
  const saveUserPhotoData = (imageData) => {
    setLoading(true)
    let saveData = {
      id: userData.id,
      firstName: '',
      middleName: '',
      lastName: '',
      email: '',
      mobileNo: '',
      address: '',
      city: '',
      state: '',
      zip: '',
      photoId: imageData,
      userName: '',
      languagePreference: '',
      referralPracticeName: ''
    }

    if (currentRole === 'Practitioner') {
      delete saveData.languagePreference
      delete saveData.referralPracticeName
      delete saveData.id

      saveData = {
        ...saveData,
        consultationRate: '',
        practiceName: '',
        practitionerId: userData.id
      }
    }
    if (currentRole === 'Coordinator') {
      delete saveData.languagePreference
      delete saveData.referralPracticeName

      saveData = {
        ...saveData,
        employeeId: '',
        email: ''

      }
    }

    // console.log('saveData Resp:-', saveData)
    const profileUrl = `${createProfileBaseUrl(userAccount, userDataAPI)}/${currentRole.toLowerCase()}/${userData.id}`

    // const reqUrl = `${profileBaseUrl}/${currentRole.toLowerCase()}/${registrationData.id}`

    callApiForRegistration(profileUrl, saveData)
      .then((response) => {
        // console.log('Update profile API Resp:-', response)
        if (response && response === `${currentRole} Photo Updated Successfully`) {
          const userPhotodata = {
            ...userData,
            photo: imageData
          }
          localStorage.setItem('UserData', JSON.stringify(userPhotodata))
          setLoading(false)
        } else {
          setLoading(false)
        }
        handleClose()
      })
      .catch(error => console.log('API Catch eror main class', error))
  }

  return (
    <React.Fragment>
      <Box sx={{ display: 'flex', alignItems: 'center', textAlign: 'center' }}>
        {/* <Typography sx={{ minWidth: 100 }}>Contact</Typography>
        <Typography sx={{ minWidth: 100 }}>Profile</Typography> */}
        <Tooltip title="Account settings">
          <IconButton
            onClick={handleClick}
            size="small"
            sx={{ ml: 2 }}
            aria-controls={open ? 'account-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={open ? 'true' : undefined}
          >
            <Avatar sx={{ width: '2.5rem', height: '2.5rem', color: '#F24B5D', backgroundColor: 'white', border: '1px solid #F24B5D' }}>{initial}</Avatar>
          </IconButton>
        </Tooltip>
      </Box>
      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        // onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: 'visible',
            filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
            mt: 1.5,
            '& .MuiAvatar-root': {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1
            },
            '&:before': {
              content: '""',
              display: 'block',
              position: 'absolute',
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: 'background.paper',
              transform: 'translateY(-50%) rotate(45deg)',
              zIndex: 0
            }
          }
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        <MenuItem style={{ paddingLeft: '5px', fontSize: '0.875rem' }}>
          <Avatar src={isLoading ? loaderImg : userData && userData.photo !== '' ? userData.photo : imgFile} sx={{ width: '3rem', height: '3rem', justifyContent: 'center', alignItems: 'center', objectFit: 'scale-down' }} /> {'Welcome,'}
          <br />
          {userName}
        </MenuItem>
        <Divider />
        <MenuItem>
          <Button variant="danger" style={{ backgroundColor: 'white', color: '#F24B5D', border: 'none' }} onClick={() => msalInstance.loginRedirect(b2cPolicies.authorities.editProfile)} >PROFILE</Button>
        </MenuItem>
        <Divider />
        <MenuItem>

          <Button variant="danger" style={{ backgroundColor: 'white', color: '#F24B5D', border: 'none' }} onClick={() => profilePic.current.click()}>CHANGE PHOTO</Button>
          <input
            id="photoId"
            ref={profilePic}
            type="file"
            style={{ display: 'none' }}
            accept="image/*"
            onChange={handleFileChange}
          />
        </MenuItem>
        <Divider />

        <MenuItem>
          <Button variant="danger" style={{ backgroundColor: 'white', color: '#F24B5D', border: 'none' }} onClick={() => {
            localStorage.clear()
            msalInstance.logoutRedirect({ postLogoutRedirectUri: '/' })
          }} >LOGOUT</Button>
        </MenuItem>
      </Menu>
    </React.Fragment>
  )
}
ClientNavigation.propTypes = {
  userName: PropTypes.string,
  userAccount: PropTypes.object,
  msalInstance: PropTypes.object
}
