import React from 'react'
import IconButton from '@material-ui/core/IconButton'
import InputAdornment from '@material-ui/core/InputAdornment'
import { TextField } from '@material-ui/core'
import { Button, OverlayTrigger, Popover } from 'react-bootstrap'
import SearchIcon from '@material-ui/icons/Search'
import ClearIcon from '@material-ui/icons/Clear'
// import FilterListIcon from '@mui/icons-material/FilterList'
import FilterImg from '../Assets/Filter.png'
import '../styles/App.css'
import PropTypes from 'prop-types'

function SearchComponent (props) {
  // const optionsArr = [{ name: 'Name', key: 'keyName' }, { name: 'Data', key: 'keyName2' }, { name: 'New Data', key: 'keyName3' }]
  const popover = (
      <Popover id="popover-basic">
          <Popover.Content style={{ display: 'flex', flexDirection: 'column', width: 150, textAlign: 'left' }}>
            {
              props.filterArr.map((data, index) =>
              <Button key={index} variant="white" id={data.key} name={data.name} style={{ backgroundColor: 'white', color: '#F24B5D', border: '0px', outline: 'none' }} onClick={props.handleFilterChange}>{data.name}</Button>
              )
            }
             </Popover.Content>

    </Popover>
  )

  return (
    <>
      <div style={{ padding: '10px', display: 'flex' }}>
        <TextField
          // label="With normal TextField"
          variant='outlined'
          size='small'
          value={props.searchValue}
          onChange={props.onSearchClick}
          sx={{
            htmlColor: 'white'
          }}
          placeholder='Search'
          InputProps={{
            startAdornment: (
              <InputAdornment position="start" style={{ marginLeft: '-20px', marginRight: '-10px' }}>
                <IconButton>
                  <SearchIcon id="search" htmlColor='#F24B5D' style={{ width: '20px' }} />
                </IconButton>
              </InputAdornment>
            ),
            endAdornment: (
              <InputAdornment position="end" style={{ marginRight: '-20px' }}>
                <IconButton id="clear" style={{ size: 'small' }} onClick={props.onSearchClick}>
                  <ClearIcon id="clear" style={{ width: '15px' }} onClick={props.onSearchClick} />
                </IconButton>
              </InputAdornment>
            )
          }}
        />
        <OverlayTrigger placement="bottom" overlay={popover} trigger="click" rootClose>
          <TextField
            // label="With normal TextField"
            variant='outlined'
            size='small'
            value={props.filterName}
            disabled
            // onChange={props.onSearchClick}
            sx={{
              htmlColor: 'white'
            }}
            style={{ width: 120 }}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end" style={{ marginRight: '-20px' }}>
                  <IconButton id="filter" style={{ size: 'small' }} onClick={props.handleFilterChange}>
                    <img id="filter" src={FilterImg} style={{ width: '24px', height: '24px' }} />
                  </IconButton>
                </InputAdornment>
              )
            }}
          />
        </OverlayTrigger>

      </div>
    </>
  )
}

export default SearchComponent

SearchComponent.propTypes = {
  searchValue: PropTypes.string,
  filterName: PropTypes.string,
  handleFilterChange: PropTypes.func.isRequired,
  onSearchClick: PropTypes.func.isRequired,
  filterArr: PropTypes.array
}
