import * as React from 'react'
import PaginationItem from '@mui/material/PaginationItem'
import Pagination from '@mui/material/Pagination'
import Stack from '@mui/material/Stack'
import { makeStyles } from '@material-ui/core/styles'
import PropTypes from 'prop-types'

const useStyles = makeStyles(() => ({
  ul: {
    '& .MuiPaginationItem-root': {
      color: '#F24B5D'
    },
    '& .Mui-selected': {
      backgroundColor: '#6A6A6A',
      color: 'white',
      shape: 'rounded'
    }
  }
}))

// class="makeStyles-ul-23 MuiPagination-ul css-wjh20t-MuiPagination-ul"

export default function PaginationControlled (props) {
  // const [page, setPage] = React.useState(1);

  // console.log("Page count :-",props.pageCount);
  const classes = useStyles()
  return (
    <Stack spacing={4}>
      <br />
      <Pagination classes={{ ul: classes.ul }} style={{ display: 'flex', justifyContent: 'center' }} px={0} count={props.pageCount} page={props.pageNo} onChange={props.handlePageChange} renderItem={(item) => (
                <PaginationItem
                style={{ borderRadius: '50px' }}
                sx={{ px: 0 }}
                  {...item}
                />
      )} />

              <br />
    </Stack>
  )
}

PaginationControlled.propTypes = {
  pageNo: PropTypes.number,
  pageCount: PropTypes.number,
  handlePageChange: PropTypes.func.isRequired
}
